// Simple text extraction functions for resume processing
// Note: This is a basic implementation for demo purposes

export async function extractTextFromFile(fileBuffer: ArrayBuffer, fileType: string): Promise<string> {
  try {
    console.log(`Extracting text from file type: ${fileType}`);
    
    // For text files, convert directly
    if (fileType === 'text/plain') {
      const decoder = new TextDecoder('utf-8');
      return decoder.decode(fileBuffer);
    }
    
    // For PDF files, we'll need a basic extraction
    if (fileType === 'application/pdf') {
      // Basic PDF text extraction would go here
      // For now, return a message indicating PDF processing
      return "PDF text extraction is not implemented in this demo. Please use a text file instead.";
    }
    
    // For Word documents
    if (fileType.includes('document') || fileType.includes('msword')) {
      // Basic Word document extraction would go here
      // For now, return a message indicating Word processing
      return "Word document text extraction is not implemented in this demo. Please use a text file instead.";
    }
    
    // Try to decode as text for any other file type
    try {
      const decoder = new TextDecoder('utf-8');
      const text = decoder.decode(fileBuffer);
      
      // Check if the decoded text looks reasonable
      if (text.length > 50 && text.includes(' ')) {
        return text;
      }
    } catch (e) {
      console.error('Failed to decode as text:', e);
    }
    
    // Fallback for unsupported file types
    return `File type ${fileType} is not supported in this demo. Please upload a plain text file (.txt) with your resume content.`;
    
  } catch (error) {
    console.error('Text extraction error:', error);
    throw new Error(`Failed to extract text from file: ${error.message}`);
  }
}

// Helper function to validate extracted text
export function validateExtractedText(text: string): boolean {
  if (!text || text.length < 50) {
    return false;
  }
  
  // Check for common resume sections or keywords
  const resumeKeywords = [
    'experience', 'education', 'skills', 'work', 'employment',
    'university', 'college', 'degree', 'certificate', 'project',
    'email', 'phone', 'address', 'objective', 'summary'
  ];
  
  const lowerText = text.toLowerCase();
  const foundKeywords = resumeKeywords.filter(keyword => lowerText.includes(keyword));
  
  return foundKeywords.length >= 2;
}