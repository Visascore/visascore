import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { createClient } from 'npm:@supabase/supabase-js'
import * as kv from './kv_store.tsx'
import { 
  analyzeResumeWithAI, 
  analyzeJobWithAI, 
  calculateMatchScore, 
  optimizeResumeWithAI
} from './ai-analysis-functions.tsx'
import { extractTextFromFile } from './text-extraction.tsx'

// Resume processing endpoints for the AI-powered resume tool
const resumeApp = new Hono()

resumeApp.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['POST', 'GET', 'OPTIONS', 'PUT', 'DELETE'],
}))

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
)

// Helper function to create a complete resume from optimized sections
function createFullResumeText(optimization: any, originalText: string): string {
  try {
    const sections = optimization.optimized_sections || {}
    
    let fullResume = ''
    
    // Add professional summary if available
    if (sections.summary) {
      fullResume += 'PROFESSIONAL SUMMARY\n'
      fullResume += sections.summary + '\n\n'
    }
    
    // Add experience section if available
    if (sections.experience && Array.isArray(sections.experience) && sections.experience.length > 0) {
      fullResume += 'PROFESSIONAL EXPERIENCE\n'
      sections.experience.forEach((exp: string, index: number) => {
        fullResume += `• ${exp}\n`
      })
      fullResume += '\n'
    }
    
    // Add skills section if available
    if (sections.skills && Array.isArray(sections.skills) && sections.skills.length > 0) {
      fullResume += 'CORE SKILLS\n'
      fullResume += sections.skills.join(' • ') + '\n\n'
    }
    
    // Add education section if available
    if (sections.education) {
      fullResume += 'EDUCATION\n'
      fullResume += sections.education + '\n\n'
    }
    
    // If we don't have much optimized content, fall back to original with improvements
    if (fullResume.length < 200) {
      fullResume = originalText
      
      // Add keyword improvements as a note
      if (optimization.keyword_additions && optimization.keyword_additions.length > 0) {
        fullResume += '\n\n--- OPTIMIZATION NOTES ---\n'
        fullResume += 'Recommended keywords to add: ' + optimization.keyword_additions.join(', ') + '\n'
      }
      
      if (optimization.ats_improvements && optimization.ats_improvements.length > 0) {
        fullResume += '\nATS Improvements to make:\n'
        optimization.ats_improvements.forEach((improvement: string, index: number) => {
          fullResume += `${index + 1}. ${improvement}\n`
        })
      }
    }
    
    return fullResume
    
  } catch (error) {
    console.error('Error creating full resume text:', error)
    return originalText + '\n\n--- Optimization data was generated but could not be formatted ---'
  }
}

// Resume upload and analysis endpoint
resumeApp.post('/resume/upload', async (c) => {
  try {
    // In public mode, create a temporary user session
    const publicUserId = `public_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`

    const formData = await c.req.formData()
    const file = formData.get('file') as File
    const title = formData.get('title') as string || 'My Resume'

    if (!file) {
      return c.json({ error: 'No file provided' }, 400)
    }

    // Validate file type and size
    const allowedTypes = ['application/pdf', 'text/plain', 'application/msword']
    if (!allowedTypes.includes(file.type) && !file.type.includes('document')) {
      return c.json({ error: 'Invalid file type. Please upload PDF, DOC, or TXT files.' }, 400)
    }

    if (file.size > 10 * 1024 * 1024) { // 10MB limit
      return c.json({ error: 'File size too large. Maximum 10MB allowed.' }, 400)
    }

    // Extract text from file
    const fileBuffer = await file.arrayBuffer()
    const extractedText = await extractTextFromFile(fileBuffer, file.type)

    if (extractedText.length < 100) {
      return c.json({ error: 'Resume text too short. Please ensure the file contains readable content.' }, 400)
    }

    // For public mode, we'll skip file storage and just analyze the text
    const fileName = `public_resumes/${publicUserId}/${Date.now()}-${file.name}`

    // Analyze resume with AI
    console.log('Analyzing resume with AI...')
    const aiAnalysis = await analyzeResumeWithAI(extractedText)

    // Store resume data
    const resumeData = {
      id: crypto.randomUUID(),
      user_id: publicUserId,
      file_name: file.name,
      file_size: file.size,
      file_type: file.type,
      storage_path: fileName,
      raw_text: extractedText,
      title,
      ai_analysis: aiAnalysis,
      ats_score: aiAnalysis.ats_score || 0,
      improvement_suggestions: aiAnalysis.improvement_areas || [],
      created_at: new Date().toISOString(),
      analyzed_at: new Date().toISOString()
    }

    // For public mode, store temporarily
    await kv.set(`resume:${resumeData.id}`, resumeData)
    
    // Set expiration for public resumes (24 hours)
    setTimeout(async () => {
      try {
        await kv.del(`resume:${resumeData.id}`)
      } catch (error) {
        console.log('Failed to clean up resume:', error)
      }
    }, 24 * 60 * 60 * 1000)

    console.log('Resume uploaded and analyzed successfully')

    return c.json({
      message: 'Resume uploaded and analyzed successfully',
      resume: {
        id: resumeData.id,
        title: resumeData.title,
        file_name: resumeData.file_name,
        ats_score: resumeData.ats_score,
        analysis: aiAnalysis
      }
    })

  } catch (error) {
    console.error('Resume upload error:', error)
    return c.json({ error: error.message || 'Internal server error during resume upload' }, 500)
  }
})

// Job description analysis endpoint
resumeApp.post('/job/analyze', async (c) => {
  try {
    // In public mode, create a temporary user session
    const publicUserId = `public_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`

    const { 
      title, 
      company, 
      description, 
      location, 
      source_url 
    } = await c.req.json()

    if (!description || description.length < 50) {
      return c.json({ error: 'Job description is too short' }, 400)
    }

    // Analyze job with AI
    console.log('Analyzing job description with AI...')
    const jobAnalysis = await analyzeJobWithAI(description)

    // Store job data with complete analysis
    const jobData = {
      id: crypto.randomUUID(),
      user_id: publicUserId,
      title: title || 'Untitled Position',
      company: company || '',
      location: location || '',
      description,
      source_url: source_url || '',
      ai_analysis: jobAnalysis, // Store complete AI analysis
      required_skills: jobAnalysis.required_skills || {},
      preferred_skills: jobAnalysis.preferred_skills || {},
      industry: jobAnalysis.industry || '',
      experience_level: jobAnalysis.experience_level || 'mid',
      visa_sponsorship: jobAnalysis.visa_sponsorship || false,
      key_responsibilities: jobAnalysis.key_responsibilities || [],
      qualifications: jobAnalysis.qualifications || [],
      keywords: jobAnalysis.keywords || [],
      salary_range: jobAnalysis.salary_range || null,
      remote_options: jobAnalysis.remote_options || 'onsite',
      company_size: jobAnalysis.company_size || 'medium',
      uk_relevance: jobAnalysis.uk_relevance || {},
      created_at: new Date().toISOString(),
      analyzed_at: new Date().toISOString()
    }

    // For public mode, store temporarily
    await kv.set(`job:${jobData.id}`, jobData)
    
    // Set expiration for public jobs (24 hours)
    setTimeout(async () => {
      try {
        await kv.del(`job:${jobData.id}`)
      } catch (error) {
        console.log('Failed to clean up job:', error)
      }
    }, 24 * 60 * 60 * 1000)

    console.log('Job description analyzed successfully')

    return c.json({
      message: 'Job description analyzed successfully',
      job: {
        id: jobData.id,
        title: jobData.title,
        company: jobData.company,
        location: jobData.location,
        analysis: jobAnalysis
      }
    })

  } catch (error) {
    console.error('Job analysis error:', error)
    return c.json({ error: error.message || 'Internal server error during job analysis' }, 500)
  }
})

// Resume-job matching endpoint
resumeApp.post('/match/analyze', async (c) => {
  try {
    // In public mode, skip user validation
    const publicUserId = `public_user`

    const { resume_id, job_id } = await c.req.json()

    if (!resume_id || !job_id) {
      return c.json({ error: 'Resume ID and Job ID are required' }, 400)
    }

    // Get resume and job data
    console.log('Looking for resume:', `resume:${resume_id}`)
    console.log('Looking for job:', `job:${job_id}`)
    
    const resumeData = await kv.get(`resume:${resume_id}`)
    const jobData = await kv.get(`job:${job_id}`)

    console.log('Resume found:', !!resumeData)
    console.log('Job found:', !!jobData)

    if (!resumeData) {
      console.error('Resume not found for ID:', resume_id)
      return c.json({ error: 'Resume not found. Please upload your resume first.' }, 404)
    }

    if (!jobData) {
      console.error('Job not found for ID:', job_id)
      return c.json({ error: 'Job not found. Please analyze the job description first.' }, 404)
    }

    // Validate resume has analysis
    if (!resumeData.ai_analysis) {
      console.error('Resume missing AI analysis:', resume_id)
      return c.json({ error: 'Resume analysis not found. Please re-upload your resume.' }, 400)
    }

    // Calculate match score with AI
    console.log('Calculating match score with AI...')
    console.log('Resume data:', resumeData)
    console.log('Job data:', jobData)
    
    // Get the stored job analysis from the job data
    const jobAnalysisData = await kv.get(`job:${job_id}`)
    console.log('Retrieved job analysis data:', jobAnalysisData)
    
    // Construct proper job analysis object
    const jobAnalysisForMatch = {
      required_skills: jobData.required_skills || {},
      preferred_skills: jobData.preferred_skills || {},
      industry: jobData.industry || 'general',
      description: jobData.description,
      experience_level: jobData.experience_level || 'mid',
      visa_sponsorship: jobData.visa_sponsorship || false,
      key_responsibilities: jobData.key_responsibilities || [],
      qualifications: jobData.qualifications || [],
      keywords: jobData.keywords || [],
      salary_range: jobData.salary_range || null,
      remote_options: jobData.remote_options || 'onsite',
      company_size: jobData.company_size || 'medium',
      uk_relevance: jobData.uk_relevance || {}
    }
    
    console.log('Job analysis for match:', jobAnalysisForMatch)
    
    const matchAnalysis = await calculateMatchScore(resumeData.ai_analysis, jobAnalysisForMatch)
    console.log('Match analysis result:', matchAnalysis)
    
    // Validate match analysis result
    if (!matchAnalysis) {
      throw new Error('Failed to generate match analysis')
    }
    
    // Ensure required fields exist with defaults for enhanced analysis
    const validatedMatch = {
      overall_score: matchAnalysis.overall_score || 0,
      skills_score: matchAnalysis.skills_score || 0,
      experience_score: matchAnalysis.experience_score || 0,
      keywords_score: matchAnalysis.keywords_score || 0,
      detailed_analysis: {
        matching_skills: matchAnalysis.detailed_analysis?.matching_skills || [],
        missing_skills: matchAnalysis.detailed_analysis?.missing_skills || [],
        keyword_gaps: matchAnalysis.detailed_analysis?.keyword_gaps || [],
        strengths: matchAnalysis.detailed_analysis?.strengths || [],
        weaknesses: matchAnalysis.detailed_analysis?.weaknesses || [],
        visa_advantages: matchAnalysis.detailed_analysis?.visa_advantages || [],
        cultural_fit_indicators: matchAnalysis.detailed_analysis?.cultural_fit_indicators || [],
        ats_compatibility: matchAnalysis.detailed_analysis?.ats_compatibility || []
      },
      optimization_suggestions: (matchAnalysis.optimization_suggestions || []).map(suggestion => ({
        type: suggestion.type || 'general',
        suggestion: suggestion.suggestion || '',
        keywords: suggestion.keywords || [],
        skills: suggestion.skills || [],
        priority: suggestion.priority || 'medium',
        impact_score: suggestion.impact_score || 0,
        implementation_effort: suggestion.implementation_effort || 'medium'
      })),
      interview_preparation: {
        likely_questions: matchAnalysis.interview_preparation?.likely_questions || [],
        key_talking_points: matchAnalysis.interview_preparation?.key_talking_points || [],
        areas_to_study: matchAnalysis.interview_preparation?.areas_to_study || [],
        weakness_mitigation: matchAnalysis.interview_preparation?.weakness_mitigation || [],
        salary_negotiation_points: matchAnalysis.interview_preparation?.salary_negotiation_points || []
      },
      market_insights: {
        competitive_positioning: matchAnalysis.market_insights?.competitive_positioning || 'Analysis pending',
        alternative_opportunities: matchAnalysis.market_insights?.alternative_opportunities || [],
        skill_development_priorities: matchAnalysis.market_insights?.skill_development_priorities || [],
        uk_market_fit: matchAnalysis.market_insights?.uk_market_fit || 'Market fit assessment pending'
      }
    }

    // Store match data
    const matchData = {
      id: crypto.randomUUID(),
      user_id: publicUserId,
      resume_id,
      job_id,
      overall_score: validatedMatch.overall_score,
      skills_score: validatedMatch.skills_score,
      experience_score: validatedMatch.experience_score,
      keywords_score: validatedMatch.keywords_score,
      detailed_analysis: validatedMatch.detailed_analysis,
      optimization_suggestions: validatedMatch.optimization_suggestions,
      interview_preparation: validatedMatch.interview_preparation,
      created_at: new Date().toISOString()
    }

    // For public mode, store temporarily
    await kv.set(`match:${matchData.id}`, matchData)
    
    // Set expiration for public matches (24 hours)
    setTimeout(async () => {
      try {
        await kv.del(`match:${matchData.id}`)
      } catch (error) {
        console.log('Failed to clean up match:', error)
      }
    }, 24 * 60 * 60 * 1000)

    console.log('Match analysis completed successfully')

    return c.json({
      message: 'Match analysis completed successfully',
      match: matchData
    })

  } catch (error) {
    console.error('Match analysis error:', error)
    return c.json({ error: error.message || 'Internal server error during match analysis' }, 500)
  }
})

// Resume optimization endpoint
resumeApp.post('/resume/optimize', async (c) => {
  try {
    // In public mode, skip user validation
    const publicUserId = `public_user`

    const { 
      resume_id, 
      job_id, 
      optimization_type = 'job-specific' 
    } = await c.req.json()

    if (!resume_id) {
      return c.json({ error: 'Resume ID is required' }, 400)
    }

    // Get resume data
    const resumeData = await kv.get(`resume:${resume_id}`)
    if (!resumeData) {
      return c.json({ error: 'Resume not found' }, 404)
    }

    let jobAnalysis = null
    if (job_id) {
      const jobData = await kv.get(`job:${job_id}`)
      if (jobData) {
        jobAnalysis = {
          required_skills: jobData.required_skills,
          preferred_skills: jobData.preferred_skills,
          industry: jobData.industry,
          description: jobData.description
        }
      }
    }

    // Generate optimized resume with AI
    console.log('Optimizing resume with AI...')
    const optimization = await optimizeResumeWithAI(
      resumeData.raw_text, 
      jobAnalysis, 
      optimization_type
    )

    // Create a complete optimized resume text from the sections
    const fullOptimizedResume = createFullResumeText(optimization, resumeData.raw_text)

    // Store optimization data
    const optimizationData = {
      id: crypto.randomUUID(),
      user_id: publicUserId,
      resume_id,
      job_id: job_id || null,
      optimized_sections: optimization.optimized_sections || {},
      changes_made: optimization.changes_made || [],
      keyword_additions: optimization.keyword_additions || [],
      ats_improvements: optimization.ats_improvements || [],
      estimated_score_improvement: optimization.estimated_score_improvement || 0,
      full_optimized_resume: fullOptimizedResume,
      optimization_type,
      created_at: new Date().toISOString()
    }

    // For public mode, store temporarily
    await kv.set(`optimization:${optimizationData.id}`, optimizationData)
    
    // Set expiration for public optimizations (24 hours)
    setTimeout(async () => {
      try {
        await kv.del(`optimization:${optimizationData.id}`)
      } catch (error) {
        console.log('Failed to clean up optimization:', error)
      }
    }, 24 * 60 * 60 * 1000)

    console.log('Resume optimization completed successfully')

    return c.json({
      message: 'Resume optimization completed successfully',
      optimization: optimizationData
    })

  } catch (error) {
    console.error('Resume optimization error:', error)
    return c.json({ error: error.message || 'Internal server error during resume optimization' }, 500)
  }
})

// Get user's resumes
resumeApp.get('/resumes', async (c) => {
  try {
    // In public mode, return all recent resumes (for demo purposes)
    const allResumes = await kv.getByPrefix('resume:') || []
    const recentResumes = allResumes
      .filter(resume => resume.user_id.startsWith('public_'))
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, 10) // Limit to recent 10 for performance

    return c.json({ resumes: recentResumes })

  } catch (error) {
    console.error('Get resumes error:', error)
    return c.json({ error: 'Internal server error getting resumes' }, 500)
  }
})

// Get user's job descriptions
resumeApp.get('/jobs', async (c) => {
  try {
    // In public mode, return all recent jobs (for demo purposes)
    const allJobs = await kv.getByPrefix('job:') || []
    const recentJobs = allJobs
      .filter(job => job.user_id.startsWith('public_'))
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, 10) // Limit to recent 10 for performance

    return c.json({ jobs: recentJobs })

  } catch (error) {
    console.error('Get jobs error:', error)
    return c.json({ error: 'Internal server error getting jobs' }, 500)
  }
})

// Get user's matches
resumeApp.get('/matches', async (c) => {
  try {
    // In public mode, return all recent matches (for demo purposes)
    const allMatches = await kv.getByPrefix('match:') || []
    const recentMatches = allMatches
      .filter(match => match.user_id.startsWith('public_'))
      .sort((a, b) => b.overall_score - a.overall_score)
      .slice(0, 10) // Limit to recent 10 for performance

    return c.json({ matches: recentMatches })

  } catch (error) {
    console.error('Get matches error:', error)
    return c.json({ error: 'Internal server error getting matches' }, 500)
  }
})

// Export as named and default export
export { resumeApp as resumeEndpoints }
export default resumeApp