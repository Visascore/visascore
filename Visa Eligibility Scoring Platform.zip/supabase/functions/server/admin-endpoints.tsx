import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'npm:@supabase/supabase-js';
import * as kv from './kv_store.tsx';

const app = new Hono();

// CORS middleware
app.use('*', cors({
  origin: ['http://localhost:3000', 'https://*.supabase.co'],
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
}));

// Create Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Admin authentication check
async function verifyAdminAuth(accessToken: string) {
  try {
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return { isValid: false, error: 'Invalid token' };
    }

    // Check if user is admin (you can customize this logic)
    const isAdmin = user.email === 'admin@visascore.com' || 
                   user.email === 'admin@visascore.co.uk' ||
                   user.user_metadata?.role === 'admin' ||
                   user.email?.endsWith('@visascore.com') ||
                   user.email?.endsWith('@visascore.co.uk');

    if (!isAdmin) {
      return { isValid: false, error: 'Access denied - admin role required' };
    }

    return { isValid: true, user };
  } catch (error) {
    return { isValid: false, error: error.message };
  }
}

// Check if admin exists (for setup page)
app.get('/admin/check', async (c) => {
  try {
    console.log('Checking admin status...');
    
    // Simple check - try to get all users
    const { data: allUsers, error: listError } = await supabase.auth.admin.listUsers();
    
    if (listError) {
      console.error('Error listing users:', listError);
      // Return a default response if we can't check
      return c.json({
        adminExists: false,
        existingAdmins: [],
        message: 'Unable to check admin status - assume setup needed'
      });
    }

    const adminEmails = ['admin@visascore.co.uk', 'admin@visascore.com'];
    const adminExists = [];
    
    console.log(`Found ${allUsers?.users?.length || 0} total users`);
    
    if (allUsers?.users && allUsers.users.length > 0) {
      for (const email of adminEmails) {
        const userExists = allUsers.users.some(user => user.email === email);
        if (userExists) {
          adminExists.push(email);
          console.log(`Found admin user: ${email}`);
        }
      }
    }

    console.log('Admin check complete:', { adminExists });

    return c.json({
      adminExists: adminExists.length > 0,
      existingAdmins: adminExists,
      message: adminExists.length > 0 ? 'Admin accounts found' : 'No admin accounts found',
      totalUsers: allUsers?.users?.length || 0
    });
  } catch (error) {
    console.error('Admin check error:', error);
    // Return safe default on any error
    return c.json({
      adminExists: false,
      existingAdmins: [],
      message: 'Error checking admin status - setup may be needed',
      error: error.message
    });
  }
});

// Create admin account endpoint (for initial setup)
app.post('/admin/setup', async (c) => {
  try {
    const { email, password, confirmKey } = await c.req.json();
    console.log('Admin setup attempt for email:', email);

    // Security check - only allow creation with specific confirmation key
    if (confirmKey !== 'ADMIN_SETUP_VISA_SCORE_2025') {
      console.error('Invalid setup key provided');
      return c.json({ error: 'Invalid setup key' }, 403);
    }

    // Check if admin already exists
    try {
      const { data: allUsers, error: checkError } = await supabase.auth.admin.listUsers();
      
      if (!checkError && allUsers?.users) {
        const userExists = allUsers.users.some(user => user.email === email);
        if (userExists) {
          console.log('Admin account already exists for:', email);
          return c.json({ error: 'Admin account already exists. You can log in directly.' }, 400);
        }
      }
    } catch (checkErr) {
      console.log('Error checking existing user, proceeding with creation:', checkErr);
    }

    console.log('Creating new admin user for:', email);

    // Create admin user
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { 
        name: 'System Administrator',
        role: 'admin',
        created_by: 'system_setup'
      },
      email_confirm: true // Auto-confirm email
    });

    if (error) {
      console.error('Supabase user creation error:', error);
      return c.json({ error: error.message }, 400);
    }

    console.log('Admin user created successfully:', data.user.id);

    // Store admin profile in KV store
    const adminProfile = {
      name: 'System Administrator',
      email: email,
      role: 'admin',
      completed_onboarding: true,
      preferences: {
        notifications: true,
        darkMode: true
      },
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    await kv.set(`user_profile:${data.user.id}`, adminProfile);
    console.log('Admin profile stored in KV store');

    return c.json({
      message: 'Admin account created successfully',
      user: {
        id: data.user.id,
        email: data.user.email,
        role: 'admin'
      }
    });
  } catch (error) {
    console.error('Admin setup error:', error);
    return c.json({ error: 'Failed to create admin account' }, 500);
  }
});

// Admin login endpoint
app.post('/admin/login', async (c) => {
  try {
    const { email, password } = await c.req.json();
    console.log('Admin login attempt for email:', email);

    // Sign in with Supabase
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) {
      console.error('Supabase auth error:', error);
      return c.json({ error: error.message }, 400);
    }

    console.log('Supabase auth successful, checking admin role for user:', data.user?.email);

    // Verify admin role
    const adminCheck = await verifyAdminAuth(data.session.access_token);
    if (!adminCheck.isValid) {
      console.error('Admin role verification failed:', adminCheck.error);
      return c.json({ error: adminCheck.error }, 403);
    }

    console.log('Admin login successful for:', data.user?.email);
    return c.json({
      user: data.user,
      session: data.session,
      message: 'Admin login successful'
    });
  } catch (error) {
    console.error('Admin login error:', error);
    return c.json({ error: 'Admin login failed' }, 500);
  }
});

// Get dashboard analytics
app.get('/admin/analytics', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    const accessToken = authHeader?.split(' ')[1];

    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const adminCheck = await verifyAdminAuth(accessToken);
    if (!adminCheck.isValid) {
      return c.json({ error: adminCheck.error }, 403);
    }

    // Get user statistics
    const { data: users, error: usersError } = await supabase.auth.admin.listUsers();
    
    if (usersError) {
      throw usersError;
    }

    // Get subscription data from KV store
    const subscriptions = await kv.getByPrefix('subscription:');
    const userProfiles = await kv.getByPrefix('user_profile:');

    // Calculate statistics
    const totalUsers = users.users.length;
    const activeUsers = users.users.filter(user => 
      new Date(user.last_sign_in_at || 0) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
    ).length;

    let trialUsers = 0;
    let monthlyUsers = 0;
    let totalRevenue = 0;
    let monthlyRevenue = 0;

    subscriptions.forEach(sub => {
      if (sub.value.status === 'trial') trialUsers++;
      if (sub.value.status === 'active' && sub.value.plan === 'monthly') {
        monthlyUsers++;
        totalRevenue += sub.value.amount || 6.99;
      }
    });

    // Calculate monthly revenue (current month)
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    subscriptions.forEach(sub => {
      if (sub.value.status === 'active' && sub.value.current_period_start) {
        const subDate = new Date(sub.value.current_period_start);
        if (subDate.getMonth() === currentMonth && subDate.getFullYear() === currentYear) {
          monthlyRevenue += sub.value.amount || 6.99;
        }
      }
    });

    // Generate chart data for the last 7 days
    const chartData = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const dayUsers = users.users.filter(user => {
        const createdDate = new Date(user.created_at).toISOString().split('T')[0];
        return createdDate === dateStr;
      }).length;

      chartData.push({
        date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        users: dayUsers,
        revenue: dayUsers * 0.5 // Estimated revenue
      });
    }

    return c.json({
      overview: {
        totalUsers,
        activeUsers,
        trialUsers,
        monthlyUsers,
        totalRevenue: parseFloat(totalRevenue.toFixed(2)),
        monthlyRevenue: parseFloat(monthlyRevenue.toFixed(2))
      },
      chartData,
      recentActivity: users.users
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
        .slice(0, 10)
        .map(user => ({
          id: user.id,
          email: user.email,
          created_at: user.created_at,
          last_sign_in_at: user.last_sign_in_at
        }))
    });
  } catch (error) {
    console.error('Analytics error:', error);
    return c.json({ error: 'Failed to fetch analytics' }, 500);
  }
});

// Get all users with details
app.get('/admin/users', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    const accessToken = authHeader?.split(' ')[1];

    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const adminCheck = await verifyAdminAuth(accessToken);
    if (!adminCheck.isValid) {
      return c.json({ error: adminCheck.error }, 403);
    }

    const { data: users, error: usersError } = await supabase.auth.admin.listUsers();
    
    if (usersError) {
      throw usersError;
    }

    // Enrich user data with profiles and subscriptions
    const enrichedUsers = await Promise.all(users.users.map(async (user) => {
      const profile = await kv.get(`user_profile:${user.id}`);
      const subscription = await kv.get(`subscription:${user.id}`);
      
      return {
        id: user.id,
        email: user.email,
        created_at: user.created_at,
        last_sign_in_at: user.last_sign_in_at,
        email_confirmed_at: user.email_confirmed_at,
        profile: profile || null,
        subscription: subscription || null
      };
    }));

    return c.json({ users: enrichedUsers });
  } catch (error) {
    console.error('Users fetch error:', error);
    return c.json({ error: 'Failed to fetch users' }, 500);
  }
});

// Delete user
app.delete('/admin/users/:userId', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    const accessToken = authHeader?.split(' ')[1];

    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const adminCheck = await verifyAdminAuth(accessToken);
    if (!adminCheck.isValid) {
      return c.json({ error: adminCheck.error }, 403);
    }

    const userId = c.req.param('userId');

    // Delete user from Supabase Auth
    const { error: deleteError } = await supabase.auth.admin.deleteUser(userId);
    
    if (deleteError) {
      throw deleteError;
    }

    // Clean up user data from KV store
    await kv.del(`user_profile:${userId}`);
    await kv.del(`subscription:${userId}`);
    
    // Delete chat history
    const chatKeys = await kv.getByPrefix(`chat_history:${userId}`);
    for (const chatKey of chatKeys) {
      await kv.del(chatKey.key);
    }

    return c.json({ message: 'User deleted successfully' });
  } catch (error) {
    console.error('User deletion error:', error);
    return c.json({ error: 'Failed to delete user' }, 500);
  }
});

// Reset user data
app.post('/admin/users/:userId/reset', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    const accessToken = authHeader?.split(' ')[1];

    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const adminCheck = await verifyAdminAuth(accessToken);
    if (!adminCheck.isValid) {
      return c.json({ error: adminCheck.error }, 403);
    }

    const userId = c.req.param('userId');

    // Reset user profile
    await kv.del(`user_profile:${userId}`);
    
    // Reset subscription
    await kv.del(`subscription:${userId}`);
    
    // Clear chat history
    const chatKeys = await kv.getByPrefix(`chat_history:${userId}`);
    for (const chatKey of chatKeys) {
      await kv.del(chatKey.key);
    }

    // Reset assessment data
    const assessmentKeys = await kv.getByPrefix(`assessment:${userId}`);
    for (const assessmentKey of assessmentKeys) {
      await kv.del(assessmentKey.key);
    }

    return c.json({ message: 'User data reset successfully' });
  } catch (error) {
    console.error('User reset error:', error);
    return c.json({ error: 'Failed to reset user data' }, 500);
  }
});

// Update user subscription
app.put('/admin/users/:userId/subscription', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    const accessToken = authHeader?.split(' ')[1];

    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const adminCheck = await verifyAdminAuth(accessToken);
    if (!adminCheck.isValid) {
      return c.json({ error: adminCheck.error }, 403);
    }

    const userId = c.req.param('userId');
    const { status, plan, amount } = await c.req.json();

    const subscription = {
      id: `admin_${Date.now()}`,
      user_id: userId,
      status,
      plan,
      amount: parseFloat(amount) || 6.99,
      currency: 'GBP',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    await kv.set(`subscription:${userId}`, subscription);

    return c.json({ message: 'Subscription updated successfully', subscription });
  } catch (error) {
    console.error('Subscription update error:', error);
    return c.json({ error: 'Failed to update subscription' }, 500);
  }
});

// Get revenue analytics
app.get('/admin/revenue', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    const accessToken = authHeader?.split(' ')[1];

    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const adminCheck = await verifyAdminAuth(accessToken);
    if (!adminCheck.isValid) {
      return c.json({ error: adminCheck.error }, 403);
    }

    const subscriptions = await kv.getByPrefix('subscription:');
    
    // Calculate revenue by month for the last 12 months
    const monthlyRevenue = {};
    const now = new Date();
    
    for (let i = 11; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      monthlyRevenue[monthKey] = 0;
    }

    subscriptions.forEach(sub => {
      if (sub.value.status === 'active' && sub.value.created_at) {
        const subDate = new Date(sub.value.created_at);
        const monthKey = `${subDate.getFullYear()}-${String(subDate.getMonth() + 1).padStart(2, '0')}`;
        
        if (monthlyRevenue.hasOwnProperty(monthKey)) {
          monthlyRevenue[monthKey] += sub.value.amount || 6.99;
        }
      }
    });

    const revenueData = Object.entries(monthlyRevenue).map(([month, revenue]) => ({
      month: new Date(month + '-01').toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
      revenue: parseFloat(revenue.toFixed(2))
    }));

    return c.json({ revenueData });
  } catch (error) {
    console.error('Revenue analytics error:', error);
    return c.json({ error: 'Failed to fetch revenue analytics' }, 500);
  }
});

// Get detailed user profile for admin
app.get('/admin/users/:userId/profile', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    const accessToken = authHeader?.split(' ')[1];

    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const adminCheck = await verifyAdminAuth(accessToken);
    if (!adminCheck.isValid) {
      return c.json({ error: adminCheck.error }, 403);
    }

    const userId = c.req.param('userId');

    // Get user from Supabase Auth
    const { data: user, error: userError } = await supabase.auth.admin.getUserById(userId);
    
    if (userError || !user) {
      return c.json({ error: 'User not found' }, 404);
    }

    // Get user profile data
    const profile = await kv.get(`user_profile:${userId}`);
    const subscription = await kv.get(`subscription:${userId}`);
    
    // Get chat history summary
    const chatKeys = await kv.getByPrefix(`chat_history:${userId}`);
    const chatSummary = {
      totalMessages: chatKeys.length,
      lastActivity: chatKeys.length > 0 ? Math.max(...chatKeys.map(chat => new Date(chat.value.timestamp || 0).getTime())) : null
    };

    // Get assessment data
    const assessmentKeys = await kv.getByPrefix(`assessment:${userId}`);
    const assessmentSummary = {
      totalAssessments: assessmentKeys.length,
      lastAssessment: assessmentKeys.length > 0 ? Math.max(...assessmentKeys.map(assessment => new Date(assessment.value.completed_at || 0).getTime())) : null
    };

    // Get visa scores
    const visaScores = await kv.get(`visa_scores:${userId}`);

    return c.json({
      user: {
        id: user.user.id,
        email: user.user.email,
        created_at: user.user.created_at,
        last_sign_in_at: user.user.last_sign_in_at,
        email_confirmed_at: user.user.email_confirmed_at,
        user_metadata: user.user.user_metadata
      },
      profile: profile || null,
      subscription: subscription || null,
      visaScores: visaScores || null,
      activity: {
        chat: chatSummary,
        assessments: assessmentSummary
      }
    });
  } catch (error) {
    console.error('User profile fetch error:', error);
    return c.json({ error: 'Failed to fetch user profile' }, 500);
  }
});

export { app as adminEndpoints }
export default app