import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { createClient } from 'jsr:@supabase/supabase-js@2'
import * as kv from './kv_store.tsx'

const authApp = new Hono()

// Enable CORS for this app
authApp.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['POST', 'GET', 'OPTIONS', 'PUT', 'DELETE'],
}))

// Create Supabase client with service role key
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
)

// Helper function to authenticate user from token
async function authenticateUser(token: string) {
  try {
    // Create a temporary client with the user's JWT token
    const tempClient = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      {
        global: {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      }
    )
    
    // Get user from the JWT token
    const { data: { user }, error } = await tempClient.auth.getUser(token)
    
    if (error) {
      console.error('Token verification error:', error)
      return { user: null, error }
    }
    
    if (!user) {
      console.error('No user found in token')
      return { user: null, error: new Error('No user found') }
    }
    
    console.log('Successfully authenticated user:', user.id)
    return { user, error: null }
  } catch (error) {
    console.error('Authentication error:', error)
    return { user: null, error }
  }
}

// Calculate visa scores based on user profile
function calculateVisaScores(onboardingData: any) {
  const scores: any = {}
  
  // Extract user data
  const { personalInfo, visaGoals, background } = onboardingData
  const age = personalInfo.age
  const education = background.education
  const workExperience = background.workExperience
  const englishLevel = background.englishLevel
  const profession = personalInfo.profession?.toLowerCase() || ''
  const country = personalInfo.country?.toLowerCase() || ''
  
  // Skilled Worker Visa Score
  let skilledWorkerScore = 0
  
  // Age points (0-15 points)
  if (age === '18-25' || age === '26-30') skilledWorkerScore += 15
  else if (age === '31-35') skilledWorkerScore += 12
  else if (age === '36-40') skilledWorkerScore += 8
  else if (age === '41-45') skilledWorkerScore += 5
  
  // Education points (0-25 points)
  if (education === 'phd') skilledWorkerScore += 25
  else if (education === 'masters') skilledWorkerScore += 20
  else if (education === 'bachelors') skilledWorkerScore += 15
  else if (education === 'diploma') skilledWorkerScore += 10
  
  // Work experience points (0-20 points)
  if (workExperience === '10+') skilledWorkerScore += 20
  else if (workExperience === '6-10') skilledWorkerScore += 15
  else if (workExperience === '4-5') skilledWorkerScore += 12
  else if (workExperience === '2-3') skilledWorkerScore += 8
  else if (workExperience === '0-1') skilledWorkerScore += 3
  
  // English level points (0-15 points)
  if (englishLevel === 'native') skilledWorkerScore += 15
  else if (englishLevel === 'advanced') skilledWorkerScore += 12
  else if (englishLevel === 'intermediate') skilledWorkerScore += 8
  else if (englishLevel === 'basic') skilledWorkerScore += 4
  
  // Profession bonus (0-15 points)
  const highDemandProfessions = ['software', 'engineer', 'doctor', 'nurse', 'teacher', 'data', 'cyber', 'researcher']
  if (highDemandProfessions.some(prof => profession.includes(prof))) {
    skilledWorkerScore += 15
  } else if (profession.includes('manager') || profession.includes('analyst')) {
    skilledWorkerScore += 10
  }
  
  // Country factor (0-10 points)
  const englishSpeakingCountries = ['india', 'nigeria', 'south africa', 'australia', 'canada', 'ireland', 'new zealand']
  if (englishSpeakingCountries.some(c => country.includes(c))) {
    skilledWorkerScore += 10
  }
  
  scores.skilledWorker = Math.min(100, skilledWorkerScore)
  
  // Global Talent Visa Score
  let globalTalentScore = 0
  
  // PhD gives significant boost
  if (education === 'phd') globalTalentScore += 40
  else if (education === 'masters') globalTalentScore += 25
  else if (education === 'bachelors') globalTalentScore += 15
  
  // Senior experience
  if (workExperience === '10+') globalTalentScore += 35
  else if (workExperience === '6-10') globalTalentScore += 25
  else if (workExperience === '4-5') globalTalentScore += 15
  
  // Tech/Research professions get boost
  const talentProfessions = ['software', 'research', 'scientist', 'architect', 'ai', 'machine learning', 'data scientist']
  if (talentProfessions.some(prof => profession.includes(prof))) {
    globalTalentScore += 25
  }
  
  scores.globalTalent = Math.min(100, globalTalentScore)
  
  // Student Visa Score
  let studentScore = 0
  
  // Age factor for students
  if (age === '18-25') studentScore += 30
  else if (age === '26-30') studentScore += 25
  else if (age === '31-35') studentScore += 15
  
  // Education background
  if (education === 'masters' || education === 'phd') studentScore += 20
  else if (education === 'bachelors') studentScore += 25
  else if (education === 'diploma') studentScore += 15
  
  // English proficiency
  if (englishLevel === 'native' || englishLevel === 'advanced') studentScore += 25
  else if (englishLevel === 'intermediate') studentScore += 15
  else if (englishLevel === 'basic') studentScore += 8
  
  // Work experience (students don't need much)
  if (workExperience === '0-1' || workExperience === '2-3') studentScore += 15
  else if (workExperience === '4-5') studentScore += 10
  
  scores.student = Math.min(100, studentScore)
  
  // Graduate Route Score (for recent graduates)
  let graduateScore = 0
  
  if (education === 'phd') graduateScore += 35
  else if (education === 'masters') graduateScore += 30
  else if (education === 'bachelors') graduateScore += 25
  
  // Recent graduate age range
  if (age === '18-25' || age === '26-30') graduateScore += 25
  else if (age === '31-35') graduateScore += 15
  
  // English skills
  if (englishLevel === 'native' || englishLevel === 'advanced') graduateScore += 20
  else if (englishLevel === 'intermediate') graduateScore += 15
  
  // Some work experience helpful
  if (workExperience === '0-1' || workExperience === '2-3') graduateScore += 20
  
  scores.graduate = Math.min(100, graduateScore)
  
  // Family Visa Score
  let familyScore = 0
  
  // Family ties are crucial
  if (background.familyTies === 'spouse') familyScore += 50
  else if (background.familyTies === 'children') familyScore += 40
  else if (background.familyTies === 'parents') familyScore += 30
  else if (background.familyTies === 'siblings') familyScore += 20
  else if (background.familyTies === 'other') familyScore += 15
  
  // Age factor
  if (age === '18-25' || age === '26-30' || age === '31-35') familyScore += 15
  
  // English skills
  if (englishLevel === 'native' || englishLevel === 'advanced') familyScore += 15
  else if (englishLevel === 'intermediate') familyScore += 10
  
  // Education and work help but aren't primary
  if (education === 'phd' || education === 'masters') familyScore += 10
  if (workExperience === '4-5' || workExperience === '6-10' || workExperience === '10+') familyScore += 10
  
  scores.family = Math.min(100, familyScore)
  
  // Investor/Start-up Visa Score
  let investorScore = 0
  
  // Business experience
  if (profession.includes('entrepreneur') || profession.includes('business') || 
      profession.includes('ceo') || profession.includes('founder')) {
    investorScore += 40
  } else if (profession.includes('manager') || profession.includes('director')) {
    investorScore += 25
  }
  
  // Education helps with business planning
  if (education === 'masters' || education === 'phd') investorScore += 20
  else if (education === 'bachelors') investorScore += 15
  
  // Work experience in business
  if (workExperience === '6-10' || workExperience === '10+') investorScore += 25
  else if (workExperience === '4-5') investorScore += 15
  
  // English for business
  if (englishLevel === 'native' || englishLevel === 'advanced') investorScore += 15
  
  scores.investor = Math.min(100, investorScore)
  
  return scores
}

// Get user profile - corrected path
authApp.get('/auth/profile', async (c) => {
  try {
    const authHeader = c.req.header('Authorization')
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Missing or invalid authorization header' }, 401)
    }

    const token = authHeader.split(' ')[1]
    console.log('Authenticating user with token...')
    
    const { user, error: authError } = await authenticateUser(token)

    if (authError || !user) {
      console.error('Auth error:', authError)
      return c.json({ error: 'Invalid token' }, 401)
    }

    console.log('Getting profile for user:', user.id)

    // Get user profile from KV store
    const profile = await kv.get(`user_profile:${user.id}`) || {
      name: user.user_metadata?.name || user.email?.split('@')[0] || 'User',
      email: user.email,
      created_at: user.created_at,
      completed_onboarding: false,
      has_used_trial: false
    }

    console.log('Profile loaded:', profile)

    return c.json(profile)

  } catch (error) {
    console.error('Get user profile error:', error)
    return c.json({ error: 'Failed to get user profile' }, 500)
  }
})

// Get visa scores for user
authApp.get('/auth/visa-scores', async (c) => {
  try {
    const authHeader = c.req.header('Authorization')
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Missing or invalid authorization header' }, 401)
    }

    const token = authHeader.split(' ')[1]
    const { user, error: authError } = await authenticateUser(token)

    if (authError || !user) {
      return c.json({ error: 'Invalid token' }, 401)
    }

    // Get user profile with onboarding data
    const profile = await kv.get(`user_profile:${user.id}`)
    
    if (!profile || !profile.completed_onboarding) {
      return c.json({ 
        error: 'Onboarding not completed',
        scores: null,
        needsOnboarding: true 
      })
    }

    // Calculate visa scores
    const scores = calculateVisaScores({
      personalInfo: {
        age: profile.age,
        country: profile.country,
        profession: profile.profession
      },
      visaGoals: profile.visa_goals || {},
      background: profile.background || {}
    })

    // Store calculated scores
    const scoreData = {
      userId: user.id,
      scores,
      calculatedAt: new Date().toISOString(),
      profileData: {
        age: profile.age,
        education: profile.background?.education,
        workExperience: profile.background?.workExperience,
        englishLevel: profile.background?.englishLevel,
        profession: profile.profession,
        country: profile.country,
        familyTies: profile.background?.familyTies
      }
    }

    await kv.set(`visa_scores:${user.id}`, scoreData)

    console.log('Visa scores calculated for user:', user.id, scores)

    return c.json({
      scores,
      profileData: scoreData.profileData,
      calculatedAt: scoreData.calculatedAt,
      recommendations: generateRecommendations(scores, profile)
    })

  } catch (error) {
    console.error('Get visa scores error:', error)
    return c.json({ error: 'Failed to calculate visa scores' }, 500)
  }
})

// Generate recommendations based on scores
function generateRecommendations(scores: any, profile: any) {
  const recommendations = []
  const sortedScores = Object.entries(scores)
    .sort(([,a], [,b]) => (b as number) - (a as number))
    .slice(0, 3)

  for (const [visaType, score] of sortedScores) {
    if (score as number > 60) {
      recommendations.push({
        visaType,
        score: score as number,
        level: 'high',
        message: `You have a strong profile for ${visaType} visa with ${score}% compatibility`,
        nextSteps: getNextSteps(visaType, profile)
      })
    } else if (score as number > 40) {
      recommendations.push({
        visaType,
        score: score as number,
        level: 'medium',
        message: `You have potential for ${visaType} visa with ${score}% compatibility`,
        nextSteps: getNextSteps(visaType, profile)
      })
    }
  }

  return recommendations
}

function getNextSteps(visaType: string, profile: any) {
  const steps: any = {
    skilledWorker: [
      'Find a UK employer willing to sponsor your visa',
      'Ensure your job is on the Skilled Worker eligible occupations list',
      'Prepare English language test results if needed',
      'Gather educational qualification documents'
    ],
    globalTalent: [
      'Research endorsing bodies in your field',
      'Prepare portfolio of achievements and recognition',
      'Get letters of recommendation from industry experts',
      'Document your exceptional talent or promise'
    ],
    student: [
      'Research UK universities and courses',
      'Take English language tests (IELTS/TOEFL)',
      'Prepare financial documents for maintenance funds',
      'Apply for unconditional offers from universities'
    ],
    graduate: [
      'Complete your UK degree successfully',
      'Apply within the time limit after graduation',
      'Prepare for job searching in the UK',
      'Network with UK employers and alumni'
    ],
    family: [
      'Gather relationship evidence and documents',
      'Meet English language requirements',
      'Prepare financial maintenance evidence',
      'Understand specific requirements for your family relationship'
    ],
    investor: [
      'Develop a comprehensive business plan',
      'Secure the required investment funds',
      'Research UK market opportunities',
      'Get legal and financial advice for your business'
    ]
  }

  return steps[visaType] || ['Contact an immigration lawyer for guidance']
}

// Complete onboarding
authApp.post('/auth/complete-onboarding', async (c) => {
  try {
    const authHeader = c.req.header('Authorization')
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Missing or invalid authorization header' }, 401)
    }

    const token = authHeader.split(' ')[1]
    const { user, error: authError } = await authenticateUser(token)

    if (authError || !user) {
      return c.json({ error: 'Invalid token' }, 401)
    }

    const { onboardingData } = await c.req.json()

    console.log('Completing onboarding for user:', user.id)

    // Save user profile with onboarding data
    const profile = {
      name: onboardingData.personalInfo.name,
      email: user.email,
      country: onboardingData.personalInfo.country,
      age: onboardingData.personalInfo.age,
      profession: onboardingData.personalInfo.profession,
      visa_goals: onboardingData.visaGoals,
      background: {
        ...onboardingData.background,
        workSector: onboardingData.background.workSector || '',
        qualificationCountry: onboardingData.background.qualificationCountry || '',
        specificSkills: onboardingData.background.specificSkills || []
      },
      preferences: {
        ...onboardingData.preferences,
        language: onboardingData.preferences.language || 'English',
        timezone: onboardingData.preferences.timezone || 'UTC'
      },
      settings: {
        emailNotifications: true,
        smsNotifications: false,
        marketing: false,
        dataSharing: true,
        theme: 'dark'
      },
      completed_onboarding: true,
      has_used_trial: false,
      onboarding_completed_at: new Date().toISOString(),
      created_at: user.created_at,
      updated_at: new Date().toISOString()
    }

    await kv.set(`user_profile:${user.id}`, profile)

    // Calculate initial visa scores
    const scores = calculateVisaScores(onboardingData)
    const scoreData = {
      userId: user.id,
      scores,
      calculatedAt: new Date().toISOString(),
      profileData: {
        age: profile.age,
        education: profile.background?.education,
        workExperience: profile.background?.workExperience,
        englishLevel: profile.background?.englishLevel,
        profession: profile.profession,
        country: profile.country,
        familyTies: profile.background?.familyTies
      }
    }

    await kv.set(`visa_scores:${user.id}`, scoreData)

    // Initialize user progress
    const initialProgress = {
      totalPoints: 0,
      currentStreak: 0,
      lastActivityDate: '',
      completedTasks: [],
      level: 1,
      achievements: [],
      weeklyGoal: 5,
      dailyTasksCompleted: 0,
      visaScoreImprovements: {},
      created_at: new Date().toISOString()
    }

    await kv.set(`user_progress:${user.id}`, initialProgress)

    console.log('Onboarding completed for user:', user.id)

    return c.json({
      message: 'Onboarding completed successfully',
      profile,
      scores,
      recommendations: generateRecommendations(scores, profile)
    })

  } catch (error) {
    console.error('Complete onboarding error:', error)
    return c.json({ error: 'Failed to complete onboarding' }, 500)
  }
})

// Update user profile - fix path to match expected usage
authApp.put('/user/profile', async (c) => {
  try {
    const authHeader = c.req.header('Authorization')
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Missing or invalid authorization header' }, 401)
    }

    const token = authHeader.split(' ')[1]
    const { user, error: authError } = await authenticateUser(token)

    if (authError || !user) {
      return c.json({ error: 'Invalid token' }, 401)
    }

    const updateData = await c.req.json()

    console.log('Updating profile for user:', user.id)

    // Get existing profile
    const existingProfile = await kv.get(`user_profile:${user.id}`) || {}

    // Update profile with deep merge for nested objects
    const updatedProfile = {
      ...existingProfile,
      ...updateData,
      // Handle nested object updates properly
      settings: updateData.settings ? {
        ...existingProfile.settings,
        ...updateData.settings
      } : existingProfile.settings,
      preferences: updateData.preferences ? {
        ...existingProfile.preferences,
        ...updateData.preferences
      } : existingProfile.preferences,
      background: updateData.background ? {
        ...existingProfile.background,
        ...updateData.background
      } : existingProfile.background,
      visa_goals: updateData.visa_goals ? {
        ...existingProfile.visa_goals,
        ...updateData.visa_goals
      } : existingProfile.visa_goals,
      updated_at: new Date().toISOString()
    }

    await kv.set(`user_profile:${user.id}`, updatedProfile)

    // Recalculate visa scores if profile data changed
    if (updateData.age || updateData.profession || updateData.background || updateData.country) {
      const scores = calculateVisaScores({
        personalInfo: {
          age: updatedProfile.age,
          country: updatedProfile.country,
          profession: updatedProfile.profession
        },
        visaGoals: updatedProfile.visa_goals || {},
        background: updatedProfile.background || {}
      })

      const scoreData = {
        userId: user.id,
        scores,
        calculatedAt: new Date().toISOString(),
        profileData: {
          age: updatedProfile.age,
          education: updatedProfile.background?.education,
          workExperience: updatedProfile.background?.workExperience,
          englishLevel: updatedProfile.background?.englishLevel,
          profession: updatedProfile.profession,
          country: updatedProfile.country,
          familyTies: updatedProfile.background?.familyTies
        }
      }

      await kv.set(`visa_scores:${user.id}`, scoreData)
    }

    console.log('Profile updated for user:', user.id)

    return c.json({
      message: 'Profile updated successfully',
      profile: updatedProfile
    })

  } catch (error) {
    console.error('Update user profile error:', error)
    return c.json({ error: 'Failed to update user profile' }, 500)
  }
})

// Check subscription access
authApp.get('/auth/check-access', async (c) => {
  try {
    const authHeader = c.req.header('Authorization')
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ has_access: false, reason: 'No token provided' })
    }

    const token = authHeader.split(' ')[1]
    const { user, error: authError } = await authenticateUser(token)

    if (authError || !user) {
      return c.json({ has_access: false, reason: 'Invalid token' })
    }

    // Get subscription status
    const subscription = await kv.get(`subscription:${user.id}`)
    
    if (!subscription) {
      const userProfile = await kv.get(`user_profile:${user.id}`)
      return c.json({ 
        has_access: false, 
        reason: 'No subscription found',
        can_start_trial: !userProfile?.has_used_trial
      })
    }

    const now = new Date()

    // Check trial access
    if (subscription.status === 'trial') {
      const trialEnd = new Date(subscription.trial_end)
      const isExpired = now > trialEnd
      
      if (!isExpired) {
        return c.json({ 
          has_access: true, 
          subscription_status: 'trial',
          days_remaining: Math.max(0, Math.ceil((trialEnd.getTime() - now.getTime()) / (24 * 60 * 60 * 1000)))
        })
      }
    }

    // Check active subscription
    if (subscription.status === 'active' && subscription.current_period_end) {
      const periodEnd = new Date(subscription.current_period_end)
      if (now <= periodEnd) {
        return c.json({ 
          has_access: true, 
          subscription_status: 'active',
          cancel_at_period_end: subscription.cancel_at_period_end || false
        })
      }
    }

    return c.json({ 
      has_access: false, 
      reason: 'Subscription expired',
      subscription_status: subscription.status
    })

  } catch (error) {
    console.error('Check access error:', error)
    return c.json({ has_access: false, reason: 'Internal server error' })
  }
})

// Sign up endpoint
authApp.post('/auth/signup', async (c) => {
  try {
    const { email, password, name } = await c.req.json()

    if (!email || !password || !name) {
      return c.json({ error: 'Email, password, and name are required' }, 400)
    }

    console.log('Creating new user account:', email)

    // First, check if user already exists by trying to get them by email
    const { data: existingUsers, error: listError } = await supabase.auth.admin.listUsers()
    
    if (!listError && existingUsers) {
      const existingUser = existingUsers.users.find(user => user.email === email)
      if (existingUser) {
        console.log('User already exists:', email)
        return c.json({ 
          error: 'An account with this email address already exists. Please sign in instead.', 
          code: 'email_exists' 
        }, 409)
      }
    }

    // Create user account
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      email_confirm: true // Auto-confirm since email server not configured
    })

    if (authError) {
      console.error('Auth creation error:', authError)
      
      // Handle different error cases
      if (authError.message.includes('already registered') || authError.code === 'email_exists') {
        return c.json({ 
          error: 'An account with this email address already exists. Please sign in instead.', 
          code: 'email_exists' 
        }, 409)
      }
      
      if (authError.message.includes('Password')) {
        return c.json({ 
          error: 'Password must be at least 6 characters long', 
          code: 'weak_password' 
        }, 400)
      }
      
      return c.json({ 
        error: authError.message || 'Failed to create account', 
        code: authError.code || 'signup_error' 
      }, 400)
    }

    if (!authData.user) {
      return c.json({ error: 'Failed to create user account' }, 500)
    }

    console.log('User created successfully:', authData.user.id)

    // Create initial user profile
    const initialProfile = {
      name,
      email,
      created_at: new Date().toISOString(),
      completed_onboarding: false,
      has_used_trial: false
    }

    await kv.set(`user_profile:${authData.user.id}`, initialProfile)

    return c.json({
      success: true,
      message: 'Account created successfully',
      user: {
        id: authData.user.id,
        email: authData.user.email,
        name
      }
    })

  } catch (error) {
    console.error('Signup error:', error)
    return c.json({ 
      error: 'Failed to create account. Please try again.', 
      code: 'internal_error' 
    }, 500)
  }
})

// Fix profile endpoint to match expected path
authApp.get('/profile', async (c) => {
  try {
    const authHeader = c.req.header('Authorization')
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Missing or invalid authorization header' }, 401)
    }

    const token = authHeader.split(' ')[1]
    console.log('Authenticating user with token...')
    
    const { user, error: authError } = await authenticateUser(token)

    if (authError || !user) {
      console.error('Auth error:', authError)
      return c.json({ error: 'Invalid token' }, 401)
    }

    console.log('Getting profile for user:', user.id)

    // Get user profile from KV store
    const profile = await kv.get(`user_profile:${user.id}`) || {
      name: user.user_metadata?.name || user.email?.split('@')[0] || 'User',
      email: user.email,
      created_at: user.created_at,
      completed_onboarding: false,
      has_used_trial: false
    }

    console.log('Profile loaded:', profile)

    return c.json(profile)

  } catch (error) {
    console.error('Get user profile error:', error)
    return c.json({ error: 'Failed to get user profile' }, 500)
  }
})

// Health check for auth endpoints
authApp.get('/auth/health', (c) => {
  return c.json({ 
    status: 'healthy', 
    service: 'auth-endpoints',
    timestamp: new Date().toISOString() 
  })
})

// Export as named and default export
export { authApp as authEndpoints }
export default authApp