import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import * as kv from './kv_store.tsx'
import { callOpenAI, getAuthenticatedUser, VISA_AI_SYSTEM_PROMPT } from './chat-helpers.tsx'

const chatApp = new Hono()

chatApp.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['POST', 'GET', 'OPTIONS', 'PUT', 'DELETE'],
}))

// Main AI Chat Endpoint
chatApp.post('/chat', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'Authentication required' }, 401)
    }

    const user = await getAuthenticatedUser(accessToken)
    const { message, sessionId, messageHistory = [] } = await c.req.json()
    
    if (!message || message.trim().length < 2) {
      return c.json({ error: 'Message is required and must be at least 2 characters' }, 400)
    }

    console.log('AI Chat request:', { 
      userId: user.id, 
      sessionId,
      messageLength: message.length, 
      historyLength: messageHistory.length 
    })

    // Format conversation for OpenAI
    const conversationMessages = [
      { role: 'system', content: VISA_AI_SYSTEM_PROMPT },
      ...messageHistory.slice(-10).map((msg: any) => ({
        role: msg.role === 'user' ? 'user' : 'assistant',
        content: msg.content
      })),
      { role: 'user', content: message.trim() }
    ]

    // Call OpenAI API
    const response = await callOpenAI(conversationMessages, 'gpt-4o-mini', 0.7, 1500)
    const aiResponse = response.choices[0].message.content

    // Create message objects
    const userMessage = {
      id: `user_${Date.now()}`,
      content: message.trim(),
      role: 'user',
      timestamp: new Date().toISOString()
    }

    const assistantMessage = {
      id: `assistant_${Date.now()}`,
      content: aiResponse,
      role: 'assistant',
      timestamp: new Date().toISOString(),
      metadata: {
        model: 'gpt-4o-mini',
        confidence: 95,
        visaRoute: 'general'
      }
    }

    // Store conversation in session
    const currentSessionId = sessionId || `chat_${user.id}_${Date.now()}`
    const sessionKey = `chat_session:${user.id}:${currentSessionId}`
    
    // Get existing session or create new one
    let existingSession = await kv.get(sessionKey)
    if (!existingSession) {
      const firstUserWords = message.trim().split(' ').slice(0, 6).join(' ')
      existingSession = {
        id: currentSessionId,
        title: firstUserWords.length > 50 ? firstUserWords.slice(0, 50) + '...' : firstUserWords,
        created_at: new Date().toISOString(),
        last_message_at: new Date().toISOString(),
        message_count: 0,
        messages: []
      }
    }

    // Update session with new messages
    const updatedMessages = [...(existingSession.messages || []), userMessage, assistantMessage]
    const updatedSession = {
      ...existingSession,
      messages: updatedMessages,
      last_message_at: new Date().toISOString(),
      message_count: updatedMessages.length
    }

    // Save updated session
    await kv.set(sessionKey, updatedSession)

    console.log('AI Chat response generated and stored successfully')

    return c.json({
      response: aiResponse,
      sessionId: currentSessionId,
      metadata: assistantMessage.metadata,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('AI Chat error:', error)
    
    const fallbackResponse = "I'm having trouble connecting to my AI brain right now. Please try asking your question again in a moment. In the meantime, you can check out our comprehensive visa guides or browse the latest UK visa news!"
    
    return c.json({ 
      response: fallbackResponse,
      error: error.message || 'Failed to process chat request',
      timestamp: new Date().toISOString(),
      fallback: true
    }, 500)
  }
})

// Get chat history
chatApp.get('/chat-history', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'Authentication required' }, 401)
    }

    const user = await getAuthenticatedUser(accessToken)
    const sessionId = c.req.query('sessionId')
    
    if (sessionId) {
      const sessionKey = `chat_session:${user.id}:${sessionId}`
      const session = await kv.get(sessionKey)
      
      if (!session) {
        return c.json({ error: 'Session not found' }, 404)
      }
      
      return c.json({ 
        messages: session.messages || [],
        session: session
      })
    } else {
      const sessions = await kv.getByPrefix(`chat_session:${user.id}:`)
      
      if (sessions.length === 0) {
        return c.json({ messages: [] })
      }
      
      const mostRecentSession = sessions
        .sort((a, b) => new Date(b.last_message_at).getTime() - new Date(a.last_message_at).getTime())[0]
      
      return c.json({ 
        messages: mostRecentSession.messages || [],
        session: mostRecentSession
      })
    }
    
  } catch (error) {
    console.error('Chat history error:', error)
    return c.json({ 
      error: error.message || 'Failed to retrieve chat history',
      messages: []
    }, 500)
  }
})

// Get all chat sessions
chatApp.get('/chat-sessions', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'Authentication required' }, 401)
    }

    const user = await getAuthenticatedUser(accessToken)
    const sessions = await kv.getByPrefix(`chat_session:${user.id}:`)
    
    const sortedSessions = sessions
      .map(session => ({
        id: session.id,
        title: session.title || 'New conversation',
        created_at: session.created_at,
        last_message_at: session.last_message_at,
        message_count: session.message_count || 0
      }))
      .sort((a, b) => new Date(b.last_message_at).getTime() - new Date(a.last_message_at).getTime())
    
    console.log('Retrieved chat sessions:', { userId: user.id, count: sortedSessions.length })
    
    return c.json({ sessions: sortedSessions })
  } catch (error) {
    console.error('Get chat sessions error:', error)
    return c.json({ 
      error: error.message || 'Failed to retrieve chat sessions',
      sessions: []
    }, 500)
  }
})

// Delete chat session
chatApp.delete('/chat-session/:sessionId', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    if (!accessToken) {
      return c.json({ error: 'Authentication required' }, 401)
    }

    const user = await getAuthenticatedUser(accessToken)
    const sessionId = c.req.param('sessionId')
    
    const sessionKey = `chat_session:${user.id}:${sessionId}`
    const existingSession = await kv.get(sessionKey)
    
    if (!existingSession) {
      return c.json({ error: 'Chat session not found' }, 404)
    }
    
    await kv.del(sessionKey)
    
    console.log('Chat session deleted:', { userId: user.id, sessionId })
    
    return c.json({ message: 'Chat session deleted successfully' })
  } catch (error) {
    console.error('Delete chat session error:', error)
    return c.json({ 
      error: error.message || 'Failed to delete chat session'
    }, 500)
  }
})

// Health check
chatApp.get('/chat-health', (c) => {
  return c.json({ 
    status: 'healthy', 
    service: 'chat-endpoints',
    openaiConfigured: !!Deno.env.get('OPENAI_API_KEY'),
    timestamp: new Date().toISOString() 
  })
})

// Export as named and default export
export { chatApp as chatEndpoints }
export default chatApp