import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import * as kv from './kv_store.tsx'

// AI-powered endpoints for visa guidance and eligibility checking
const aiApp = new Hono()

aiApp.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['POST', 'GET', 'OPTIONS', 'PUT', 'DELETE'],
}))

const openaiApiKey = Deno.env.get('OPENAI_API_KEY')
if (!openaiApiKey) {
  console.error('OPENAI_API_KEY is not set')
}

// Helper function to call OpenAI API
async function callOpenAI(messages: any[], model = 'gpt-4o-mini', temperature = 0.7, maxTokens = 2000) {
  if (!openaiApiKey) {
    throw new Error('OpenAI API key not configured')
  }

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${openaiApiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      messages,
      temperature,
      max_tokens: maxTokens,
    }),
  })

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Unknown error' }))
    throw new Error(`OpenAI API error: ${errorData.error?.message || response.statusText}`)
  }

  return await response.json()
}

// AI Visa Assistant Chat Endpoint
aiApp.post('/ai-chat', async (c) => {
  try {
    const { message, conversationHistory = [] } = await c.req.json()
    
    if (!message || message.length < 2) {
      return c.json({ error: 'Message is required and must be at least 2 characters' }, 400)
    }

    console.log('AI Chat request:', { messageLength: message.length, historyLength: conversationHistory.length })

    // Build conversation context
    const systemPrompt = `You are VISA-AI, a friendly and knowledgeable UK visa consultant assistant. You provide accurate, up-to-date information about UK visas and immigration.

Key 2025 UK Visa Information:
- Skilled Worker visa requires RQF Level 6+ qualification and £41,700+ minimum salary
- Global Talent visa has two stages: endorsement then visa application
- Student visas are now all electronic (eVisa system)
- Graduate visa duration reduced from 2 years to 18 months after Autumn 2025
- New ETA system for visa-free nationals from January 2025
- All visa fees include Immigration Health Surcharge of £1,035/year

Visa Categories:
1. Work Visas: Skilled Worker, Global Talent, Graduate, Intra-company Transfer
2. Study Visas: Student, Child Student, Short-term Study
3. Family Visas: Spouse/Partner, Dependent Child, Parent, Adult Dependent Relative
4. Visit Visas: Standard Visitor, Business Visitor, Transit
5. Other: UK Ancestry, Investor, Innovator Founder

Always be helpful, empathetic, and provide actionable guidance. If you don't know something specific, direct users to official UKVI sources.`

    const messages = [
      { role: 'system', content: systemPrompt },
      ...conversationHistory.slice(-10), // Keep last 10 messages for context
      { role: 'user', content: message }
    ]

    const response = await callOpenAI(messages, 'gpt-4o-mini', 0.7, 1500)
    const aiResponse = response.choices[0].message.content

    // Store conversation for analytics (optional)
    const conversationId = `conversation:${Date.now()}_${Math.random().toString(36).slice(2)}`
    await kv.set(conversationId, {
      timestamp: new Date().toISOString(),
      userMessage: message,
      aiResponse: aiResponse,
      type: 'ai_chat'
    })

    console.log('AI Chat response generated successfully')

    return c.json({
      response: aiResponse,
      conversationId,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('AI Chat error:', error)
    return c.json({ 
      error: error.message || 'Failed to process AI chat request',
      fallback: "I'm having trouble connecting to my AI brain right now. Please try asking your question again, or check out our comprehensive visa guides in the meantime!"
    }, 500)
  }
})

// AI Eligibility Assessment Endpoint
aiApp.post('/ai-eligibility', async (c) => {
  try {
    const { visaRoute, answers, userProfile = {} } = await c.req.json()
    
    if (!visaRoute || !answers) {
      return c.json({ error: 'Visa route and answers are required' }, 400)
    }

    console.log('AI Eligibility assessment:', { visaRoute: visaRoute.name, answersCount: Object.keys(answers).length })

    const eligibilityPrompt = `You are an expert UK visa consultant. Assess eligibility for the ${visaRoute.name} visa based on the user's answers.

Visa Route: ${visaRoute.name}
Description: ${visaRoute.description}
Category: ${visaRoute.category}
Difficulty: ${visaRoute.difficulty}

User's Answers:
${Object.entries(answers).map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') : value}`).join('\n')}

Provide a comprehensive assessment in JSON format:
{
  "overallScore": 85,
  "eligibilityStatus": "Strong Candidate|Good Potential|Needs Improvement|Not Eligible",
  "strengths": ["List of user's strengths for this visa"],
  "weaknesses": ["List of areas that need improvement"],
  "recommendations": ["Specific actionable steps to improve eligibility"],
  "requiredDocuments": ["List of documents they'll need"],
  "timeline": "Realistic timeline for application",
  "estimatedCost": "Total estimated cost in GBP",
  "riskFactors": ["Potential challenges or risks"],
  "nextSteps": ["Immediate next steps they should take"],
  "confidenceLevel": "High|Medium|Low",
  "additionalNotes": "Any additional important information"
}

Base your assessment on current 2025 UK visa requirements and be realistic but encouraging.`

    const messages = [
      {
        role: 'system',
        content: 'You are an expert UK immigration consultant with deep knowledge of all UK visa routes and requirements. Provide accurate, helpful assessments based on current UKVI guidelines.'
      },
      {
        role: 'user',
        content: eligibilityPrompt
      }
    ]

    const response = await callOpenAI(messages, 'gpt-4o-mini', 0.3, 2000)
    
    let assessment
    try {
      assessment = JSON.parse(response.choices[0].message.content)
    } catch (parseError) {
      console.error('Failed to parse AI assessment:', parseError)
      throw new Error('Failed to parse eligibility assessment')
    }

    // Store assessment result
    const assessmentId = `assessment:${Date.now()}_${Math.random().toString(36).slice(2)}`
    await kv.set(assessmentId, {
      visaRoute: visaRoute.name,
      answers,
      assessment,
      timestamp: new Date().toISOString(),
      type: 'eligibility_assessment'
    })

    console.log('AI Eligibility assessment completed successfully')

    return c.json({
      assessment,
      assessmentId,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('AI Eligibility error:', error)
    return c.json({ 
      error: error.message || 'Failed to process eligibility assessment',
      fallback: {
        overallScore: 0,
        eligibilityStatus: "Assessment Unavailable",
        strengths: [],
        weaknesses: ["Unable to complete AI assessment at this time"],
        recommendations: ["Please try again later or consult official UKVI guidance"],
        requiredDocuments: [],
        timeline: "Unable to determine",
        estimatedCost: "Please check UKVI website",
        riskFactors: [],
        nextSteps: ["Retry assessment or seek professional advice"],
        confidenceLevel: "Low",
        additionalNotes: "AI assessment temporarily unavailable"
      }
    }, 500)
  }
})

// AI Visa Route Recommendation Endpoint
aiApp.post('/ai-recommendations', async (c) => {
  try {
    const { userProfile, preferences = {} } = await c.req.json()
    
    if (!userProfile) {
      return c.json({ error: 'User profile is required' }, 400)
    }

    console.log('AI Recommendations request:', { profile: !!userProfile, preferences: Object.keys(preferences).length })

    const recommendationPrompt = `Based on the user's profile and preferences, recommend the most suitable UK visa routes.

User Profile:
${Object.entries(userProfile).map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') : value}`).join('\n')}

User Preferences:
${Object.entries(preferences).map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') : value}`).join('\n')}

Available UK Visa Routes:
1. Skilled Worker - For skilled workers with job offers
2. Global Talent - For exceptional individuals in tech, academia, arts
3. Student Visa - For studying at UK institutions
4. Graduate Visa - For UK degree graduates
5. UK Ancestry - For Commonwealth citizens with UK-born grandparents
6. Standard Visitor - For temporary visits
7. Family Visas - For joining family members
8. Investor/Innovator - For business investment

Provide recommendations in JSON format:
{
  "primaryRecommendations": [
    {
      "visaRoute": "Skilled Worker",
      "matchScore": 95,
      "reasoning": ["Why this is recommended"],
      "pros": ["Advantages for this user"],
      "cons": ["Potential challenges"],
      "requirements": ["Key requirements they must meet"],
      "timeline": "Expected timeline",
      "likelihood": "High|Medium|Low"
    }
  ],
  "alternativeOptions": [
    {
      "visaRoute": "Global Talent",
      "matchScore": 75,
      "reasoning": ["Why this could work"],
      "requirements": ["What they'd need to qualify"]
    }
  ],
  "notSuitable": [
    {
      "visaRoute": "UK Ancestry",
      "reason": "Why this doesn't match their profile"
    }
  ],
  "overallGuidance": "General advice and next steps",
  "confidenceLevel": "High|Medium|Low"
}`

    const messages = [
      {
        role: 'system',
        content: 'You are an expert UK immigration consultant. Analyze user profiles and recommend the most suitable visa routes based on their circumstances, qualifications, and goals.'
      },
      {
        role: 'user',
        content: recommendationPrompt
      }
    ]

    const response = await callOpenAI(messages, 'gpt-4o-mini', 0.4, 2000)
    
    let recommendations
    try {
      recommendations = JSON.parse(response.choices[0].message.content)
    } catch (parseError) {
      console.error('Failed to parse AI recommendations:', parseError)
      throw new Error('Failed to parse visa recommendations')
    }

    // Store recommendations
    const recommendationId = `recommendations:${Date.now()}_${Math.random().toString(36).slice(2)}`
    await kv.set(recommendationId, {
      userProfile,
      preferences,
      recommendations,
      timestamp: new Date().toISOString(),
      type: 'visa_recommendations'
    })

    console.log('AI Recommendations generated successfully')

    return c.json({
      recommendations,
      recommendationId,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('AI Recommendations error:', error)
    return c.json({ 
      error: error.message || 'Failed to generate visa recommendations',
      fallback: {
        primaryRecommendations: [],
        alternativeOptions: [],
        notSuitable: [],
        overallGuidance: "AI recommendations temporarily unavailable. Please consult our visa guides or try again later.",
        confidenceLevel: "Low"
      }
    }, 500)
  }
})

// Health check endpoint
aiApp.get('/ai-health', (c) => {
  return c.json({ 
    status: 'healthy', 
    openaiConfigured: !!openaiApiKey,
    timestamp: new Date().toISOString() 
  })
})

// Export as named and default export
export { aiApp as aiEndpoints }
export default aiApp