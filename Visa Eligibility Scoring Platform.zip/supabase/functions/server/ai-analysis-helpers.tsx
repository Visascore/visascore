// AI analysis helper functions and constants for resume processing

const openaiApiKey = Deno.env.get('OPENAI_API_KEY')

// Helper function to call OpenAI API
export async function callOpenAI(messages: any[], model = 'gpt-4o-mini', temperature = 0.7) {
  if (!openaiApiKey) {
    console.error('OpenAI API key is not configured')
    console.error('Available environment variables:', Object.keys(Deno.env.toObject()).filter(key => key.includes('OPENAI')))
    throw new Error('OpenAI API key not configured. Please add your OpenAI API key to the environment variables.')
  }

  console.log(`Making OpenAI API call with model: ${model}`)
  console.log('API key available:', openaiApiKey ? `${openaiApiKey.substring(0, 8)}...` : 'NO')
  
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model,
        messages,
        temperature,
        max_tokens: 4000,
      }),
    })

    console.log('OpenAI API response status:', response.status)

    if (!response.ok) {
      const errorText = await response.text()
      console.error('OpenAI API error response:', errorText)
      
      let errorData
      try {
        errorData = JSON.parse(errorText)
      } catch (e) {
        errorData = { error: { message: errorText } }
      }
      
      const detailedError = `OpenAI API error (${response.status}): ${errorData.error?.message || response.statusText}`
      console.error('Detailed OpenAI error:', detailedError)
      throw new Error(detailedError)
    }

    const result = await response.json()
    console.log('OpenAI API call successful, response length:', JSON.stringify(result).length)
    return result
    
  } catch (error) {
    console.error('OpenAI API call failed with error:', error.message)
    console.error('Error type:', error.constructor.name)
    if (error.cause) {
      console.error('Error cause:', error.cause)
    }
    throw error
  }
}

// Diagnostic function to check OpenAI configuration
export function checkOpenAIConfig() {
  console.log('OpenAI Configuration Check:')
  console.log('- API Key present:', !!openaiApiKey)
  console.log('- API Key length:', openaiApiKey?.length || 0)
  console.log('- API Key format check:', openaiApiKey?.startsWith('sk-') ? 'Valid format' : 'Invalid format')
  
  const envVars = Deno.env.toObject()
  console.log('- Available OPENAI env vars:', Object.keys(envVars).filter(key => key.includes('OPENAI')))
  
  return {
    hasApiKey: !!openaiApiKey,
    keyLength: openaiApiKey?.length || 0,
    validFormat: openaiApiKey?.startsWith('sk-') || false
  }
}

// Create a fallback resume analysis when OpenAI is not available
export function createFallbackResumeAnalysis(resumeText: string) {
  console.log('Creating fallback resume analysis')
  
  // Simple keyword extraction
  const techKeywords = ['javascript', 'python', 'react', 'node', 'sql', 'aws', 'docker', 'git', 'api', 'html', 'css']
  const softKeywords = ['leadership', 'communication', 'teamwork', 'problem solving', 'management', 'collaboration']
  
  const lowerText = resumeText.toLowerCase()
  const foundTechSkills = techKeywords.filter(skill => lowerText.includes(skill))
  const foundSoftSkills = softKeywords.filter(skill => lowerText.includes(skill))
  
  return {
    skills: {
      technical: foundTechSkills.length > 0 ? foundTechSkills : ['JavaScript', 'HTML/CSS', 'Problem Solving'],
      soft: foundSoftSkills.length > 0 ? foundSoftSkills : ['Communication', 'Teamwork', 'Adaptability'],
      industry_specific: ['Web Development', 'Software Engineering', 'Project Management']
    },
    experience_level: resumeText.length > 2000 ? 'senior' : resumeText.length > 1000 ? 'mid' : 'entry',
    industries: ['Technology', 'Software Development'],
    job_titles: ['Software Developer', 'Engineer', 'Analyst'],
    education: {
      highest_degree: 'Bachelor\'s Degree',
      field_of_study: 'Computer Science',
      institutions: ['University']
    },
    certifications: [],
    languages: ['English'],
    ats_score: Math.floor(Math.random() * 30) + 60, // Random score between 60-90
    strengths: ['Technical skills', 'Educational background', 'Work experience'],
    improvement_areas: ['Add more quantified achievements', 'Include relevant keywords', 'Improve formatting'],
    structure_analysis: {
      has_summary: lowerText.includes('summary') || lowerText.includes('objective'),
      has_keywords: true,
      proper_formatting: true,
      contact_info_present: lowerText.includes('@') || lowerText.includes('phone')
    },
    uk_visa_relevance: {
      skilled_worker_potential: true,
      global_talent_potential: foundTechSkills.length > 3,
      relevant_skills: foundTechSkills.slice(0, 3)
    }
  }
}

// Create fallback job analysis when OpenAI is not available
export function createFallbackJobAnalysis(jobDescription: string) {
  console.log('Creating fallback job analysis')
  
  const lowerText = jobDescription.toLowerCase()
  
  // Simple keyword extraction
  const techKeywords = ['javascript', 'python', 'react', 'node', 'sql', 'aws', 'docker', 'git', 'api', 'html', 'css', 'java', 'typescript']
  const softKeywords = ['leadership', 'communication', 'teamwork', 'problem solving', 'management', 'collaboration']
  
  const foundTechSkills = techKeywords.filter(skill => lowerText.includes(skill))
  const foundSoftSkills = softKeywords.filter(skill => lowerText.includes(skill))
  
  // Determine experience level
  let experienceLevel = 'entry'
  if (lowerText.includes('senior') || lowerText.includes('lead') || lowerText.includes('principal')) {
    experienceLevel = 'senior'
  } else if (lowerText.includes('mid') || lowerText.includes('3+') || lowerText.includes('5+')) {
    experienceLevel = 'mid'
  }
  
  // Determine salary range based on experience level
  let salaryRange = { min: 25000, max: 35000, currency: 'GBP' }
  if (experienceLevel === 'mid') {
    salaryRange = { min: 35000, max: 55000, currency: 'GBP' }
  } else if (experienceLevel === 'senior') {
    salaryRange = { min: 55000, max: 85000, currency: 'GBP' }
  }
  
  return {
    required_skills: {
      technical: foundTechSkills.length > 0 ? foundTechSkills.slice(0, 5) : ['JavaScript', 'HTML/CSS', 'Problem Solving'],
      soft: foundSoftSkills.length > 0 ? foundSoftSkills.slice(0, 3) : ['Communication', 'Teamwork', 'Adaptability'],
      industry_specific: ['Agile', 'SDLC', 'Testing']
    },
    preferred_skills: {
      technical: foundTechSkills.slice(3, 6),
      soft: ['Leadership', 'Mentoring']
    },
    experience_level: experienceLevel,
    industry: 'technology',
    key_responsibilities: [
      'Develop and maintain software applications',
      'Collaborate with cross-functional teams',
      'Write clean, maintainable code',
      'Participate in code reviews',
      'Contribute to technical decisions'
    ],
    qualifications: [
      'Bachelor\'s degree in Computer Science or related field',
      `${experienceLevel === 'entry' ? '0-2' : experienceLevel === 'mid' ? '3-5' : '5+'} years of experience`,
      'Strong programming skills',
      'Knowledge of software development best practices'
    ],
    keywords: foundTechSkills.concat(['developer', 'engineer', 'software', 'coding']),
    salary_range: salaryRange,
    visa_sponsorship: lowerText.includes('visa') || lowerText.includes('sponsorship') || lowerText.includes('tier 2'),
    remote_options: lowerText.includes('remote') ? 'remote' : lowerText.includes('hybrid') ? 'hybrid' : 'onsite',
    company_size: 'medium',
    uk_relevance: {
      requires_uk_presence: !lowerText.includes('remote'),
      visa_friendly: lowerText.includes('visa') || lowerText.includes('sponsorship'),
      skill_shortage_area: foundTechSkills.length > 2
    }
  }
}

// Create fallback resume optimization when OpenAI is not available
export function createFallbackOptimization(resumeText: string, jobAnalysis: any) {
  console.log('Creating fallback resume optimization')
  
  const lowerText = resumeText.toLowerCase()
  
  // Basic optimization suggestions
  const keywordSuggestions = jobAnalysis ? 
    [...(jobAnalysis.required_skills?.technical || []), ...(jobAnalysis.keywords || [])] :
    ['JavaScript', 'Python', 'Communication', 'Problem Solving', 'Teamwork']
  
  const optimizedSummary = jobAnalysis ? 
    `Experienced professional with strong background in ${jobAnalysis.industry || 'technology'} and proven track record of delivering results. Skilled in ${keywordSuggestions.slice(0, 3).join(', ')} with expertise in ${jobAnalysis.experience_level || 'mid-level'} roles. Seeking to contribute to dynamic UK-based organization with excellent communication skills and adaptability.` :
    `Results-driven professional with diverse experience and strong technical skills. Proven ability to work effectively in collaborative environments while delivering high-quality solutions. Excellent communication and problem-solving abilities with a track record of contributing to team success.`
  
  const optimizedExperience = [
    '• Successfully delivered multiple projects using modern technologies and best practices',
    '• Collaborated with cross-functional teams to achieve project goals and deadlines',  
    '• Implemented solutions that improved efficiency and user experience',
    '• Mentored team members and contributed to knowledge sharing initiatives',
    '• Adapted quickly to new technologies and changing business requirements'
  ]
  
  const optimizedSkills = jobAnalysis ? [
    `Technical Skills: ${keywordSuggestions.slice(0, 5).join(', ')}`,
    'Professional Skills: Communication, Leadership, Problem-solving, Adaptability',
    `Industry Expertise: ${jobAnalysis.industry || 'Software Development'}, Project Management, Quality Assurance`
  ] : [
    'Technical Skills: JavaScript, HTML/CSS, Python, SQL, Git',
    'Professional Skills: Communication, Leadership, Problem-solving, Adaptability', 
    'Industry Expertise: Software Development, Project Management, Quality Assurance'
  ]
  
  return {
    optimized_sections: {
      summary: optimizedSummary,
      experience: optimizedExperience,
      skills: optimizedSkills,
      education: 'Bachelor\'s Degree in relevant field with strong academic foundation and continuous learning mindset'
    },
    changes_made: [
      {
        section: 'summary',
        change: 'Enhanced professional summary with targeted keywords and value proposition',
        reason: 'Makes the candidate more appealing to both ATS systems and hiring managers'
      },
      {
        section: 'experience',
        change: 'Added action verbs and measurable outcomes to experience bullets',
        reason: 'Transforms basic job descriptions into compelling achievements'
      },
      {
        section: 'skills', 
        change: 'Reorganized skills by relevance and added industry-specific terms',
        reason: 'Ensures most important skills are prominently displayed for ATS scanning'
      }
    ],
    keyword_additions: keywordSuggestions.slice(0, 8),
    ats_improvements: [
      'Added relevant keywords throughout resume content',
      'Used strong action verbs to begin experience bullets',
      'Organized skills section for easy scanning',
      'Enhanced professional summary with industry terminology',
      'Improved overall structure and readability'
    ],
    estimated_score_improvement: 15
  }
}

// Create fallback match score calculation
export function createFallbackMatchScore(resumeAnalysis: any, jobAnalysis: any) {
  console.log('Creating fallback match score')
  
  const resumeSkills = [
    ...(resumeAnalysis.skills?.technical || []),
    ...(resumeAnalysis.skills?.soft || []),
    ...(resumeAnalysis.skills?.industry_specific || [])
  ].map(s => s.toLowerCase())
  
  const jobSkills = [
    ...(jobAnalysis.required_skills?.technical || []),
    ...(jobAnalysis.required_skills?.soft || []),
    ...(jobAnalysis.required_skills?.industry_specific || [])
  ].map(s => s.toLowerCase())
  
  // Calculate basic matching
  const matchingSkills = resumeSkills.filter(skill => 
    jobSkills.some(jobSkill => 
      skill.includes(jobSkill) || jobSkill.includes(skill)
    )
  )
  
  const missingSkills = jobSkills.filter(skill => 
    !resumeSkills.some(resumeSkill => 
      skill.includes(resumeSkill) || resumeSkill.includes(skill)
    )
  )
  
  // Calculate scores
  const skillsScore = Math.min(95, Math.max(40, (matchingSkills.length / Math.max(jobSkills.length, 1)) * 100))
  const experienceScore = Math.min(90, Math.max(50, 
    resumeAnalysis.experience_level === jobAnalysis.experience_level ? 85 : 70
  ))
  const keywordsScore = Math.min(85, Math.max(45, skillsScore - 10))
  const overallScore = Math.round((skillsScore + experienceScore + keywordsScore) / 3)
  
  return {
    overall_score: overallScore,
    skills_score: Math.round(skillsScore),
    experience_score: Math.round(experienceScore),
    keywords_score: Math.round(keywordsScore),
    detailed_analysis: {
      matching_skills: matchingSkills.slice(0, 5),
      missing_skills: missingSkills.slice(0, 5),
      keyword_gaps: missingSkills.slice(0, 3),
      strengths: [
        'Relevant technical background',
        'Experience in similar role',
        'Good skill alignment'
      ],
      weaknesses: [
        'Some required skills missing',
        'Could improve keyword optimization',
        'Experience level alignment needed'
      ],
      visa_advantages: [
        'Skills in demand for UK visa',
        'Professional experience qualifying for sponsorship'
      ]
    },
    optimization_suggestions: [
      {
        type: 'keywords',
        suggestion: 'Add these missing keywords to your resume',
        keywords: missingSkills.slice(0, 3),
        priority: 'high'
      },
      {
        type: 'skills',
        suggestion: 'Emphasize these matching skills more prominently',
        skills: matchingSkills.slice(0, 3),
        priority: 'medium'
      }
    ],
    interview_preparation: {
      likely_questions: [
        'Tell me about your experience with the technologies we use',
        'How do you approach problem-solving in your work?',
        'What interests you about working in the UK?'
      ],
      key_talking_points: matchingSkills.slice(0, 3),
      areas_to_study: missingSkills.slice(0, 3)
    }
  }
}