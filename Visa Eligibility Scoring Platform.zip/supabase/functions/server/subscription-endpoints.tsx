import { Hono } from 'npm:hono';
import { createClient } from 'jsr:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const subscriptionApp = new Hono();

// Create Supabase client with service role key
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Helper function to authenticate user from token
async function authenticateUser(token: string) {
  try {
    // Create a temporary client with the user's JWT token
    const tempClient = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      {
        global: {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      }
    )
    
    // Get user from the JWT token
    const { data: { user }, error } = await tempClient.auth.getUser(token)
    
    if (error) {
      console.error('Token verification error:', error)
      return { user: null, error }
    }
    
    if (!user) {
      console.error('No user found in token')
      return { user: null, error: new Error('No user found') }
    }
    
    console.log('Successfully authenticated user:', user.id)
    return { user, error: null }
  } catch (error) {
    console.error('Authentication error:', error)
    return { user: null, error }
  }
}

// Start free trial
subscriptionApp.post('/start-trial', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'Authorization required' }, 401);
    }

    const { user, error: authError } = await authenticateUser(accessToken);
    if (authError || !user) {
      console.error('Auth error in start-trial:', authError);
      return c.json({ error: 'Invalid token' }, 401);
    }

    const body = await c.req.json();
    const { card_details } = body;

    // Check if user has already used their free trial
    const existingProfile = await kv.get(`user_profile:${user.id}`);
    if (existingProfile?.has_used_trial) {
      return c.json({ error: 'Free trial already used' }, 400);
    }

    // Check if user already has an active subscription
    const existingSubscription = await kv.get(`subscription:${user.id}`);
    if (existingSubscription && ['trial', 'active'].includes(existingSubscription.status)) {
      return c.json({ error: 'User already has an active subscription' }, 400);
    }

    const now = new Date();
    const trialEnd = new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000); // 2 days from now

    // Create subscription record
    const subscription = {
      id: crypto.randomUUID(),
      user_id: user.id,
      status: 'trial',
      plan: 'Monthly Plan',
      amount: 6.99,
      currency: 'GBP',
      trial_start: now.toISOString(),
      trial_end: trialEnd.toISOString(),
      card_last_four: card_details.last_four,
      card_brand: card_details.brand,
      cardholder_name: card_details.cardholder_name,
      billing_address: card_details.billing_address,
      created_at: now.toISOString(),
      updated_at: now.toISOString()
    };

    // Save subscription
    await kv.set(`subscription:${user.id}`, subscription);

    // Update user profile to mark trial as used
    const userProfile = existingProfile || {
      user_id: user.id,
      name: user.user_metadata?.name || '',
      email: user.email,
      completed_onboarding: false,
      created_at: now.toISOString()
    };

    userProfile.has_used_trial = true;
    userProfile.updated_at = now.toISOString();

    await kv.set(`user_profile:${user.id}`, userProfile);

    console.log(`Free trial started for user ${user.id}`);

    return c.json({
      message: 'Free trial started successfully',
      subscription: {
        ...subscription,
        days_remaining: 2,
        is_expired: false
      }
    });

  } catch (error) {
    console.error('Error starting free trial:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Get subscription status
subscriptionApp.get('/subscription', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'Authorization required' }, 401);
    }

    const { user, error: authError } = await authenticateUser(accessToken);
    if (authError || !user) {
      console.error('Auth error in get subscription:', authError);
      return c.json({ error: 'Invalid token' }, 401);
    }

    const subscription = await kv.get(`subscription:${user.id}`);
    
    if (!subscription) {
      return c.json(null);
    }

    const now = new Date();
    let updatedSubscription = { ...subscription };

    // Check if trial has expired
    if (subscription.status === 'trial' && subscription.trial_end) {
      const trialEnd = new Date(subscription.trial_end);
      const isExpired = now > trialEnd;
      const daysRemaining = Math.max(0, Math.ceil((trialEnd.getTime() - now.getTime()) / (24 * 60 * 60 * 1000)));

      updatedSubscription.is_expired = isExpired;
      updatedSubscription.days_remaining = daysRemaining;

      // If trial expired, update status
      if (isExpired && subscription.status === 'trial') {
        updatedSubscription.status = 'expired';
        updatedSubscription.updated_at = now.toISOString();
        await kv.set(`subscription:${user.id}`, updatedSubscription);
      }
    }

    // Check if active subscription has ended
    if (subscription.status === 'active' && subscription.current_period_end) {
      const periodEnd = new Date(subscription.current_period_end);
      if (now > periodEnd) {
        updatedSubscription.status = 'expired';
        updatedSubscription.updated_at = now.toISOString();
        await kv.set(`subscription:${user.id}`, updatedSubscription);
      }
    }

    return c.json(updatedSubscription);

  } catch (error) {
    console.error('Error getting subscription:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Update subscription (after successful payment)
subscriptionApp.post('/update-subscription', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'Authorization required' }, 401);
    }

    const { user, error: authError } = await authenticateUser(accessToken);
    if (authError || !user) {
      console.error('Auth error in update subscription:', authError);
      return c.json({ error: 'Invalid token' }, 401);
    }

    const body = await c.req.json();
    const { payment_status, payment_id, subscription_details } = body;

    if (payment_status !== 'completed') {
      return c.json({ error: 'Payment not completed' }, 400);
    }

    const existingSubscription = await kv.get(`subscription:${user.id}`);
    if (!existingSubscription) {
      return c.json({ error: 'No subscription found' }, 404);
    }

    const now = new Date();
    const periodStart = now;
    const periodEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // 30 days from now

    const updatedSubscription = {
      ...existingSubscription,
      status: 'active',
      current_period_start: periodStart.toISOString(),
      current_period_end: periodEnd.toISOString(),
      payment_id: payment_id,
      cancel_at_period_end: false,
      updated_at: now.toISOString(),
      ...subscription_details
    };

    await kv.set(`subscription:${user.id}`, updatedSubscription);

    console.log(`Subscription activated for user ${user.id}`);

    return c.json({
      message: 'Subscription updated successfully',
      subscription: updatedSubscription
    });

  } catch (error) {
    console.error('Error updating subscription:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Cancel subscription
subscriptionApp.post('/cancel-subscription', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'Authorization required' }, 401);
    }

    const { user, error: authError } = await authenticateUser(accessToken);
    if (authError || !user) {
      console.error('Auth error in cancel subscription:', authError);
      return c.json({ error: 'Invalid token' }, 401);
    }

    const subscription = await kv.get(`subscription:${user.id}`);
    if (!subscription) {
      return c.json({ error: 'No subscription found' }, 404);
    }

    if (subscription.status !== 'active') {
      return c.json({ error: 'Subscription is not active' }, 400);
    }

    const now = new Date();
    
    // Mark subscription for cancellation at period end
    const updatedSubscription = {
      ...subscription,
      cancel_at_period_end: true,
      canceled_at: now.toISOString(),
      updated_at: now.toISOString()
    };

    await kv.set(`subscription:${user.id}`, updatedSubscription);

    console.log(`Subscription canceled for user ${user.id} - will end at ${subscription.current_period_end}`);

    return c.json({
      message: 'Subscription canceled successfully',
      subscription: updatedSubscription
    });

  } catch (error) {
    console.error('Error canceling subscription:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Check access (used by middleware)
subscriptionApp.get('/check-access', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ has_access: false, reason: 'No token provided' });
    }

    const { user, error: authError } = await authenticateUser(accessToken);
    if (authError || !user) {
      console.error('Auth error in check access:', authError);
      return c.json({ has_access: false, reason: 'Invalid token' });
    }

    const subscription = await kv.get(`subscription:${user.id}`);
    
    if (!subscription) {
      return c.json({ 
        has_access: false, 
        reason: 'No subscription found',
        can_start_trial: true 
      });
    }

    const now = new Date();

    // Check trial access
    if (subscription.status === 'trial') {
      const trialEnd = new Date(subscription.trial_end);
      const isExpired = now > trialEnd;
      
      if (!isExpired) {
        return c.json({ 
          has_access: true, 
          subscription_status: 'trial',
          days_remaining: Math.max(0, Math.ceil((trialEnd.getTime() - now.getTime()) / (24 * 60 * 60 * 1000)))
        });
      } else {
        // Update expired trial
        await kv.set(`subscription:${user.id}`, {
          ...subscription,
          status: 'expired',
          is_expired: true,
          updated_at: now.toISOString()
        });
        return c.json({ 
          has_access: false, 
          reason: 'Trial expired',
          subscription_status: 'expired'
        });
      }
    }

    // Check active subscription
    if (subscription.status === 'active') {
      if (subscription.current_period_end) {
        const periodEnd = new Date(subscription.current_period_end);
        if (now <= periodEnd) {
          return c.json({ 
            has_access: true, 
            subscription_status: 'active',
            cancel_at_period_end: subscription.cancel_at_period_end || false
          });
        } else {
          // Update expired subscription
          await kv.set(`subscription:${user.id}`, {
            ...subscription,
            status: 'expired',
            updated_at: now.toISOString()
          });
          return c.json({ 
            has_access: false, 
            reason: 'Subscription expired',
            subscription_status: 'expired'
          });
        }
      }
    }

    return c.json({ 
      has_access: false, 
      reason: 'Invalid subscription status',
      subscription_status: subscription.status
    });

  } catch (error) {
    console.error('Error checking access:', error);
    return c.json({ has_access: false, reason: 'Internal server error' });
  }
});

export default subscriptionApp;