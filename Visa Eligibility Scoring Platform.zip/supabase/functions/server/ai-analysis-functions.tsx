// AI analysis functions for resume and job processing
import { callOpenAI, createFallbackResumeAnalysis, createFallbackJobAnalysis, createFallbackMatchScore, createFallbackOptimization } from './ai-analysis-helpers.tsx'

// Helper function to clean and parse AI responses that may contain markdown
function cleanAndParseJSON(response: string): any {
  try {
    // First try to parse as-is
    return JSON.parse(response)
  } catch (error) {
    console.log('Initial JSON parse failed, attempting to clean response...')
    
    try {
      // Remove markdown code blocks if present
      let cleanedResponse = response.trim()
      
      // Remove various markdown code block patterns
      if (cleanedResponse.includes('```json')) {
        cleanedResponse = cleanedResponse.replace(/```json\s*/g, '').replace(/\s*```/g, '')
      } else if (cleanedResponse.includes('```')) {
        cleanedResponse = cleanedResponse.replace(/```\s*/g, '').replace(/\s*```/g, '')
      }
      
      // Remove any leading/trailing text that isn't part of JSON
      const jsonStartIndex = cleanedResponse.indexOf('{')
      const jsonEndIndex = cleanedResponse.lastIndexOf('}')
      
      if (jsonStartIndex !== -1 && jsonEndIndex !== -1 && jsonEndIndex > jsonStartIndex) {
        cleanedResponse = cleanedResponse.substring(jsonStartIndex, jsonEndIndex + 1)
      }
      
      // Clean up common formatting issues
      cleanedResponse = cleanedResponse
        .replace(/\n\s*\/\/.*$/gm, '') // Remove comments
        .replace(/,\s*}/g, '}') // Remove trailing commas
        .replace(/,\s*]/g, ']') // Remove trailing commas in arrays
        .trim()
      
      console.log('Attempting to parse cleaned response...')
      return JSON.parse(cleanedResponse)
    } catch (secondError) {
      console.error('Failed to parse JSON after cleaning:', secondError)
      console.error('Original response length:', response.length)
      console.error('Original response preview:', response.substring(0, 500))
      
      // Try one more time with a more aggressive approach
      try {
        const jsonMatch = response.match(/\{[\s\S]*\}/g)
        if (jsonMatch && jsonMatch.length > 0) {
          // Take the largest JSON-like structure
          const largestMatch = jsonMatch.reduce((a, b) => a.length > b.length ? a : b)
          console.log('Attempting to parse largest JSON match...')
          return JSON.parse(largestMatch)
        }
      } catch (thirdError) {
        console.error('All JSON parsing attempts failed:', thirdError)
      }
      
      throw new Error('Unable to parse AI response as JSON after multiple attempts')
    }
  }
}

// Analyze resume with enhanced AI evaluation
export async function analyzeResumeWithAI(resumeText: string) {
  try {
    const prompt = `
You are an expert AI resume analyzer with deep expertise in UK job market trends, ATS optimization, visa requirements, and career development. 

Perform a comprehensive analysis of this resume, extracting and evaluating all relevant information for job matching and career optimization.

**ANALYSIS REQUIREMENTS:**
- Extract all technical and soft skills with proficiency context
- Determine accurate experience level based on roles and responsibilities
- Assess ATS compatibility and keyword optimization
- Evaluate UK visa sponsorship potential
- Identify career trajectory and growth indicators
- Analyze competitive positioning in current market

IMPORTANT: Return ONLY valid JSON with no markdown formatting, code blocks, or additional text. Do not wrap your response in \`\`\`json or \`\`\` blocks.

Return your analysis as JSON in this exact format:

{
  "skills": {
    "technical": ["List all technical skills found - be comprehensive"],
    "soft": ["List all soft skills and leadership qualities"],
    "industry_specific": ["Domain-specific skills and knowledge areas"],
    "emerging_tech": ["Any cutting-edge technologies or methodologies"],
    "certifications_skills": ["Skills evidenced by certifications"]
  },
  "experience_analysis": {
    "level": "entry|mid|senior|executive",
    "years_total": 5,
    "years_relevant": 3,
    "career_progression": "upward|lateral|mixed|unclear",
    "leadership_experience": true,
    "international_experience": false,
    "remote_work_experience": true
  },
  "industries": ["List all industries candidate has worked in"],
  "job_titles": ["All job titles held by candidate"],
  "education": {
    "highest_degree": "string",
    "field_of_study": "string",
    "institutions": ["school1", "school2"],
    "graduation_year": "YYYY or null",
    "relevant_coursework": ["relevant courses"],
    "academic_achievements": ["honors, gpa, etc."]
  },
  "certifications": ["List all certifications with issuing bodies"],
  "languages": ["All languages with proficiency levels"],
  "achievements": {
    "quantified_results": ["Specific measurable achievements"],
    "awards_recognition": ["Any awards or recognition"],
    "publications_patents": ["Academic or professional publications"],
    "projects": ["Notable projects with impact"]
  },
  "ats_analysis": {
    "score": 85,
    "keyword_density": "appropriate|low|high",
    "format_compatibility": "excellent|good|fair|poor",
    "section_organization": "logical|confusing|missing_key_sections",
    "contact_info_quality": "complete|incomplete|missing"
  },
  "strengths": ["Detailed list of candidate's key strengths"],
  "improvement_areas": ["Specific areas for resume improvement"],
  "market_positioning": {
    "competitiveness": "highly_competitive|competitive|average|below_average",
    "unique_value_proposition": "What makes this candidate stand out",
    "salary_range_estimate": {"min": 40000, "max": 60000, "currency": "GBP"},
    "target_companies": ["Types of companies that would be interested"]
  },
  "uk_visa_analysis": {
    "skilled_worker_eligibility": true,
    "global_talent_potential": false,
    "shortage_occupation_match": false,
    "salary_threshold_likelihood": "likely|possible|unlikely",
    "relevant_skills_for_sponsorship": ["skills that support visa application"],
    "visa_route_recommendations": ["Most suitable visa routes"]
  },
  "career_development": {
    "growth_trajectory": "rapid|steady|stagnant",
    "skill_gaps": ["Skills needed for next career level"],
    "recommended_next_roles": ["Logical next career steps"],
    "industry_transition_potential": ["Industries candidate could transition to"]
  }
}

**RESUME TEXT TO ANALYZE:**
${resumeText}

**CONTEXT:**
- Current UK job market: Skills shortage in tech, healthcare, engineering
- Visa requirements: £41,700+ salary threshold, approved sponsor needed
- ATS trends: Keyword optimization crucial, clean formatting preferred
- Market competition: High demand for experienced professionals with proven results

Provide a thorough, professional analysis that maximizes the candidate's potential for job matching and career success.
`

    const messages = [
      {
        role: 'system',
        content: 'You are a world-class AI resume analyzer and career strategist with expertise in UK employment market, ATS systems, visa regulations, and talent acquisition. You provide comprehensive, actionable insights that help candidates optimize their career prospects and help employers identify top talent. Your analysis is detailed, accurate, and forward-thinking. CRITICAL: Always return responses as valid JSON only, without any markdown formatting, code blocks, or additional text.'
      },
      {
        role: 'user',
        content: prompt
      }
    ]

    console.log('Calling OpenAI for enhanced resume analysis...')
    const response = await callOpenAI(messages, 'gpt-4o', 0.2)
    
    try {
      const analysis = cleanAndParseJSON(response.choices[0].message.content)
      console.log('Enhanced resume analysis completed successfully')
      return analysis
    } catch (parseError) {
      console.error('Failed to parse enhanced resume analysis:', parseError)
      console.log('Raw AI response:', response.choices[0].message.content)
      throw new Error('Failed to parse AI response')
    }
    
  } catch (error) {
    console.error('OpenAI enhanced resume analysis failed, using fallback:', error)
    // Return fallback analysis if OpenAI fails
    return createFallbackResumeAnalysis(resumeText)
  }
}

// Analyze job description with enhanced AI evaluation  
export async function analyzeJobWithAI(jobDescription: string) {
  try {
    const prompt = `
You are an expert AI recruitment analyst with deep expertise in UK job market analysis, talent acquisition, visa sponsorship requirements, and employment law.

Perform a comprehensive analysis of this job description, extracting all relevant information for candidate matching and recruitment optimization.

**ANALYSIS REQUIREMENTS:**
- Identify all skill requirements with priority levels
- Determine accurate experience and seniority expectations
- Extract compensation and benefits information
- Assess visa sponsorship potential and requirements
- Evaluate company culture and work environment indicators
- Identify growth and development opportunities

IMPORTANT: Return ONLY valid JSON with no markdown formatting, code blocks, or additional text. Do not wrap your response in \`\`\`json or \`\`\` blocks.

Return your analysis as JSON in this exact format:

{
  "role_overview": {
    "title": "Exact job title",
    "department": "Department or team",
    "reporting_structure": "Who this role reports to",
    "team_size": "Size of team this role joins/manages",
    "role_type": "permanent|contract|temporary|freelance"
  },
  "required_skills": {
    "technical": ["Must-have technical skills"],
    "soft": ["Essential soft skills and qualities"],
    "industry_specific": ["Domain-specific knowledge required"],
    "tools_platforms": ["Specific tools, software, platforms"],
    "methodologies": ["Agile, DevOps, etc."]
  },
  "preferred_skills": {
    "technical": ["Nice-to-have technical skills"],
    "soft": ["Additional beneficial qualities"],
    "bonus_qualifications": ["Additional certifications or experience"]
  },
  "experience_requirements": {
    "level": "entry|mid|senior|executive|lead",
    "years_required": 5,
    "years_preferred": 7,
    "specific_experience": ["Specific types of experience valued"],
    "leadership_required": false,
    "industry_experience": ["Relevant industry backgrounds"]
  },
  "education_qualifications": {
    "minimum_education": "High school|Bachelor|Master|PhD|Professional",
    "preferred_fields": ["Computer Science", "Engineering"],
    "certifications_required": ["Required professional certifications"],
    "certifications_preferred": ["Preferred certifications"]
  },
  "responsibilities": {
    "primary": ["Core job responsibilities"],
    "secondary": ["Additional duties"],
    "growth_opportunities": ["Areas for professional development"],
    "collaboration": ["Teams and stakeholders to work with"]
  },
  "company_analysis": {
    "size": "startup|small|medium|large|enterprise",
    "industry": "Primary industry sector",
    "culture_indicators": ["Cultural values and work style indicators"],
    "growth_stage": "early_stage|scaling|established|mature",
    "technology_stack": ["Technologies the company uses"]
  },
  "compensation_benefits": {
    "salary_range": {
      "min": 40000,
      "max": 60000,
      "currency": "GBP",
      "confidence": "high|medium|low"
    },
    "benefits": ["List of benefits mentioned"],
    "equity_options": false,
    "bonus_structure": "Details about bonus/commission",
    "professional_development": ["Learning and development opportunities"]
  },
  "work_arrangement": {
    "location": "Specific location or remote",
    "remote_options": "remote|hybrid|onsite",
    "travel_requirements": "Percentage or description",
    "working_hours": "Standard hours or flexibility",
    "timezone_requirements": "Any timezone constraints"
  },
  "visa_sponsorship_analysis": {
    "sponsorship_available": true,
    "sponsorship_likelihood": "high|medium|low",
    "salary_meets_threshold": true,
    "skilled_worker_eligible": true,
    "shortage_occupation": false,
    "sponsorship_evidence": ["Text that indicates sponsorship willingness"]
  },
  "application_process": {
    "urgency": "urgent|normal|flexible",
    "selection_criteria": ["How candidates will be evaluated"],
    "interview_process": ["Expected interview stages"],
    "start_date": "Immediate|flexible|specific_date"
  },
  "market_competitiveness": {
    "demand_level": "high|medium|low",
    "skill_scarcity": "rare|competitive|common",
    "career_growth_potential": "excellent|good|limited",
    "industry_outlook": "growing|stable|declining"
  },
  "red_flags": ["Any concerning aspects of the posting"],
  "opportunity_highlights": ["Most attractive aspects of the role"]
}

**JOB DESCRIPTION TO ANALYZE:**
${jobDescription}

**CONTEXT:**
- UK visa sponsorship requires £41,700+ salary threshold for most roles
- Current skills shortages: Tech, healthcare, engineering, skilled trades
- ATS optimization: Many employers use automated screening
- Market trends: Remote/hybrid work increasingly common post-pandemic

Provide a thorough, professional analysis that enables accurate candidate matching and informed decision-making.
`

    const messages = [
      {
        role: 'system',
        content: 'You are a world-class AI recruitment analyst and job market expert with comprehensive knowledge of UK employment landscape, visa regulations, talent acquisition strategies, and hiring best practices. You provide detailed, accurate job analysis that helps match the right candidates to the right opportunities while ensuring compliance with UK employment law and visa requirements. CRITICAL: Always return responses as valid JSON only, without any markdown formatting, code blocks, or additional text.'
      },
      {
        role: 'user',
        content: prompt
      }
    ]

    console.log('Calling OpenAI for enhanced job analysis...')
    const response = await callOpenAI(messages, 'gpt-4o', 0.2)
    
    try {
      const analysis = cleanAndParseJSON(response.choices[0].message.content)
      console.log('Enhanced job analysis completed successfully')
      return analysis
    } catch (parseError) {
      console.error('Failed to parse enhanced job analysis:', parseError)
      console.log('Raw AI response:', response.choices[0].message.content)
      throw new Error('Failed to parse AI response')
    }
    
  } catch (error) {
    console.error('OpenAI enhanced job analysis failed, using fallback:', error)
    // Return fallback analysis if OpenAI fails
    return createFallbackJobAnalysis(jobDescription)
  }
}

// Calculate match score between resume and job with enhanced AI analysis
export async function calculateMatchScore(resumeAnalysis: any, jobAnalysis: any) {
  try {
    const prompt = `
You are an expert AI career consultant and recruiter with deep expertise in UK job market analysis, visa requirements, and ATS systems. 

Perform a comprehensive analysis comparing this candidate's resume with the job requirements. Provide detailed, actionable insights that consider:

1. Technical and soft skills alignment
2. Experience level compatibility
3. Industry and domain expertise match
4. Keywords and ATS optimization
5. UK visa sponsorship potential
6. Cultural and company fit indicators
7. Salary expectation alignment
8. Career progression trajectory
9. Geographic and remote work considerations
10. Professional development needs

**ANALYSIS REQUIREMENTS:**
- Use percentage scores (0-100) based on objective criteria
- Provide specific, actionable feedback
- Consider UK employment law and visa requirements
- Factor in industry standards and market demands
- Include both technical and cultural fit assessment

IMPORTANT: Return ONLY valid JSON with no markdown formatting, code blocks, or additional text. Do not wrap your response in \`\`\`json or \`\`\` blocks.

Return your analysis as JSON in this exact format:

{
  "overall_score": 85,
  "skills_score": 90,
  "experience_score": 80,
  "keywords_score": 75,
  "detailed_analysis": {
    "matching_skills": ["List specific skills that align between candidate and job"],
    "missing_skills": ["Critical skills the candidate lacks"],
    "keyword_gaps": ["Important keywords missing from resume"],
    "strengths": ["Detailed strengths that make this a good match - be specific"],
    "weaknesses": ["Specific areas that need improvement or concern"],
    "visa_advantages": ["Specific advantages for UK visa sponsorship eligibility"],
    "cultural_fit_indicators": ["Indicators of cultural and company fit"],
    "ats_compatibility": ["How well the resume would perform in ATS systems"]
  },
  "optimization_suggestions": [
    {
      "type": "keywords|skills|experience|format|content",
      "suggestion": "Specific, actionable suggestion",
      "keywords": ["specific keywords to add"],
      "skills": ["specific skills to emphasize"],
      "priority": "high|medium|low",
      "impact_score": 15,
      "implementation_effort": "low|medium|high"
    }
  ],
  "interview_preparation": {
    "likely_questions": ["Specific questions based on job requirements and candidate background"],
    "key_talking_points": ["Specific points candidate should emphasize in interview"],
    "areas_to_study": ["Technical/domain areas to brush up on"],
    "weakness_mitigation": ["How to address potential concerns"],
    "salary_negotiation_points": ["Leverage points for salary negotiation"]
  },
  "market_insights": {
    "competitive_positioning": "How competitive is this candidate in current market",
    "alternative_opportunities": ["Similar roles/companies to consider"],
    "skill_development_priorities": ["Skills to prioritize for career growth"],
    "uk_market_fit": "Assessment of fit within UK job market"
  }
}

**CANDIDATE RESUME ANALYSIS:**
${JSON.stringify(resumeAnalysis, null, 2)}

**JOB REQUIREMENTS ANALYSIS:**
${JSON.stringify(jobAnalysis, null, 2)}

**ADDITIONAL CONTEXT:**
- Current UK job market: Competitive, emphasis on skilled workers
- Visa sponsorship: Requires £41,700+ salary threshold for most roles
- ATS systems: Favor keyword-rich, well-structured resumes
- UK employers: Value cultural fit, communication skills, and adaptability

Provide a thorough, professional analysis that would help both the candidate and hiring manager make informed decisions.
`

    const messages = [
      {
        role: 'system',
        content: 'You are a world-class AI career consultant and recruitment expert specializing in UK job market analysis, talent matching, and visa requirements. You have extensive experience in ATS optimization, salary benchmarking, and career development. Your analysis helps candidates optimize their applications and helps employers find the best talent. Always provide specific, actionable insights backed by current market knowledge. CRITICAL: Always return responses as valid JSON only, without any markdown formatting, code blocks, or additional text.'
      },
      {
        role: 'user',
        content: prompt
      }
    ]

    console.log('Calling OpenAI for enhanced match analysis...')
    const response = await callOpenAI(messages, 'gpt-4o', 0.3)
    
    try {
      const analysis = cleanAndParseJSON(response.choices[0].message.content)
      console.log('Enhanced match analysis completed successfully')
      return analysis
    } catch (parseError) {
      console.error('Failed to parse enhanced match analysis:', parseError)
      console.log('Raw AI response:', response.choices[0].message.content)
      throw new Error('Failed to parse AI response')
    }
    
  } catch (error) {
    console.error('OpenAI enhanced match analysis failed, using fallback:', error)
    // Return fallback analysis if OpenAI fails
    return createFallbackMatchScore(resumeAnalysis, jobAnalysis)
  }
}

// Generate optimized resume content with enhanced AI analysis
export async function optimizeResumeWithAI(resumeText: string, jobAnalysis: any, optimizationType: string) {
  try {
    // Extract specific job requirements for targeted optimization
    const jobRequirements = jobAnalysis ? {
      requiredSkills: jobAnalysis.required_skills || {},
      preferredSkills: jobAnalysis.preferred_skills || {},
      responsibilities: jobAnalysis.responsibilities || jobAnalysis.key_responsibilities || [],
      experienceLevel: jobAnalysis.experience_level || jobAnalysis.experience_requirements?.level || 'mid',
      industry: jobAnalysis.industry || '',
      companySize: jobAnalysis.company_size || jobAnalysis.company_analysis?.size || '',
      salaryRange: jobAnalysis.salary_range || jobAnalysis.compensation_benefits?.salary_range || null,
      visaSponsorship: jobAnalysis.visa_sponsorship || jobAnalysis.visa_sponsorship_analysis?.sponsorship_available || false,
      jobTitle: jobAnalysis.title || jobAnalysis.role_overview?.title || '',
      keywords: jobAnalysis.keywords || [],
      description: jobAnalysis.description || ''
    } : null

    const prompt = `
You are an expert AI resume writer and ATS optimization specialist with deep expertise in UK hiring practices, visa requirements, and career development.

**CRITICAL MISSION:** Transform this resume into a PERFECT MATCH for this specific job by rewriting every section to directly address the job requirements.

**TARGET JOB DETAILS:**
${jobRequirements ? `
- Job Title: ${jobRequirements.jobTitle}
- Industry: ${jobRequirements.industry}
- Experience Level: ${jobRequirements.experienceLevel}
- Required Technical Skills: ${JSON.stringify(jobRequirements.requiredSkills.technical || [])}
- Required Soft Skills: ${JSON.stringify(jobRequirements.requiredSkills.soft || [])}
- Key Responsibilities: ${JSON.stringify(jobRequirements.responsibilities)}
- Visa Sponsorship Available: ${jobRequirements.visaSponsorship}
- Salary Range: ${jobRequirements.salaryRange ? `£${jobRequirements.salaryRange.min}-${jobRequirements.salaryRange.max}` : 'Not specified'}
` : 'No specific job provided - optimize for general UK market'}

**OPTIMIZATION REQUIREMENTS - MAKE EVERY WORD COUNT:**
1. **Professional Summary:** Rewrite to mirror the job title and top 3-4 requirements
2. **Experience Bullets:** Transform each bullet to showcase achievements that directly relate to job responsibilities
3. **Skills:** Prioritize and reorganize to match job requirements exactly
4. **Keywords:** Integrate ALL job-specific keywords naturally throughout
5. **ATS Optimization:** Ensure resume scores 90%+ in ATS systems for this specific role
6. **UK Market Focus:** Position candidate as ideal for UK employment and visa sponsorship

**QUALITY STANDARDS FOR THIS SPECIFIC JOB:**
- Every bullet point must relate to a job requirement or responsibility
- Use the exact terminology and keywords from the job description
- Quantify achievements that demonstrate capability for this role
- Show progression that leads logically to this next career step
- Address any experience gaps with transferable skills
- Emphasize UK-relevant experience and qualifications

IMPORTANT: Return ONLY valid JSON with no markdown formatting, code blocks, or additional text. Do not wrap your response in \`\`\`json or \`\`\` blocks.

Return your optimization as JSON in this exact format:

{
  "optimized_sections": {
    "summary": "Compelling 3-4 line professional summary that EXACTLY mirrors the job title and requirements, positioned for this specific role",
    "experience": [
      "• [Achievement that directly relates to a key job responsibility] using [specific tools/skills mentioned in job]",
      "• [Quantified result that demonstrates capability for main job function] resulting in [business impact]",
      "• [Leadership/project example that shows readiness for this role's seniority level] with [relevant methodology from job]"
    ],
    "skills": [
      "PRIMARY TECHNICAL SKILLS (matching job requirements): [Exact skills from job posting in priority order]",
      "SECONDARY TECHNICAL SKILLS (supporting capabilities): [Additional relevant skills]", 
      "PROFESSIONAL COMPETENCIES (soft skills from job): [Communication, leadership, etc. as specified in job]",
      "INDUSTRY EXPERTISE: [Domain knowledge specific to this industry/role]"
    ],
    "education": "Education section optimized to highlight qualifications most relevant to this specific role and UK employment"
  },
  "changes_made": [
    {
      "section": "summary",
      "change": "Completely rewrote professional summary to mirror the exact job title and top requirements",
      "reason": "Creates immediate connection between candidate profile and job needs - critical for ATS and recruiter screening"
    },
    {
      "section": "experience", 
      "change": "Transformed all experience bullets to directly address job responsibilities and requirements",
      "reason": "Shows clear evidence that candidate can perform the specific duties outlined in the job description"
    },
    {
      "section": "skills",
      "change": "Reorganized skills in exact priority order based on job requirements, using job-specific terminology",
      "reason": "Maximizes ATS keyword matching and shows hiring manager that candidate has precisely what they need"
    }
  ],
  "keyword_additions": ["Specific keywords from job description that were strategically added throughout resume"],
  "ats_improvements": [
    "Achieved 95%+ keyword match with job description for maximum ATS scoring",
    "Used exact terminology and phrases from job posting to trigger ATS algorithms",
    "Structured content to highlight job-specific qualifications in each section",
    "Optimized for UK ATS systems and hiring practices",
    "Enhanced visa sponsorship appeal by emphasizing relevant qualifications"
  ],
  "estimated_score_improvement": 35,
  "job_specific_optimizations": [
    "Professional summary now directly mirrors job title and industry requirements",
    "Each experience bullet addresses a specific job responsibility or requirement", 
    "Skills section prioritizes exact technical requirements mentioned in job posting",
    "Added industry-specific keywords and terminology throughout",
    "Emphasized qualifications that support UK visa sponsorship eligibility",
    "Tailored seniority level and leadership examples to match job expectations"
  ]
}

**ORIGINAL RESUME TEXT:**
${resumeText}

**DETAILED JOB-SPECIFIC REQUIREMENTS TO ADDRESS:**
${jobRequirements ? `
MUST-HAVE TECHNICAL SKILLS: ${JSON.stringify(jobRequirements.requiredSkills.technical || [])}
MUST-HAVE SOFT SKILLS: ${JSON.stringify(jobRequirements.requiredSkills.soft || [])}
NICE-TO-HAVE SKILLS: ${JSON.stringify(jobRequirements.preferredSkills || {})}
KEY RESPONSIBILITIES TO DEMONSTRATE: ${JSON.stringify(jobRequirements.responsibilities)}
INDUSTRY CONTEXT: ${jobRequirements.industry}
EXPERIENCE LEVEL EXPECTED: ${jobRequirements.experienceLevel}
COMPANY SIZE: ${jobRequirements.companySize}
` : 'GENERAL OPTIMIZATION - No specific job provided'}

**CRITICAL SUCCESS FACTORS:**
1. Resume must score 95%+ match for THIS specific job in ATS systems
2. Every section must demonstrate direct relevance to THIS role
3. Keywords must match job posting exactly (not just similar terms)
4. Experience bullets must show capability for THIS job's responsibilities
5. Skills must be prioritized exactly as they appear in job requirements
6. Professional summary must position candidate as perfect fit for THIS specific opportunity

**UK EMPLOYMENT CONTEXT:**
- Visa sponsorship threshold: £41,700+ (emphasize qualifying salary potential)
- Skills shortage areas: Tech, engineering, healthcare (leverage if applicable)
- ATS optimization crucial: 80%+ of UK employers use automated screening
- Cultural fit indicators valued: teamwork, communication, adaptability

**OPTIMIZATION TYPE:** ${optimizationType}

Transform this resume into an EXACT MATCH for the target job. Make every word work toward getting this candidate an interview for THIS specific role.
`

    const messages = [
      {
        role: 'system',
        content: 'You are a world-class resume writer and career strategist specializing in UK job market optimization. You have helped thousands of candidates secure interviews and job offers by transforming their resumes into compelling professional narratives. You understand ATS systems, UK hiring practices, visa requirements, and what makes hiring managers take notice. Your optimizations are comprehensive, impactful, and result-driven. CRITICAL: Always return responses as valid JSON only, without any markdown formatting, code blocks, or additional text.'
      },
      {
        role: 'user',
        content: prompt
      }
    ]

    console.log('Calling OpenAI for resume optimization...')
    const response = await callOpenAI(messages, 'gpt-4o', 0.4)
    
    try {
      const optimization = cleanAndParseJSON(response.choices[0].message.content)
      console.log('Resume optimization completed successfully')
      return optimization
    } catch (parseError) {
      console.error('Failed to parse resume optimization:', parseError)
      console.log('Raw AI response:', response.choices[0].message.content)
      throw new Error('Failed to parse AI optimization response')
    }
    
  } catch (error) {
    console.error('OpenAI resume optimization failed, using fallback:', error)
    // Return fallback optimization instead of throwing error
    return createFallbackOptimization(resumeText, jobAnalysis)
  }
}

// Extract text from uploaded resume file
export async function extractTextFromFile(fileBuffer: ArrayBuffer, fileType: string): Promise<string> {
  try {
    if (fileType.includes('pdf')) {
      // For PDF extraction, we'll use a simple approach
      // In production, you'd want to use a proper PDF parsing library
      const text = new TextDecoder().decode(fileBuffer)
      return text.replace(/[^\x20-\x7E\n\r]/g, '') // Basic cleanup
    } else if (fileType.includes('text') || fileType.includes('txt')) {
      return new TextDecoder().decode(fileBuffer)
    } else {
      // For DOCX and other formats, we'll expect the frontend to handle conversion
      throw new Error('Unsupported file type. Please convert to PDF or text format.')
    }
  } catch (error) {
    console.error('Text extraction error:', error)
    throw new Error('Failed to extract text from file')
  }
}