import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { authEndpoints } from './auth-endpoints.tsx';
import { chatEndpoints } from './chat-endpoints.tsx';
import { dashboardEndpoints } from './dashboard-endpoints.tsx';
import { resumeEndpoints } from './resume-endpoints.tsx';
import { aiEndpoints } from './ai-endpoints.tsx';
import { adminEndpoints } from './admin-endpoints.tsx';
import { eligibilityEndpoints } from './eligibility-endpoints.tsx';

const app = new Hono();

// Add comprehensive CORS and logging
app.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['POST', 'GET', 'PUT', 'DELETE', 'OPTIONS'],
}));

app.use('*', logger(console.log));

// Health check endpoint
app.get('/make-server-ca272e8b/health', (c) => {
  return c.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    services: ['auth', 'chat', 'dashboard', 'resume', 'ai', 'admin', 'eligibility'],
    environment: {
      openaiConfigured: !!Deno.env.get('OPENAI_API_KEY'),
      supabaseConfigured: !!Deno.env.get('SUPABASE_URL') && !!Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    }
  });
});

// Mount all endpoint groups (removed subscription endpoints)
app.route('/make-server-ca272e8b', authEndpoints);
app.route('/make-server-ca272e8b', chatEndpoints);
app.route('/make-server-ca272e8b', dashboardEndpoints);
app.route('/make-server-ca272e8b', resumeEndpoints);
app.route('/make-server-ca272e8b', aiEndpoints);
app.route('/make-server-ca272e8b', adminEndpoints);
app.route('/make-server-ca272e8b', eligibilityEndpoints);

// Global error handler
app.onError((err, c) => {
  console.error('Server error:', err);
  return c.json({ error: 'Internal server error', details: err.message }, 500);
});

// 404 handler
app.notFound((c) => {
  return c.json({ error: 'Route not found', path: c.req.path }, 404);
});

// Start server
Deno.serve(app.fetch);