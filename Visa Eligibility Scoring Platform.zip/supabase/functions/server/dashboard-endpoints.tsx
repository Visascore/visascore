import { Hono } from 'npm:hono'
import { createClient } from 'npm:@supabase/supabase-js'
import * as kv from './kv_store.tsx'
import { callOpenAI } from './ai-analysis-helpers.tsx'

const app = new Hono()

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
)

// Generate AI-powered daily tasks
app.post('/generate-daily-tasks', async (c) => {
  try {
    const { userId, userProfile } = await c.req.json()
    
    console.log('Generating AI tasks for user:', userId)
    
    if (!userId || !userProfile) {
      return c.json({ error: 'Missing required fields' }, 400)
    }

    // Create AI prompt based on user profile
    const prompt = `Generate 5 personalized daily tasks for a UK visa applicant with the following profile:

Name: ${userProfile.name}
Completed Assessments: ${userProfile.completedAssessments?.map(a => `${a.visaType} (${a.score}% match)`).join(', ') || 'None'}
Current Level: ${userProfile.currentLevel || 1}
Preferences: ${userProfile.preferences || 'UK visa preparation'}

Requirements:
- Tasks should be specific, actionable, and achievable in 15-60 minutes
- Include a mix of research, documentation, skill-building, and preparation tasks
- Consider the user's current progress and visa route preferences
- Each task should have clear value for UK visa application success
- Make tasks engaging and motivating

Return a JSON array with this exact structure:
[
  {
    "title": "Task title (clear and specific)",
    "description": "Detailed description of what to do and why it's important",
    "category": "research|documentation|skill-building|preparation|networking",
    "priority": "high|medium|low",
    "points": 30-80,
    "estimatedTime": "15-60 minutes",
    "visaRoute": "relevant visa route if applicable"
  }
]

Make each task unique and valuable for their UK visa journey.`

    try {
      const aiResponse = await callOpenAI([
        {
          role: 'system',
          content: 'You are a UK visa expert who creates personalized daily tasks to help applicants prepare their applications effectively. Always respond with valid JSON only.'
        },
        {
          role: 'user',
          content: prompt
        }
      ], 'gpt-4o', 0.7)

      if (!aiResponse?.choices?.[0]?.message?.content) {
        throw new Error('No AI response received')
      }

      let aiTasks
      try {
        // Clean the response to ensure it's valid JSON
        let content = aiResponse.choices[0].message.content.trim()
        
        // Remove any markdown formatting
        if (content.startsWith('```json')) {
          content = content.slice(7)
        }
        if (content.endsWith('```')) {
          content = content.slice(0, -3)
        }
        
        aiTasks = JSON.parse(content)
      } catch (parseError) {
        console.error('Error parsing AI response:', parseError)
        throw new Error('Invalid AI response format')
      }

      // Validate and format tasks
      const tasks = aiTasks.map((task: any, index: number) => ({
        id: `ai_task_${Date.now()}_${index}`,
        title: task.title || `Task ${index + 1}`,
        description: task.description || 'Complete this task to advance your visa preparation',
        category: ['research', 'documentation', 'skill-building', 'preparation', 'networking'].includes(task.category) 
          ? task.category : 'preparation',
        priority: ['high', 'medium', 'low'].includes(task.priority) ? task.priority : 'medium',
        points: Math.max(20, Math.min(100, parseInt(task.points) || 40)),
        estimatedTime: task.estimatedTime || '30 minutes',
        completed: false,
        dueDate: new Date().toISOString().split('T')[0],
        visaRoute: task.visaRoute || undefined,
        aiGenerated: true
      }))

      // Store tasks in KV store
      await kv.set(`daily_tasks:${userId}:${new Date().toISOString().split('T')[0]}`, {
        userId,
        date: new Date().toISOString().split('T')[0],
        tasks,
        generatedAt: new Date().toISOString(),
        aiGenerated: true
      })

      console.log(`Generated ${tasks.length} AI tasks for user ${userId}`)

      return c.json({ 
        message: 'AI tasks generated successfully',
        tasks,
        count: tasks.length
      })

    } catch (aiError) {
      console.error('AI task generation error:', aiError)
      
      // Fallback to template tasks
      const fallbackTasks = [
        {
          id: `fallback_task_${Date.now()}_1`,
          title: 'Review UK visa requirements',
          description: 'Spend 30 minutes reading official UKVI guidance for your target visa route',
          category: 'research',
          priority: 'high',
          points: 50,
          estimatedTime: '30 minutes',
          completed: false,
          dueDate: new Date().toISOString().split('T')[0],
          aiGenerated: false
        },
        {
          id: `fallback_task_${Date.now()}_2`,
          title: 'Update professional profile',
          description: 'Review and enhance your LinkedIn profile with recent achievements',
          category: 'preparation',
          priority: 'medium',
          points: 40,
          estimatedTime: '45 minutes',
          completed: false,
          dueDate: new Date().toISOString().split('T')[0],
          aiGenerated: false
        },
        {
          id: `fallback_task_${Date.now()}_3`,
          title: 'Practice English skills',
          description: 'Complete 20 minutes of English language practice focused on professional vocabulary',
          category: 'skill-building',
          priority: 'medium',
          points: 30,
          estimatedTime: '20 minutes',
          completed: false,
          dueDate: new Date().toISOString().split('T')[0],
          aiGenerated: false
        }
      ]

      return c.json({ 
        message: 'Fallback tasks generated (AI unavailable)',
        tasks: fallbackTasks,
        count: fallbackTasks.length,
        aiGenerated: false
      })
    }

  } catch (error) {
    console.error('Generate daily tasks error:', error)
    return c.json({ error: 'Failed to generate daily tasks' }, 500)
  }
})

// Update user progress when task is completed
app.post('/update-user-progress', async (c) => {
  try {
    const { userId, taskId, pointsEarned, progress } = await c.req.json()
    
    console.log('Updating progress for user:', userId, 'Task:', taskId, 'Points:', pointsEarned)
    
    if (!userId || !taskId || typeof pointsEarned !== 'number') {
      return c.json({ error: 'Missing required fields' }, 400)
    }

    // Store progress update
    const progressUpdate = {
      userId,
      taskId,
      pointsEarned,
      timestamp: new Date().toISOString(),
      progress: progress || {}
    }

    // Store in KV with timestamp for historical tracking
    const progressKey = `progress_update:${userId}:${Date.now()}`
    await kv.set(progressKey, progressUpdate)

    // Update user's current progress
    const userProgressKey = `user_progress:${userId}`
    const currentProgress = await kv.get(userProgressKey) || {
      totalPoints: 0,
      currentStreak: 0,
      lastActivityDate: '',
      completedTasks: [],
      level: 1,
      achievements: [],
      weeklyGoal: 5,
      dailyTasksCompleted: 0
    }

    const updatedProgress = {
      ...currentProgress,
      ...progress,
      lastUpdated: new Date().toISOString()
    }

    await kv.set(userProgressKey, updatedProgress)

    // Check for level up or achievements
    const levelUp = Math.floor(updatedProgress.totalPoints / 100) + 1 > currentProgress.level
    const newAchievements = []

    if (levelUp) {
      newAchievements.push(`Level ${Math.floor(updatedProgress.totalPoints / 100) + 1} Reached`)
    }

    if (updatedProgress.currentStreak >= 7 && currentProgress.currentStreak < 7) {
      newAchievements.push('Week Warrior')
    }

    console.log(`Progress updated for user ${userId}: +${pointsEarned} points, Level ${updatedProgress.level}`)

    return c.json({ 
      message: 'Progress updated successfully',
      pointsEarned,
      newLevel: updatedProgress.level,
      levelUp,
      newAchievements,
      totalPoints: updatedProgress.totalPoints,
      currentStreak: updatedProgress.currentStreak
    })

  } catch (error) {
    console.error('Update user progress error:', error)
    return c.json({ error: 'Failed to update user progress' }, 500)
  }
})

// Get user progress and statistics
app.get('/user-progress/:userId', async (c) => {
  try {
    const userId = c.req.param('userId')
    
    if (!userId) {
      return c.json({ error: 'User ID required' }, 400)
    }

    // Get current progress
    const progress = await kv.get(`user_progress:${userId}`)
    
    // Get recent task completions
    const recentUpdates = await kv.getByPrefix(`progress_update:${userId}:`)
    const sortedUpdates = recentUpdates
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 10) // Last 10 updates

    // Get today's tasks
    const todaysTasks = await kv.get(`daily_tasks:${userId}:${new Date().toISOString().split('T')[0]}`)

    return c.json({
      progress: progress || {
        totalPoints: 0,
        currentStreak: 0,
        lastActivityDate: '',
        completedTasks: [],
        level: 1,
        achievements: [],
        weeklyGoal: 5,
        dailyTasksCompleted: 0
      },
      recentUpdates,
      todaysTasks: todaysTasks?.tasks || []
    })

  } catch (error) {
    console.error('Get user progress error:', error)
    return c.json({ error: 'Failed to get user progress' }, 500)
  }
})

// Get daily tasks for a specific date
app.get('/daily-tasks/:userId/:date', async (c) => {
  try {
    const userId = c.req.param('userId')
    const date = c.req.param('date')
    
    if (!userId || !date) {
      return c.json({ error: 'User ID and date required' }, 400)
    }

    const tasks = await kv.get(`daily_tasks:${userId}:${date}`)
    
    return c.json({
      tasks: tasks?.tasks || [],
      date,
      generatedAt: tasks?.generatedAt,
      aiGenerated: tasks?.aiGenerated || false
    })

  } catch (error) {
    console.error('Get daily tasks error:', error)
    return c.json({ error: 'Failed to get daily tasks' }, 500)
  }
})

// Mark task as completed
app.post('/complete-task', async (c) => {
  try {
    const { userId, taskId, date } = await c.req.json()
    
    console.log('Completing task:', taskId, 'for user:', userId, 'on date:', date)
    
    if (!userId || !taskId || !date) {
      return c.json({ error: 'Missing required fields' }, 400)
    }

    // Get tasks for the date
    const tasksData = await kv.get(`daily_tasks:${userId}:${date}`)
    
    if (!tasksData?.tasks) {
      return c.json({ error: 'Tasks not found for this date' }, 404)
    }

    // Update the specific task
    const updatedTasks = tasksData.tasks.map((task: any) => {
      if (task.id === taskId) {
        return {
          ...task,
          completed: true,
          completedAt: new Date().toISOString()
        }
      }
      return task
    })

    // Save updated tasks
    await kv.set(`daily_tasks:${userId}:${date}`, {
      ...tasksData,
      tasks: updatedTasks,
      lastUpdated: new Date().toISOString()
    })

    const completedTask = updatedTasks.find((task: any) => task.id === taskId)
    
    console.log(`Task ${taskId} completed for user ${userId}`)

    return c.json({
      message: 'Task completed successfully',
      task: completedTask,
      pointsEarned: completedTask?.points || 0
    })

  } catch (error) {
    console.error('Complete task error:', error)
    return c.json({ error: 'Failed to complete task' }, 500)
  }
})

// Export as named and default export
export { app as dashboardEndpoints }
export default app