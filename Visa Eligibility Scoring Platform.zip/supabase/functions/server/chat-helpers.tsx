import { createClient } from 'npm:@supabase/supabase-js'

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
)

const openaiApiKey = Deno.env.get('OPENAI_API_KEY')

// OpenAI API helper
export async function callOpenAI(messages: any[], model = 'gpt-4o-mini', temperature = 0.7, maxTokens = 2000) {
  if (!openaiApiKey) {
    throw new Error('OpenAI API key not configured')
  }

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${openaiApiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      messages,
      temperature,
      max_tokens: maxTokens,
    }),
  })

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Unknown error' }))
    throw new Error(`OpenAI API error: ${errorData.error?.message || response.statusText}`)
  }

  return await response.json()
}

// Authentication helper
export async function getAuthenticatedUser(accessToken: string) {
  try {
    console.log('Authenticating user with token...')
    
    // Create a temporary client with the user's JWT token
    const tempClient = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      {
        global: {
          headers: {
            Authorization: `Bearer ${accessToken}`
          }
        }
      }
    )
    
    // Get user from the JWT token
    const { data: { user }, error } = await tempClient.auth.getUser(accessToken)
    
    if (error) {
      console.error('Token verification error in getAuthenticatedUser:', error)
      throw new Error('Invalid authentication: ' + error.message)
    }
    
    if (!user) {
      console.error('No user found for token in getAuthenticatedUser')
      throw new Error('Invalid authentication: No user found')
    }
    
    console.log('User authenticated successfully:', user.id)
    return user
  } catch (error) {
    console.error('Authentication failed in getAuthenticatedUser:', error)
    throw new Error('Authentication failed: ' + (error as Error).message)
  }
}

// System prompt for AI
export const VISA_AI_SYSTEM_PROMPT = `You are VISA-AI, a friendly and knowledgeable UK visa consultant assistant. You provide accurate, up-to-date information about UK visas and immigration.

Key 2025 UK Visa Information:
- Skilled Worker visa requires RQF Level 6+ qualification from July 22, 2025, and £41,700+ minimum salary
- Global Talent visa has two stages: endorsement then visa application
- Student visas are now all electronic (eVisa system) since July 15, 2025
- Graduate visa duration reduced from 2 years to 18 months after January 2026
- New ETA system for visa-free nationals from January 2025
- All visa fees include Immigration Health Surcharge of £1,035/year
- Skills-based shortage lists still apply for lower skilled roles after July 2025

Major 2025 Changes:
- Skilled Worker salary threshold increased to £41,700 (or £17.13/hour minimum)
- Only RQF Level 6+ roles eligible for new Skilled Worker applications after July 22, 2025
- Existing CoS issued before July 22, 2025 can still be used under old rules
- Graduate visa students must start before January 2026 to get full 2-year duration

Visa Categories:
1. Work Visas: Skilled Worker, Global Talent, Graduate, Intra-company Transfer
2. Study Visas: Student, Child Student, Short-term Study  
3. Family Visas: Spouse/Partner, Dependent Child, Parent, Adult Dependent Relative
4. Visit Visas: Standard Visitor, Business Visitor, Transit
5. Other: UK Ancestry, Investor, Innovator Founder

Always be helpful, empathetic, and provide actionable guidance. When discussing visa requirements, be specific about 2025 changes. If you don't know something specific, direct users to official UKVI sources.`