import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'jsr:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['POST', 'GET', 'PUT', 'DELETE', 'OPTIONS'],
}));

// OpenAI API configuration
const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');
if (!OPENAI_API_KEY) {
  console.error('OPENAI_API_KEY environment variable is required');
}

// AI-powered eligibility assessment
app.post('/assess-eligibility', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Authorization header required' }, 401);
    }

    const token = authHeader.replace('Bearer ', '');
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return c.json({ error: 'Invalid token' }, 401);
    }

    const requestBody = await c.req.json();
    const { visaRoute, answers, userProfile } = requestBody;

    if (!visaRoute || !answers) {
      return c.json({ error: 'Visa route and answers are required' }, 400);
    }

    // Prepare the AI prompt with UKVI-specific context
    const systemPrompt = `You are a UK visa eligibility assessment AI with expert knowledge of UKVI requirements. 

Analyze the user's answers against the specific visa route requirements and provide:
1. An overall eligibility score (0-100)
2. Detailed analysis of each requirement area
3. Specific recommendations for improvement
4. Timeframe estimates for addressing deficiencies
5. Risk assessment for application success

Base your assessment ONLY on current UKVI requirements as of 2024. Be precise and reference specific requirements.

Visa Route: ${visaRoute.name}
Official UKVI Guidance: ${visaRoute.ukviGuidanceUrl}
Last Updated: ${visaRoute.lastUpdated}

Essential Requirements:
${visaRoute.requirements.essential.map((req: string, idx: number) => `${idx + 1}. ${req}`).join('\n')}

Disqualifying Factors:
${visaRoute.requirements.disqualifying.map((factor: string, idx: number) => `${idx + 1}. ${factor}`).join('\n')}

Return a JSON response with this exact structure:
{
  "overallScore": number (0-100),
  "eligibilityStatus": "Highly Likely" | "Likely" | "Possible" | "Unlikely" | "Not Eligible",
  "assessment": {
    "strengths": ["specific strength 1", "specific strength 2"],
    "weaknesses": ["specific weakness 1", "specific weakness 2"],
    "criticalIssues": ["critical issue 1"] or [],
    "missingRequirements": ["missing req 1", "missing req 2"]
  },
  "recommendations": [
    {
      "category": "requirement category",
      "priority": "High" | "Medium" | "Low",
      "action": "specific action needed",
      "timeframe": "estimated time",
      "difficulty": "Easy" | "Medium" | "Hard"
    }
  ],
  "nextSteps": ["immediate step 1", "step 2", "step 3"],
  "riskFactors": ["risk 1", "risk 2"],
  "applicationTimeline": "estimated timeline for being application-ready"
}`;

    const userAnswersText = answers.map((answer: any) => {
      const question = visaRoute.questions.find((q: any) => q.id === answer.questionId);
      return `Q: ${question?.text}\nA: ${answer.answer}\nWeight: ${question?.weight || 1}`;
    }).join('\n\n');

    const userContext = userProfile ? `
User Profile Context:
- Name: ${userProfile.name || 'Not provided'}
- Background: ${userProfile.background || 'Not provided'}
- Experience: ${userProfile.experience || 'Not provided'}
` : '';

    const fullPrompt = `${systemPrompt}

${userContext}

User's Answers:
${userAnswersText}

Provide detailed, actionable assessment based on current UKVI requirements.`;

    // Call OpenAI API
    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: systemPrompt
          },
          {
            role: 'user',
            content: fullPrompt
          }
        ],
        temperature: 0.1, // Low temperature for consistent, factual responses
        max_tokens: 2000,
        response_format: { type: 'json_object' }
      }),
    });

    if (!openaiResponse.ok) {
      console.error('OpenAI API error:', await openaiResponse.text());
      throw new Error('AI assessment failed');
    }

    const openaiData = await openaiResponse.json();
    const aiAssessment = JSON.parse(openaiData.choices[0].message.content);

    // Store the assessment result
    const assessmentId = `assessment_${user.id}_${Date.now()}`;
    const assessmentData = {
      id: assessmentId,
      userId: user.id,
      visaRouteId: visaRoute.id,
      visaRouteName: visaRoute.name,
      answers,
      aiAssessment,
      timestamp: new Date().toISOString(),
      version: '1.0'
    };

    await kv.set(`assessment:${assessmentId}`, assessmentData);
    await kv.set(`user_latest_assessment:${user.id}`, assessmentData);

    // Generate action plan if score is below 85%
    let actionPlan = null;
    if (aiAssessment.overallScore < 85) {
      actionPlan = await generateActionPlan(aiAssessment, visaRoute, user.id);
    }

    return c.json({
      success: true,
      assessmentId,
      assessment: aiAssessment,
      actionPlan,
      ukviApplicationUrl: visaRoute.ukviUrl,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Assessment error:', error);
    return c.json({ 
      error: 'Failed to assess eligibility', 
      details: error.message 
    }, 500);
  }
});

// Generate AI-powered action plan
async function generateActionPlan(assessment: any, visaRoute: any, userId: string) {
  const actionPlanPrompt = `Based on this visa eligibility assessment, create a detailed 5+ day action plan to improve the applicant's eligibility score.

Current Score: ${assessment.overallScore}%
Target Score: 85%+ (application ready)
Visa Route: ${visaRoute.name}

Assessment Details:
Weaknesses: ${assessment.assessment.weaknesses.join(', ')}
Missing Requirements: ${assessment.assessment.missingRequirements.join(', ')}
Critical Issues: ${assessment.assessment.criticalIssues.join(', ')}

Create a JSON response with this structure:
{
  "planId": "unique_plan_id",
  "targetScore": 85,
  "estimatedDays": number,
  "tasks": [
    {
      "id": "task_1",
      "title": "task title",
      "description": "detailed description",
      "category": "Documentation|Financial|Skills|Language|Other",
      "priority": "High|Medium|Low",
      "estimatedDays": number,
      "difficulty": "Easy|Medium|Hard",
      "scoreImpact": number (points increase when completed),
      "requirements": ["what is needed"],
      "resources": ["helpful links or documents"],
      "completed": false
    }
  ],
  "milestones": [
    {
      "day": number,
      "title": "milestone title",
      "description": "what should be achieved"
    }
  ],
  "tips": ["helpful tip 1", "tip 2"],
  "warningNote": "Any critical warnings about timeline or requirements"
}

Ensure minimum 5 days timeline and realistic, actionable steps.`;

  try {
    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'You are a UK visa preparation expert creating actionable improvement plans.'
          },
          {
            role: 'user',
            content: actionPlanPrompt
          }
        ],
        temperature: 0.2,
        max_tokens: 1500,
        response_format: { type: 'json_object' }
      }),
    });

    if (openaiResponse.ok) {
      const openaiData = await openaiResponse.json();
      const actionPlan = JSON.parse(openaiData.choices[0].message.content);
      
      // Store the action plan
      const planId = `plan_${userId}_${Date.now()}`;
      actionPlan.planId = planId;
      await kv.set(`action_plan:${planId}`, actionPlan);
      
      return actionPlan;
    }
  } catch (error) {
    console.error('Action plan generation error:', error);
  }

  return null;
}

// Update action plan task completion
app.post('/update-action-plan', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Authorization header required' }, 401);
    }

    const token = authHeader.replace('Bearer ', '');
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return c.json({ error: 'Invalid token' }, 401);
    }

    const { planId, taskId, completed } = await c.req.json();

    if (!planId || !taskId || completed === undefined) {
      return c.json({ error: 'Plan ID, task ID, and completed status required' }, 400);
    }

    // Get current plan
    const currentPlan = await kv.get(`action_plan:${planId}`);
    if (!currentPlan) {
      return c.json({ error: 'Action plan not found' }, 404);
    }

    // Update task completion status
    const updatedTasks = currentPlan.tasks.map((task: any) => {
      if (task.id === taskId) {
        return { ...task, completed };
      }
      return task;
    });

    // Calculate new score based on completed tasks
    const completedTasks = updatedTasks.filter((task: any) => task.completed);
    const totalScoreIncrease = completedTasks.reduce((sum: number, task: any) => sum + (task.scoreImpact || 0), 0);
    
    const updatedPlan = {
      ...currentPlan,
      tasks: updatedTasks,
      currentScore: Math.min(100, (currentPlan.baseScore || 70) + totalScoreIncrease),
      completedTasks: completedTasks.length,
      totalTasks: updatedTasks.length,
      lastUpdated: new Date().toISOString()
    };

    // Save updated plan
    await kv.set(`action_plan:${planId}`, updatedPlan);

    return c.json({
      success: true,
      updatedPlan,
      scoreChange: completed ? `+${updatedTasks.find((t: any) => t.id === taskId)?.scoreImpact || 0}` : `-${updatedTasks.find((t: any) => t.id === taskId)?.scoreImpact || 0}`,
      newScore: updatedPlan.currentScore
    });

  } catch (error) {
    console.error('Update action plan error:', error);
    return c.json({ error: 'Failed to update action plan' }, 500);
  }
});

// Get action plan
app.get('/action-plan/:planId', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Authorization header required' }, 401);
    }

    const planId = c.req.param('planId');
    const actionPlan = await kv.get(`action_plan:${planId}`);

    if (!actionPlan) {
      return c.json({ error: 'Action plan not found' }, 404);
    }

    return c.json({ success: true, actionPlan });

  } catch (error) {
    console.error('Get action plan error:', error);
    return c.json({ error: 'Failed to retrieve action plan' }, 500);
  }
});

// Get user's latest assessment
app.get('/latest-assessment', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Authorization header required' }, 401);
    }

    const token = authHeader.replace('Bearer ', '');
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return c.json({ error: 'Invalid token' }, 401);
    }

    const latestAssessment = await kv.get(`user_latest_assessment:${user.id}`);
    
    return c.json({ 
      success: true, 
      assessment: latestAssessment || null 
    });

  } catch (error) {
    console.error('Get latest assessment error:', error);
    return c.json({ error: 'Failed to retrieve assessment' }, 500);
  }
});

export { app as eligibilityEndpoints }
export default app