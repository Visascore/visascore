import { projectId, publicAnonKey } from './supabase/info'

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-ca272e8b`

// Session management for anonymous users
let currentSessionId: string | null = null

export function getSessionId(): string {
  if (!currentSessionId) {
    currentSessionId = localStorage.getItem('visa-ai-session-id') || null
  }
  return currentSessionId || ''
}

export function setSessionId(sessionId: string) {
  currentSessionId = sessionId
  localStorage.setItem('visa-ai-session-id', sessionId)
}

// Generic API call helper
async function apiCall(endpoint: string, options: RequestInit = {}) {
  const url = `${API_BASE_URL}${endpoint}`
  
  const defaultHeaders = {
    'Authorization': `Bearer ${publicAnonKey}`,
    'Content-Type': 'application/json',
    'X-Session-ID': getSessionId() || '',
  }

  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        ...defaultHeaders,
        ...options.headers,
      },
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      throw new Error(errorData.error || `API call failed: ${response.statusText}`)
    }

    return await response.json()
  } catch (error) {
    console.error(`API call to ${endpoint} failed:`, error)
    throw error
  }
}

// AI Chat API
export async function sendChatMessage(message: string, conversationHistory: any[] = []) {
  return apiCall('/ai-chat', {
    method: 'POST',
    body: JSON.stringify({
      message,
      conversationHistory
    })
  })
}

// AI Eligibility Assessment API
export async function assessEligibility(visaRoute: any, answers: any, userProfile: any = {}) {
  return apiCall('/ai-eligibility', {
    method: 'POST',
    body: JSON.stringify({
      visaRoute,
      answers,
      userProfile
    })
  })
}

// AI Visa Route Recommendations API
export async function getVisaRecommendations(userProfile: any, preferences: any = {}) {
  return apiCall('/ai-recommendations', {
    method: 'POST',
    body: JSON.stringify({
      userProfile,
      preferences
    })
  })
}

// Resume Upload API
export async function uploadResume(formData: FormData) {
  const url = `${API_BASE_URL}/resume/upload`
  
  try {
    console.log('Uploading resume to:', url)
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
      body: formData
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error('Resume upload failed with status:', response.status, errorText)
      
      let errorData
      try {
        errorData = JSON.parse(errorText)
      } catch (e) {
        errorData = { error: errorText }
      }
      
      throw new Error(errorData.error || `Resume upload failed: ${response.statusText}`)
    }

    const result = await response.json()
    console.log('Resume upload successful:', result)
    return result
    
  } catch (error) {
    console.error('Resume upload failed:', error)
    throw error
  }
}

// Job Analysis API
export async function analyzeJob(jobData: any) {
  return apiCall('/job/analyze', {
    method: 'POST',
    body: JSON.stringify(jobData)
  })
}

// Resume-Job Matching API
export async function matchResumeToJob(resumeId: string, jobId: string) {
  return apiCall('/match/analyze', {
    method: 'POST',
    body: JSON.stringify({
      resume_id: resumeId,
      job_id: jobId
    })
  })
}

// Resume Optimization API
export async function optimizeResume(resumeId: string, jobId?: string, optimizationType: string = 'job-specific') {
  return apiCall('/resume/optimize', {
    method: 'POST',
    body: JSON.stringify({
      resume_id: resumeId,
      job_id: jobId,
      optimization_type: optimizationType
    })
  })
}

// Get User Data APIs (for when authentication is restored)
export async function getUserResumes() {
  return apiCall('/resumes', {
    method: 'GET'
  })
}

export async function getUserJobs() {
  return apiCall('/jobs', {
    method: 'GET'
  })
}

export async function getUserMatches() {
  return apiCall('/matches', {
    method: 'GET'
  })
}

// Health Check API
export async function checkApiHealth() {
  try {
    const [aiHealth, serverHealth] = await Promise.all([
      apiCall('/ai-health', { method: 'GET' }),
      apiCall('/health', { method: 'GET' })
    ])
    
    return {
      ai: aiHealth,
      server: serverHealth,
      status: 'healthy'
    }
  } catch (error) {
    console.error('Health check failed:', error)
    return {
      status: 'unhealthy',
      error: error.message
    }
  }
}

// Chat Session Management APIs
export async function createChatSession(title: string = "New conversation") {
  const response = await apiCall('/chat-sessions', {
    method: 'POST',
    body: JSON.stringify({ title })
  })
  
  // Store session ID for future requests
  if (response.sessionId) {
    setSessionId(response.sessionId)
  }
  
  return response
}

export async function getChatSessions() {
  const response = await apiCall('/chat-sessions', {
    method: 'GET'
  })
  
  // Store session ID for future requests
  if (response.sessionId) {
    setSessionId(response.sessionId)
  }
  
  return response
}

export async function getChatSession(chatSessionId: string) {
  return apiCall(`/chat-sessions/${chatSessionId}`, {
    method: 'GET'
  })
}

export async function updateChatSession(chatSessionId: string, updates: any) {
  return apiCall(`/chat-sessions/${chatSessionId}`, {
    method: 'PUT',
    body: JSON.stringify(updates)
  })
}

export async function deleteChatSession(chatSessionId: string) {
  return apiCall(`/chat-sessions/${chatSessionId}`, {
    method: 'DELETE'
  })
}

export async function addMessageToChatSession(chatSessionId: string, message: any) {
  return apiCall(`/chat-sessions/${chatSessionId}/messages`, {
    method: 'POST',
    body: JSON.stringify({ message })
  })
}

// Error handling helper
export function handleApiError(error: any) {
  if (error.message?.includes('Failed to fetch')) {
    return 'Unable to connect to server. Please check your internet connection and try again.'
  }
  
  if (error.message?.includes('OpenAI API')) {
    return 'AI service is temporarily unavailable. Please try again in a few minutes.'
  }
  
  return error.message || 'An unexpected error occurred. Please try again.'
}