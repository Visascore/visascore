import { projectId, publicAnonKey } from './supabase/info';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-ca272e8b`;

// Test backend connectivity
export async function testBackendConnectivity(): Promise<boolean> {
  try {
    const response = await fetch(`${API_BASE_URL}/health`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`
      }
    });
    return response.ok;
  } catch (error) {
    console.error('Backend connectivity test failed:', error);
    return false;
  }
}

// Load user profile
export async function loadUserProfile(accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/auth/profile`, {
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    }
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to load user profile');
  }

  return response.json();
}

// Load user visa scores
export async function loadVisaScores(accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/auth/visa-scores`, {
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    }
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to load visa scores');
  }

  return response.json();
}

// Complete onboarding
export async function completeOnboarding(onboardingData: any, accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/auth/complete-onboarding`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ onboardingData })
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to complete onboarding');
  }

  return response.json();
}

// Update user profile
export async function updateUserProfile(profileData: any, accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/user/profile`, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(profileData)
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to update profile');
  }

  return response.json();
}

// Load subscription
export async function loadSubscription(accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/subscription/status`, {
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    }
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to load subscription');
  }

  return response.json();
}

// Start free trial
export async function startFreeTrial(cardDetails: any, accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/subscription/start-trial`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(cardDetails)
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to start free trial');
  }

  return response.json();
}

// Check access
export async function checkAccess(accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/auth/check-access`, {
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    }
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to check access');
  }

  return response.json();
}

// Chat functions
export async function sendChatMessage(message: string, chatHistory: any[], accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/chat/send`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      message,
      chatHistory
    })
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to send chat message');
  }

  return response.json();
}

// Get chat history
export async function getChatHistory(accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/chat/history`, {
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    }
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to get chat history');
  }

  return response.json();
}

// Clear chat history
export async function clearChatHistory(accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/chat/clear`, {
    method: 'DELETE',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    }
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to clear chat history');
  }

  return response.json();
}

// Generate daily tasks
export async function generateDailyTasks(userId: string, userProfile: any, accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/generate-daily-tasks`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      userId,
      userProfile
    })
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to generate daily tasks');
  }

  return response.json();
}

// Get user progress
export async function getUserProgress(userId: string, accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/user-progress/${userId}`, {
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    }
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to get user progress');
  }

  return response.json();
}

// Complete task
export async function completeTask(userId: string, taskId: string, date: string, accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/complete-task`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      userId,
      taskId,
      date
    })
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to complete task');
  }

  return response.json();
}

// Update user progress
export async function updateUserProgress(userId: string, taskId: string, pointsEarned: number, progress: any, accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/update-user-progress`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      userId,
      taskId,
      pointsEarned,
      progress
    })
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to update user progress');
  }

  return response.json();
}

// Resume analysis functions
export async function analyzeResume(resumeText: string, jobDescription: string, accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/resume/analyze`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      resumeText,
      jobDescription
    })
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to analyze resume');
  }

  return response.json();
}

// Optimize resume
export async function optimizeResume(resumeText: string, jobDescription: string, accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/resume/optimize`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      resumeText,
      jobDescription
    })
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to optimize resume');
  }

  return response.json();
}

// Match resume to jobs
export async function matchResumeToJobs(resumeText: string, accessToken: string) {
  const response = await fetch(`${API_BASE_URL}/resume/match-jobs`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      resumeText
    })
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to match resume to jobs');
  }

  return response.json();
}

// Admin API functions
export const adminAPI = {
  // Admin login
  async login(email: string, password: string) {
    const response = await fetch(`${API_BASE_URL}/admin/login`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email, password })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Admin login failed');
    }

    return response.json();
  },

  // Get analytics
  async getAnalytics(accessToken: string) {
    const response = await fetch(`${API_BASE_URL}/admin/analytics`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to get analytics');
    }

    return response.json();
  },

  // Get all users
  async getUsers(accessToken: string) {
    const response = await fetch(`${API_BASE_URL}/admin/users`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to get users');
    }

    return response.json();
  },

  // Get revenue data
  async getRevenue(accessToken: string) {
    const response = await fetch(`${API_BASE_URL}/admin/revenue`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to get revenue data');
    }

    return response.json();
  },

  // Delete user
  async deleteUser(userId: string, accessToken: string) {
    const response = await fetch(`${API_BASE_URL}/admin/users/${userId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to delete user');
    }

    return response.json();
  },

  // Reset user data
  async resetUser(userId: string, accessToken: string) {
    const response = await fetch(`${API_BASE_URL}/admin/users/${userId}/reset`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to reset user');
    }

    return response.json();
  },

  // Update subscription
  async updateSubscription(userId: string, status: string, plan: string, amount: number, accessToken: string) {
    const response = await fetch(`${API_BASE_URL}/admin/users/${userId}/subscription`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ status, plan, amount })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to update subscription');
    }

    return response.json();
  },

  // Get user profile details
  async getUserProfile(userId: string, accessToken: string) {
    const response = await fetch(`${API_BASE_URL}/admin/users/${userId}/profile`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to get user profile');
    }

    return response.json();
  }
};