import { createClient as createSupabaseClient, SupabaseClient } from '@supabase/supabase-js'
import { projectId, publicAnonKey } from './info'

// Singleton instance
let supabaseInstance: SupabaseClient | null = null

export const createClient = (): SupabaseClient => {
  // Return existing instance if it exists
  if (supabaseInstance) {
    return supabaseInstance
  }

  // Create new instance only if one doesn't exist
  supabaseInstance = createSupabaseClient(
    `https://${projectId}.supabase.co`,
    publicAnonKey,
    {
      auth: {
        persistSession: true,
        storageKey: 'visa-score-auth',
        storage: typeof window !== 'undefined' ? window.localStorage : undefined,
        autoRefreshToken: true,
        detectSessionInUrl: true
      },
      global: {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    }
  )

  return supabaseInstance
}

// Export a function for dynamic imports
export const supabase = () => createClient()

// Export the client factory for dynamic usage
export const getSupabaseClient = () => {
  return { supabase: createClient }
}

export default createClient