export interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

export interface UserProfile {
  name: string;
  email: string;
  completed_onboarding: boolean;
  country?: string;
  age?: string;
  profession?: string;
  visa_goals?: {
    primaryRoute?: string;
    timeframe?: string;
    previousApplications?: string;
    specificGoals?: string;
  };
  background?: {
    education?: string;
    workExperience?: string;
    englishLevel?: string;
    familyTies?: string;
    specificSkills?: string[];
    workSector?: string;
    qualificationCountry?: string;
  };
  preferences?: {
    communicationStyle?: string;
    priority?: string;
    notifications?: boolean;
    language?: string;
    timezone?: string;
  };
  settings?: {
    emailNotifications?: boolean;
    smsNotifications?: boolean;
    marketing?: boolean;
    dataSharing?: boolean;
    theme?: 'light' | 'dark' | 'auto';
  };
  [key: string]: any;
}

export interface AuthResult {
  success: boolean;
  error?: string;
  code?: string;
}

export interface OnboardingResult extends AuthResult {
  profile?: UserProfile;
  scores?: any;
}