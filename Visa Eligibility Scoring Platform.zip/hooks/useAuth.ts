import { useState, useEffect } from 'react';
import { createClient } from '../utils/supabase/client';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { toast } from 'sonner@2.0.3';
import { AuthState, UserProfile, AuthResult, OnboardingResult } from './authTypes';
import { AUTH_ERROR_MESSAGES, AUTH_SUCCESS_MESSAGES } from './authConstants';
import { createSignOutFunction } from './signOutUtils';

export function useAuth() {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
    session: null
  });
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  const supabase = createClient();

  // Create the comprehensive sign out function
  const handleSignOut = createSignOutFunction(supabase, setAuthState, setUserProfile);

  // Add keyboard shortcut for quick sign out (Ctrl/Cmd + Shift + Q)
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key === 'Q') {
        if (authState.isAuthenticated) {
          event.preventDefault();
          console.log('🔄 Quick sign out triggered via keyboard shortcut');
          handleSignOut();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [authState.isAuthenticated, handleSignOut]);

  useEffect(() => {
    // Get initial session
    const getInitialSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error) {
          console.error('Error getting session:', error);
        }
        
        if (session?.user) {
          setAuthState({
            user: session.user as any,
            isAuthenticated: true,
            isLoading: false,
            session
          });
          await loadUserProfile(session.user.id, session.access_token);
        } else {
          setAuthState({
            user: null,
            isAuthenticated: false,
            isLoading: false,
            session: null
          });
        }
      } catch (error) {
        console.error('Error in getInitialSession:', error);
        setAuthState({
          user: null,
          isAuthenticated: false,
          isLoading: false,
          session: null
        });
      }
    };

    getInitialSession();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('Auth state changed:', event, session?.user?.email);
      
      if (session?.user) {
        setAuthState({
          user: session.user as any,
          isAuthenticated: true,
          isLoading: false,
          session
        });
        await loadUserProfile(session.user.id, session.access_token);
      } else {
        setAuthState({
          user: null,
          isAuthenticated: false,
          isLoading: false,
          session: null
        });
        setUserProfile(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const loadUserProfile = async (userId: string, accessToken: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ca272e8b/auth/profile`,
        {
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        setUserProfile(data);
      } else {
        console.log('Failed to load user profile:', response.status);
      }
    } catch (error) {
      console.log('Error loading user profile:', error);
    }
  };

  const handleSignIn = async (email: string, password: string): Promise<AuthResult> => {
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        throw error;
      }

      toast.success(AUTH_SUCCESS_MESSAGES.SIGN_IN_SUCCESS);
      return { success: true };
    } catch (error: any) {
      console.error('Sign in error:', error);
      let errorMessage = AUTH_ERROR_MESSAGES.SIGN_IN_FAILED;
      
      if (error.message === AUTH_ERROR_MESSAGES.INVALID_CREDENTIALS) {
        errorMessage = 'Invalid email or password';
      } else if (error.message === AUTH_ERROR_MESSAGES.EMAIL_NOT_CONFIRMED) {
        errorMessage = 'Please check your email and click the verification link before signing in';
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast.error(errorMessage);
      return { success: false, error: errorMessage };
    }
  };

  const handleSignUp = async (email: string, password: string, name: string): Promise<AuthResult> => {
    try {
      // Create user via backend
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ca272e8b/auth/signup`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            email,
            password,
            name
          })
        }
      );

      const data = await response.json();

      if (!response.ok) {
        // Handle specific error codes from backend
        if (data.code === 'email_exists' || response.status === 409) {
          const errorMessage = 'An account with this email already exists. Please sign in instead.';
          toast.error(errorMessage);
          return { success: false, error: errorMessage, code: 'email_exists' };
        }
        
        if (data.code === 'weak_password') {
          const errorMessage = 'Password must be at least 6 characters long';
          toast.error(errorMessage);
          return { success: false, error: errorMessage, code: 'weak_password' };
        }
        
        throw new Error(data.error || AUTH_ERROR_MESSAGES.SIGN_UP_FAILED);
      }

      toast.success('Account created successfully! You can now sign in.');
      return { success: true };
    } catch (error: any) {
      console.error('Sign up error:', error);
      let errorMessage = AUTH_ERROR_MESSAGES.SIGN_UP_FAILED;
      
      if (error.message === AUTH_ERROR_MESSAGES.USER_ALREADY_REGISTERED) {
        errorMessage = 'An account with this email already exists. Please sign in instead.';
      } else if (error.message?.includes('email')) {
        errorMessage = 'An account with this email already exists. Please sign in instead.';
      } else if (error.message?.includes('Password')) {
        errorMessage = 'Password must be at least 6 characters long';
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast.error(errorMessage);
      return { success: false, error: errorMessage };
    }
  };

  const updateUserProfile = async (profileData: Partial<UserProfile>): Promise<AuthResult> => {
    try {
      if (!authState.session?.access_token) {
        throw new Error(AUTH_ERROR_MESSAGES.NO_AUTH_TOKEN);
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ca272e8b/user/profile`,
        {
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${authState.session.access_token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(profileData)
        }
      );

      if (!response.ok) {
        throw new Error(AUTH_ERROR_MESSAGES.PROFILE_UPDATE_FAILED);
      }

      const data = await response.json();
      setUserProfile(data.profile);
      toast.success(AUTH_SUCCESS_MESSAGES.PROFILE_UPDATE_SUCCESS);
      
      return { success: true };
    } catch (error: any) {
      console.error('Update profile error:', error);
      toast.error(error.message || AUTH_ERROR_MESSAGES.PROFILE_UPDATE_FAILED);
      return { success: false, error: error.message };
    }
  };

  const completeOnboarding = async (onboardingData: any): Promise<OnboardingResult> => {
    try {
      if (!authState.session?.access_token) {
        throw new Error(AUTH_ERROR_MESSAGES.NO_AUTH_TOKEN);
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ca272e8b/auth/complete-onboarding`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${authState.session.access_token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ onboardingData })
        }
      );

      if (!response.ok) {
        throw new Error(AUTH_ERROR_MESSAGES.ONBOARDING_FAILED);
      }

      const data = await response.json();
      setUserProfile(data.profile);
      toast.success(AUTH_SUCCESS_MESSAGES.ONBOARDING_SUCCESS);
      
      return { success: true, profile: data.profile, scores: data.scores };
    } catch (error: any) {
      console.error('Complete onboarding error:', error);
      toast.error(error.message || AUTH_ERROR_MESSAGES.ONBOARDING_FAILED);
      return { success: false, error: error.message };
    }
  };

  const updateSettings = async (settingsData: Partial<UserProfile['settings']>): Promise<AuthResult> => {
    try {
      const updatedProfile = {
        ...userProfile,
        settings: {
          ...userProfile?.settings,
          ...settingsData
        }
      };

      const result = await updateUserProfile(updatedProfile);
      return result;
    } catch (error: any) {
      console.error('Update settings error:', error);
      toast.error(AUTH_ERROR_MESSAGES.SETTINGS_UPDATE_FAILED);
      return { success: false, error: error.message };
    }
  };

  return {
    authState,
    userProfile,
    handleSignIn,
    handleSignUp,
    handleSignOut,
    updateUserProfile,
    completeOnboarding,
    updateSettings,
    setUserProfile
  };
}