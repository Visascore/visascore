import { toast } from 'sonner@2.0.3';
import { AuthState, UserProfile } from './authTypes';
import {
  getSignOutProgress,
  setSignOutProgress,
  clearLocalStorageData,
  clearSessionStorageData,
  clearBrowserCaches,
  clearCookies,
  performEmergencyCleanup,
  forceRedirectToHome
} from './authHelpers';

export const createSignOutFunction = (
  supabase: any,
  setAuthState: (state: AuthState) => void,
  setUserProfile: (profile: UserProfile | null) => void
) => {
  return async (): Promise<void> => {
    try {
      // Prevent multiple simultaneous sign out attempts
      if (getSignOutProgress()) {
        console.log('Sign out already in progress, ignoring request');
        return;
      }
      
      setSignOutProgress(true);
      console.log('🔄 Starting comprehensive sign out process...');

      // Step 1: Clear all localStorage data immediately
      clearLocalStorageData();

      // Step 2: Clear sessionStorage as well
      clearSessionStorageData();

      // Step 3: Clear React state immediately (optimistic update)
      setAuthState({
        user: null,
        isAuthenticated: false,
        isLoading: false,
        session: null
      });
      setUserProfile(null);
      console.log('✅ Cleared React state');

      // Step 4: Sign out from Supabase with comprehensive cleanup
      console.log('🔄 Signing out from Supabase...');
      const { error } = await supabase.auth.signOut({
        scope: 'global' // Sign out from all sessions
      });
      
      if (error) {
        console.error('❌ Supabase sign out error:', error);
        // Don't throw - we still want to clear local state
        toast.error('Network error during sign out, but you have been signed out locally');
      } else {
        console.log('✅ Successfully signed out from Supabase');
        toast.success('Signed out successfully');
      }

      // Step 5: Additional cleanup - clear any cached network requests
      await clearBrowserCaches();

      // Step 6: Clear cookies if any (for additional security)
      clearCookies();

      console.log('🎉 Sign out process completed successfully');

      // Step 7: Force redirect to home page
      forceRedirectToHome(500);

    } catch (error) {
      console.error('❌ Comprehensive sign out error:', error);
      
      // Emergency cleanup - ensure user is signed out locally regardless of errors
      setAuthState({
        user: null,
        isAuthenticated: false,
        isLoading: false,
        session: null
      });
      setUserProfile(null);

      // Clear localStorage in error case too
      performEmergencyCleanup();

      // Show error but still redirect
      toast.error('Sign out completed with some errors, but you have been signed out successfully');
      
      // Force redirect even on error
      forceRedirectToHome(1000);
    } finally {
      setSignOutProgress(false);
    }
  };
};