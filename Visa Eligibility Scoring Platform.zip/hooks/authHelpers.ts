import { AUTH_LOCAL_STORAGE_KEYS } from './authConstants';

// Sign out progress tracking
let isSignOutInProgress = false;

export const getSignOutProgress = () => isSignOutInProgress;
export const setSignOutProgress = (value: boolean) => {
  isSignOutInProgress = value;
};

export const clearLocalStorageData = () => {
  console.log('🔄 Clearing localStorage data...');
  
  AUTH_LOCAL_STORAGE_KEYS.forEach(key => {
    try {
      localStorage.removeItem(key);
      console.log(`✅ Cleared localStorage: ${key}`);
    } catch (err) {
      console.warn(`⚠️ Failed to clear localStorage key ${key}:`, err);
    }
  });
};

export const clearSessionStorageData = () => {
  try {
    sessionStorage.clear();
    console.log('✅ Cleared sessionStorage');
  } catch (err) {
    console.warn('⚠️ Failed to clear sessionStorage:', err);
  }
};

export const clearBrowserCaches = async () => {
  if ('caches' in window) {
    try {
      const cacheNames = await caches.keys();
      await Promise.all(
        cacheNames.map(cacheName => caches.delete(cacheName))
      );
      console.log('✅ Cleared browser caches');
    } catch (err) {
      console.warn('⚠️ Failed to clear caches:', err);
    }
  }
};

export const clearCookies = () => {
  document.cookie.split(";").forEach(cookie => {
    const eqPos = cookie.indexOf("=");
    const name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
    document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/";
  });
  console.log('✅ Cleared cookies');
};

export const performEmergencyCleanup = () => {
  try {
    localStorage.clear();
    console.log('✅ Emergency localStorage clear completed');
  } catch (clearError) {
    console.error('❌ Failed to clear localStorage in error handler:', clearError);
  }
};

export const forceRedirectToHome = (delay: number = 500) => {
  setTimeout(() => {
    console.log('🔄 Redirecting to home page...');
    window.location.replace('/'); // Use replace instead of href to prevent back navigation
  }, delay);
};