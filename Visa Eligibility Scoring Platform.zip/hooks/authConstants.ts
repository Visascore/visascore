// Authentication-related constants
export const AUTH_LOCAL_STORAGE_KEYS = [
  'visa-score-onboarding',
  'onboardingJustCompleted',
  'chat-history',
  'visa-assessments',
  'user-preferences',
  'user-dashboard-data',
  'visa-route-progress',
  'ai-conversation-history',
  'eligibility-results',
  'action-plans'
] as const;

export const AUTH_ERROR_MESSAGES = {
  INVALID_CREDENTIALS: 'Invalid login credentials',
  EMAIL_NOT_CONFIRMED: 'Email not confirmed',
  USER_ALREADY_REGISTERED: 'User already registered',
  SIGN_IN_FAILED: 'Failed to sign in',
  SIGN_UP_FAILED: 'Failed to create account',
  SIGN_OUT_FAILED: 'Failed to sign out',
  PROFILE_UPDATE_FAILED: 'Failed to update profile',
  ONBOARDING_FAILED: 'Failed to complete onboarding',
  SETTINGS_UPDATE_FAILED: 'Failed to update settings',
  NO_AUTH_TOKEN: 'No authentication token available'
} as const;

export const AUTH_SUCCESS_MESSAGES = {
  SIGN_IN_SUCCESS: 'Successfully signed in!',
  SIGN_UP_SUCCESS: 'Account created successfully! You can now sign in and complete your profile.',
  SIGN_OUT_SUCCESS: 'Signed out successfully',
  PROFILE_UPDATE_SUCCESS: 'Profile updated successfully',
  ONBOARDING_SUCCESS: 'Profile created successfully! Welcome to Visa Score!'
} as const;