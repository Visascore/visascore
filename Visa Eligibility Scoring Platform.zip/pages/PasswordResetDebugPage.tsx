import { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Alert, AlertDescription } from '../components/ui/alert';
import { ArrowLeft, Shield, Key, Mail, AlertTriangle, CheckCircle, Info } from 'lucide-react';
import { supabase } from '../utils/supabase/client';

interface PasswordResetDebugPageProps {
  navigate: (path: string) => void;
}

export function PasswordResetDebugPage({ navigate }: PasswordResetDebugPageProps) {
  const [debugInfo, setDebugInfo] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    checkPasswordResetStatus();
  }, []);

  const checkPasswordResetStatus = async () => {
    setLoading(true);
    try {
      // Get URL parameters
      const urlParams = new URLSearchParams(window.location.search);
      const accessToken = urlParams.get('access_token');
      const refreshToken = urlParams.get('refresh_token');
      const errorCode = urlParams.get('error');
      const errorDescription = urlParams.get('error_description');

      const info = {
        url: window.location.href,
        accessToken: accessToken ? `${accessToken.substring(0, 10)}...` : null,
        refreshToken: refreshToken ? `${refreshToken.substring(0, 10)}...` : null,
        errorCode,
        errorDescription,
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
        referrer: document.referrer || 'Direct access'
      };

      setDebugInfo(info);

      // Check current session
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      if (session) {
        info.sessionExists = true;
        info.userId = session.user?.id;
        info.userEmail = session.user?.email;
      } else {
        info.sessionExists = false;
        info.sessionError = sessionError?.message;
      }

      setDebugInfo({ ...info });

    } catch (err: any) {
      setError(err.message || 'Failed to check password reset status');
    } finally {
      setLoading(false);
    }
  };

  const clearTokensAndRedirect = () => {
    // Clear URL parameters and redirect to home
    window.history.replaceState({}, document.title, '/');
    navigate('/');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
          <p className="text-muted-foreground">Checking password reset status...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/')}
              className="mobile-back-button"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
            
            <div className="flex items-center space-x-2">
              <Shield className="w-5 h-5 text-primary" />
              <span className="font-semibold">Password Reset Debug</span>
            </div>
          </div>

          {/* Debug Information */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Info className="w-5 h-5" />
                <span>Debug Information</span>
              </CardTitle>
              <CardDescription>
                Technical details about the password reset process
              </CardDescription>
            </CardHeader>
            <CardContent>
              {debugInfo && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <div>
                        <label className="text-sm font-medium">Session Status</label>
                        <div className="flex items-center space-x-2">
                          {debugInfo.sessionExists ? (
                            <CheckCircle className="w-4 h-4 text-green-500" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-red-500" />
                          )}
                          <Badge variant={debugInfo.sessionExists ? 'default' : 'destructive'}>
                            {debugInfo.sessionExists ? 'Active Session' : 'No Session'}
                          </Badge>
                        </div>
                      </div>

                      <div>
                        <label className="text-sm font-medium">Access Token</label>
                        <p className="text-sm text-muted-foreground font-mono">
                          {debugInfo.accessToken || 'Not found'}
                        </p>
                      </div>

                      <div>
                        <label className="text-sm font-medium">Refresh Token</label>
                        <p className="text-sm text-muted-foreground font-mono">
                          {debugInfo.refreshToken || 'Not found'}
                        </p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="text-sm font-medium">Error Code</label>
                        <p className="text-sm text-muted-foreground">
                          {debugInfo.errorCode || 'None'}
                        </p>
                      </div>

                      <div>
                        <label className="text-sm font-medium">Error Description</label>
                        <p className="text-sm text-muted-foreground">
                          {debugInfo.errorDescription || 'None'}
                        </p>
                      </div>

                      <div>
                        <label className="text-sm font-medium">User Email</label>
                        <p className="text-sm text-muted-foreground">
                          {debugInfo.userEmail || 'Not available'}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-border">
                    <label className="text-sm font-medium">Current URL</label>
                    <p className="text-xs text-muted-foreground font-mono break-all">
                      {debugInfo.url}
                    </p>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Timestamp</label>
                    <p className="text-sm text-muted-foreground">
                      {new Date(debugInfo.timestamp).toLocaleString()}
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Status Alerts */}
          <div className="space-y-4 mb-6">
            {debugInfo?.errorCode && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Error detected:</strong> {debugInfo.errorCode}
                  {debugInfo.errorDescription && (
                    <span> - {debugInfo.errorDescription}</span>
                  )}
                </AlertDescription>
              </Alert>
            )}

            {debugInfo?.sessionExists && (
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Success:</strong> You have an active session. The password reset was successful.
                </AlertDescription>
              </Alert>
            )}

            {!debugInfo?.sessionExists && !debugInfo?.errorCode && (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <strong>No active session:</strong> The password reset link may have expired or been used already.
                </AlertDescription>
              </Alert>
            )}
          </div>

          {/* Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Next Steps</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {debugInfo?.sessionExists ? (
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">
                      Your password reset was successful. You can now access your account.
                    </p>
                    <Button 
                      onClick={clearTokensAndRedirect}
                      className="w-full mobile-button"
                    >
                      <Key className="w-4 h-4 mr-2" />
                      Continue to Dashboard
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">
                      The password reset link has expired or been used. Please request a new one.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      <Button 
                        onClick={() => navigate('/password-reset')}
                        className="mobile-button"
                      >
                        <Mail className="w-4 h-4 mr-2" />
                        Request New Reset
                      </Button>
                      <Button 
                        variant="outline"
                        onClick={() => navigate('/')}
                        className="mobile-button"
                      >
                        <ArrowLeft className="w-4 h-4 mr-2" />
                        Back to Home
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Technical Details */}
          {error && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-destructive">Error Details</CardTitle>
              </CardHeader>
              <CardContent>
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          )}

          {/* Help Section */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Troubleshooting</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div>
                  <strong>Link expired:</strong>
                  <p className="text-muted-foreground">
                    Password reset links expire after 1 hour for security reasons.
                  </p>
                </div>
                <div>
                  <strong>Already used:</strong>
                  <p className="text-muted-foreground">
                    Each reset link can only be used once. Request a new one if needed.
                  </p>
                </div>
                <div>
                  <strong>Browser issues:</strong>
                  <p className="text-muted-foreground">
                    Try clearing your browser cache or using an incognito window.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}