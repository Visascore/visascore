import { UserDashboard } from '../components/UserDashboard';
import { Header } from '../components/Header';

interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

interface UserProfile {
  name: string;
  email: string;
  completed_onboarding: boolean;
  [key: string]: any;
}

interface DashboardPageProps {
  authState: AuthState;
  userProfile: UserProfile | null;
  navigate: (path: string) => void;
  onSignIn?: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  onSignUp?: (email: string, password: string, name: string) => Promise<{ success: boolean; error?: string }>;
  onSignOut?: () => void;
}

export function DashboardPage({ authState, userProfile, navigate, onSignIn, onSignUp, onSignOut }: DashboardPageProps) {
  const handleSignOut = () => {
    console.log('Sign out requested from dashboard');
    if (onSignOut) {
      onSignOut();
    }
  };

  if (!authState.isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Header
          authState={authState}
          userProfile={userProfile}
          onSignIn={onSignIn}
          onSignUp={onSignUp}
          onSignOut={handleSignOut}
          currentPath="/dashboard"
          navigate={navigate}
        />
        
        <div className="pt-16 flex items-center justify-center min-h-screen px-4">
          <div className="bg-card border border-border rounded-xl p-8 shadow-lg max-w-2xl w-full">
            <div className="text-center space-y-6">
              <div className="space-y-4">
                <h2 className="text-3xl font-semibold text-card-foreground">Your Visa Journey Dashboard</h2>
                <p className="text-muted-foreground">Access your personalized visa assessment tools and track your progress towards UK immigration success.</p>
              </div>
              
              <div className="bg-muted/50 rounded-lg p-6">

                <ul className="text-left space-y-3 max-w-md mx-auto">
                  <li className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                    <span className="text-muted-foreground">Track your visa eligibility scores in real-time</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                    <span className="text-muted-foreground">Follow personalized action plans with step-by-step guidance</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                    <span className="text-muted-foreground">Check eligibility for multiple UK visa routes</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                    <span className="text-muted-foreground">Access AI-powered recommendations and insights</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                    <span className="text-muted-foreground">Monitor your progress and completed milestones</span>
                  </li>
                </ul>
              </div>
              
              <div className="space-y-4">
                <button
                  onClick={() => navigate('/')}
                  className="bg-primary text-primary-foreground px-8 py-3 rounded-lg hover:bg-primary/90 transition-colors font-medium w-full sm:w-auto"
                >
                  Sign In to Dashboard
                </button>
                
                <div>
                  <button
                    onClick={() => navigate('/')}
                    className="text-muted-foreground hover:text-foreground transition-colors underline"
                  >
                    Go Home
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header
        authState={authState}
        userProfile={userProfile}
        onSignIn={onSignIn}
        onSignUp={onSignUp}
        onSignOut={handleSignOut}
        currentPath="/dashboard"
        navigate={navigate}
      />
      
      <div className="pt-16">
        <UserDashboard 
          authState={authState}
          userProfile={userProfile}
          navigate={navigate}
        />
      </div>
    </div>
  );
}