import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { ArrowLeft, HeartHandshake, Users, FileText, CheckCircle, AlertCircle, MapPin } from 'lucide-react';

interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

interface UserProfile {
  name: string;
  email: string;
  completed_onboarding: boolean;
  [key: string]: any;
}

interface AncestryVisaGuidePageProps {
  authState: AuthState;
  userProfile: UserProfile | null;
  navigate: (path: string) => void;
}

export function AncestryVisaGuidePage({ authState, userProfile, navigate }: AncestryVisaGuidePageProps) {
  const [activeTab, setActiveTab] = useState('overview');

  const eligibleCountries = [
    'Australia', 'Canada', 'New Zealand', 'South Africa', 'Zimbabwe'
  ];

  const requirements = [
    {
      title: 'Ancestry Requirement',
      description: 'You must have a grandparent who was born in the UK',
      icon: Users,
      details: [
        'Grandparent born in UK, Channel Islands, or Isle of Man',
        'Includes Northern Ireland before 1922',
        'Adoptive grandparents may qualify',
        'Must provide birth certificates'
      ]
    },
    {
      title: 'Age Requirement',
      description: 'You must be aged 17 or over',
      icon: CheckCircle,
      details: [
        'No upper age limit',
        'Must be 17 or over when applying',
        'Different rules for those under 18'
      ]
    },
    {
      title: 'Nationality Requirement',
      description: 'You must be a Commonwealth citizen',
      icon: MapPin,
      details: [
        'Must be from a Commonwealth country',
        'Cannot be a UK citizen',
        'Must have valid passport'
      ]
    }
  ];

  const documents = [
    {
      category: 'Your Documents',
      items: [
        'Valid passport',
        'Birth certificate',
        'Marriage certificate (if applicable)',
        'Divorce decree (if applicable)'
      ]
    },
    {
      category: 'Parent\'s Documents',
      items: [
        'Birth certificate',
        'Marriage certificate',
        'Adoption papers (if applicable)'
      ]
    },
    {
      category: 'Grandparent\'s Documents',
      items: [
        'Birth certificate showing UK birth',
        'Marriage certificate',
        'Death certificate (if applicable)'
      ]
    }
  ];

  const benefits = [
    'Live and work in the UK for 5 years',
    'No restrictions on employment',
    'Bring spouse and children under 18',
    'Apply for settlement after 5 years',
    'Access to healthcare (with surcharge)',
    'Study in the UK'
  ];

  if (!authState.isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-semibold">Access Denied</h2>
          <p className="text-muted-foreground">Please sign in to access the Ancestry Visa Guide.</p>
          <Button onClick={() => navigate('/')}>Go to Home</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mobile-page-container bg-background">
      <div className="mobile-page-content">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate('/dashboard')}
                  className="mobile-back-button"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
                <div>
                  <h1 className="text-2xl font-bold flex items-center space-x-2">
                    <HeartHandshake className="w-6 h-6 text-primary" />
                    <span>UK Ancestry Visa Guide</span>
                  </h1>
                  <p className="text-muted-foreground">
                    Complete guide for Commonwealth citizens with UK ancestry
                  </p>
                </div>
              </div>
              <Badge variant="secondary" className="hidden sm:flex">
                Commonwealth Only
              </Badge>
            </div>

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="requirements">Requirements</TabsTrigger>
                <TabsTrigger value="documents">Documents</TabsTrigger>
                <TabsTrigger value="application">Application</TabsTrigger>
              </TabsList>

              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <HeartHandshake className="w-5 h-5" />
                      <span>What is the UK Ancestry Visa?</span>
                    </CardTitle>
                    <CardDescription>
                      A visa for Commonwealth citizens with UK-born grandparents
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">
                      The UK Ancestry visa allows Commonwealth citizens who have a grandparent 
                      born in the UK to live and work in the UK for up to 5 years. It's one of 
                      the most straightforward routes to UK residency for eligible applicants.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-muted/50 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Key Benefits</h4>
                        <ul className="text-sm space-y-1">
                          {benefits.map((benefit, index) => (
                            <li key={index} className="flex items-center space-x-2">
                              <CheckCircle className="w-3 h-3 text-green-500" />
                              <span>{benefit}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div className="bg-muted/50 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Eligible Countries</h4>
                        <ul className="text-sm space-y-1">
                          {eligibleCountries.map((country, index) => (
                            <li key={index} className="flex items-center space-x-2">
                              <MapPin className="w-3 h-3 text-primary" />
                              <span>{country}</span>
                            </li>
                          ))}
                        </ul>
                        <p className="text-xs text-muted-foreground mt-2">
                          + Other Commonwealth countries
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Requirements Tab */}
              <TabsContent value="requirements" className="space-y-6">
                <div className="grid gap-6">
                  {requirements.map((req, index) => (
                    <Card key={index}>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <req.icon className="w-5 h-5 text-primary" />
                          <span>{req.title}</span>
                        </CardTitle>
                        <CardDescription>{req.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {req.details.map((detail, idx) => (
                            <li key={idx} className="flex items-center space-x-2 text-sm">
                              <div className="w-2 h-2 bg-primary rounded-full"></div>
                              <span>{detail}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <AlertCircle className="w-5 h-5 text-yellow-500" />
                      <span>Important Notes</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start space-x-2">
                        <AlertCircle className="w-4 h-4 text-yellow-500 mt-0.5" />
                        <span>You cannot apply if you already have British citizenship</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <AlertCircle className="w-4 h-4 text-yellow-500 mt-0.5" />
                        <span>Great-grandparents do not qualify - it must be grandparents</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <AlertCircle className="w-4 h-4 text-yellow-500 mt-0.5" />
                        <span>You must be able to support yourself financially</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Documents Tab */}
              <TabsContent value="documents" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Required Documents</CardTitle>
                    <CardDescription>
                      All documents needed for your ancestry visa application
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-6">
                      {documents.map((doc, index) => (
                        <div key={index} className="border rounded-lg p-4">
                          <h4 className="font-semibold mb-3">{doc.category}</h4>
                          <ul className="space-y-2">
                            {doc.items.map((item, idx) => (
                              <li key={idx} className="flex items-center space-x-2 text-sm">
                                <FileText className="w-4 h-4 text-primary" />
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Document Tips</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                        <span>All documents must be original or certified copies</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                        <span>Non-English documents need official translation</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                        <span>Order documents early as processing can take time</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Application Tab */}
              <TabsContent value="application" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Application Process</CardTitle>
                    <CardDescription>
                      Step-by-step guide to applying for the UK Ancestry visa
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-muted/50 p-4 rounded-lg">
                          <h4 className="font-semibold mb-2">Application Cost</h4>
                          <p className="text-2xl font-bold text-primary">£531</p>
                          <p className="text-sm text-muted-foreground">
                            Plus healthcare surcharge (£624/year)
                          </p>
                        </div>
                        
                        <div className="bg-muted/50 p-4 rounded-lg">
                          <h4 className="font-semibold mb-2">Processing Time</h4>
                          <p className="text-2xl font-bold text-primary">3 weeks</p>
                          <p className="text-sm text-muted-foreground">
                            Standard processing time
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Next Steps</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Button 
                        onClick={() => navigate('/assessment')}
                        className="h-auto p-4 mobile-button"
                      >
                        <div className="text-center">
                          <FileText className="w-6 h-6 mx-auto mb-2" />
                          <div className="font-semibold">Check Eligibility</div>
                          <div className="text-xs opacity-80">Start your assessment</div>
                        </div>
                      </Button>
                      
                      <Button 
                        variant="outline"
                        onClick={() => navigate('/ai-assistant')}
                        className="h-auto p-4 mobile-button"
                      >
                        <div className="text-center">
                          <Users className="w-6 h-6 mx-auto mb-2" />
                          <div className="font-semibold">AI Assistant</div>
                          <div className="text-xs opacity-80">Get personalized help</div>
                        </div>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}