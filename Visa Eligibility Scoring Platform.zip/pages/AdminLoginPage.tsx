import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Shield, Lock, Mail, Eye, EyeOff, Loader2, Settings, CheckCircle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { adminAPI } from '../utils/api-client';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface AdminLoginPageProps {
  onAdminLogin: (adminAuth: any) => void;
  onBackToHome: () => void;
}

export function AdminLoginPage({ onAdminLogin, onBackToHome }: AdminLoginPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showSetup, setShowSetup] = useState(false);
  const [setupLoading, setSetupLoading] = useState(false);
  const [setupComplete, setSetupComplete] = useState(false);
  const [adminStatus, setAdminStatus] = useState<any>(null);

  // Check admin status on component mount
  useEffect(() => {
    const checkAdminStatus = async () => {
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-ca272e8b/admin/check`,
          {
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`
            }
          }
        );
        const data = await response.json();
        setAdminStatus(data);
        console.log('Admin status check:', data);
      } catch (error) {
        console.error('Failed to check admin status:', error);
      }
    };

    checkAdminStatus();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    console.log('Admin login attempt:', { email, password: '***' });

    try {
      const data = await adminAPI.login(email, password);
      console.log('Admin login successful:', data);
      toast.success('Admin login successful');
      onAdminLogin(data);
    } catch (err: any) {
      console.error('Admin login error details:', {
        error: err,
        message: err.message,
        email: email,
        hasPassword: !!password
      });
      
      const errorMessage = err.message || 'Admin login failed';
      setError(errorMessage);
      
      // If login fails with specific error, show setup option
      if (errorMessage.includes('Invalid login') || 
          errorMessage.includes('User not found') || 
          errorMessage.includes('credentials') ||
          errorMessage.includes('Email not confirmed')) {
        console.log('Showing setup option due to login failure');
        setShowSetup(true);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSetupAdmin = async () => {
    setSetupLoading(true);
    setError('');

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ca272e8b/admin/setup`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            email: 'admin@visascore.co.uk',
            password: '@Admin123',
            confirmKey: 'ADMIN_SETUP_VISA_SCORE_2025'
          })
        }
      );

      const data = await response.json();

      if (response.ok) {
        toast.success('Admin account created successfully!');
        setSetupComplete(true);
        setShowSetup(false);
        setError('');
        // Auto-fill the login form
        setEmail('admin@visascore.co.uk');
        setPassword('@Admin123');
        
        // Refresh admin status
        const statusResponse = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-ca272e8b/admin/check`,
          {
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`
            }
          }
        );
        const statusData = await statusResponse.json();
        setAdminStatus(statusData);
        
        // Show success message
        setTimeout(() => {
          setSetupComplete(false);
        }, 5000);
      } else {
        console.error('Admin setup error response:', data);
        setError(data.error || 'Failed to create admin account');
      }
    } catch (error) {
      console.error('Admin setup error:', error);
      setError('Network error - failed to create admin account');
    } finally {
      setSetupLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center space-x-2">
            <Shield className="h-8 w-8 text-primary" />
            <h1 className="text-2xl font-bold">Admin Portal</h1>
          </div>
          <p className="text-muted-foreground">
            Administrative access to Visa Score platform
          </p>
        </div>

        {/* Login Card */}
        <Card>
          <CardHeader>
            <CardTitle>Admin Login</CardTitle>
            <CardDescription>
              Enter your admin credentials to access the dashboard
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Admin Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="admin@visascore.co.uk"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter admin password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>

              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Button
                type="submit"
                className="w-full"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    Signing In...
                  </>
                ) : (
                  'Sign In to Admin Dashboard'
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Success Message */}
        {setupComplete && (
          <Alert className="border-green-500 bg-green-50/10">
            <CheckCircle className="h-4 w-4 text-green-500" />
            <AlertDescription className="text-green-500">
              ✅ Admin account created! You can now log in with the credentials above.
            </AlertDescription>
          </Alert>
        )}

        {/* Admin Status Card */}
        {adminStatus && !setupComplete && (
          <Card className={adminStatus.adminExists ? "border-green-200 bg-green-50/10" : "border-amber-200 bg-amber-50/10"}>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-sm">
                {adminStatus.adminExists ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <Settings className="h-4 w-4 text-amber-500" />
                )}
                <span>
                  {adminStatus.adminExists ? 'Admin Account Status' : 'Setup Required'}
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {adminStatus.adminExists ? (
                <div className="space-y-2">
                  <p className="text-sm text-green-600">
                    ✅ Admin account exists. You can log in above.
                  </p>
                  {adminStatus.existingAdmins.length > 0 && (
                    <div className="text-xs text-muted-foreground">
                      <p>Existing admin emails:</p>
                      <ul className="list-disc list-inside ml-2">
                        {adminStatus.existingAdmins.map((email: string) => (
                          <li key={email}>{email}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-sm text-amber-600">
                    No admin account found. Create one to access the admin panel.
                  </p>
                  <Button
                    onClick={handleSetupAdmin}
                    disabled={setupLoading}
                    className="w-full"
                    variant="outline"
                    size="sm"
                  >
                    {setupLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                        Creating Admin Account...
                      </>
                    ) : (
                      <>
                        <Settings className="w-4 h-4 mr-2" />
                        Create Admin Account
                      </>
                    )}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Setup Card - Only shown when admin login fails */}
        {showSetup && (
          <Card className="border-amber-200 bg-amber-50/10">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Settings className="h-5 w-5 text-amber-500" />
                <span>Initial Admin Setup</span>
              </CardTitle>
              <CardDescription>
                It appears no admin account exists. Click below to create the initial admin account.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="bg-muted/30 rounded-lg p-3 space-y-2">
                  <p className="text-sm font-medium">Admin Account Details:</p>
                  <div className="text-xs text-muted-foreground space-y-1">
                    <p>Email: admin@visascore.co.uk</p>
                    <p>Password: @Admin123</p>
                  </div>
                </div>
                
                <Button
                  onClick={handleSetupAdmin}
                  disabled={setupLoading}
                  className="w-full"
                  variant="outline"
                >
                  {setupLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      Creating Admin Account...
                    </>
                  ) : (
                    <>
                      <Settings className="w-4 h-4 mr-2" />
                      Create Admin Account
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Admin Instructions */}
        <Card className="bg-muted/50">
          <CardContent className="pt-6">
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <Shield className="h-5 w-5 text-amber-500 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-sm font-medium">Admin Access Requirements</p>
                  <p className="text-xs text-muted-foreground">
                    This portal is restricted to authorized administrators only. Admin access is granted to:
                  </p>
                  <ul className="text-xs text-muted-foreground list-disc list-inside space-y-1 ml-4">
                    <li>Users with email: admin@visascore.co.uk</li>
                    <li>Users with email: admin@visascore.com</li>
                    <li>Users with role: 'admin' in user metadata</li>
                    <li>Users with @visascore.com or @visascore.co.uk email domains</li>
                  </ul>
                </div>
              </div>
              
              <div className="border-t pt-3">
                <p className="text-xs text-muted-foreground">
                  All administrative activities are logged and monitored for security purposes.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Back to Home */}
        <div className="text-center">
          <Button variant="ghost" onClick={onBackToHome}>
            ← Back to Home
          </Button>
        </div>
      </div>
    </div>
  );
}