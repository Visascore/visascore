import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { ArrowLeft, Building2, CheckCircle, AlertCircle, Info } from 'lucide-react';

interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

interface UserProfile {
  name: string;
  email: string;
  completed_onboarding: boolean;
  [key: string]: any;
}

interface EndorsementCheckerPageProps {
  authState: AuthState;
  userProfile: UserProfile | null;
  navigate: (path: string) => void;
}

export function EndorsementCheckerPage({ authState, userProfile, navigate }: EndorsementCheckerPageProps) {
  const [selectedField, setSelectedField] = useState('');
  const [selectedBody, setSelectedBody] = useState('');

  const endorsingBodies = {
    'science': {
      name: 'Royal Society',
      description: 'For leaders in science and research',
      fields: ['Physics', 'Chemistry', 'Biology', 'Mathematics', 'Computer Science'],
      requirements: [
        'PhD in relevant field',
        'Significant research publications',
        'International recognition',
        'Research grants or funding'
      ],
      criteria: {
        'Exceptional Talent': [
          'Fellow of Royal Society or equivalent',
          'Major international awards',
          'Breakthrough research impact',
          'Leadership in field'
        ],
        'Exceptional Promise': [
          'Recent PhD with outstanding thesis',
          'High-impact publications',
          'Significant research potential',
          'Evidence of innovation'
        ]
      }
    },
    'engineering': {
      name: 'Royal Academy of Engineering',
      description: 'For leaders in engineering and technology',
      fields: ['Civil Engineering', 'Mechanical Engineering', 'Electrical Engineering', 'Software Engineering'],
      requirements: [
        'Engineering degree or equivalent',
        'Professional engineering experience',
        'Industry recognition',
        'Technical innovation'
      ],
      criteria: {
        'Exceptional Talent': [
          'Fellow of Royal Academy of Engineering',
          'Senior technical leadership role',
          'Major engineering achievements',
          'Industry awards and recognition'
        ],
        'Exceptional Promise': [
          'Emerging technical leader',
          'Innovative engineering solutions',
          'Professional recognition',
          'Strong career trajectory'
        ]
      }
    },
    'arts': {
      name: 'Arts Council England',
      description: 'For leaders in arts and culture',
      fields: ['Visual Arts', 'Performing Arts', 'Literature', 'Film', 'Music'],
      requirements: [
        'Portfolio of artistic work',
        'Professional recognition',
        'Media coverage',
        'Arts industry endorsements'
      ],
      criteria: {
        'Exceptional Talent': [
          'International exhibitions/performances',
          'Major arts awards',
          'Critical acclaim',
          'Cultural impact'
        ],
        'Exceptional Promise': [
          'Emerging artistic talent',
          'Growing recognition',
          'Innovative artistic work',
          'Future potential'
        ]
      }
    },
    'humanities': {
      name: 'British Academy',
      description: 'For leaders in humanities and social sciences',
      fields: ['History', 'Philosophy', 'Literature', 'Economics', 'Political Science'],
      requirements: [
        'PhD in relevant field',
        'Academic publications',
        'Research excellence',
        'Scholarly recognition'
      ],
      criteria: {
        'Exceptional Talent': [
          'Fellow of British Academy',
          'Major academic awards',
          'Influential research',
          'International recognition'
        ],
        'Exceptional Promise': [
          'Outstanding early career researcher',
          'Innovative scholarship',
          'Academic potential',
          'Research impact'
        ]
      }
    }
  };

  const fields = Object.keys(endorsingBodies);

  const getCompatibilityScore = () => {
    if (!selectedField || !selectedBody) return 0;
    
    const body = endorsingBodies[selectedField as keyof typeof endorsingBodies];
    return body ? 85 : 0;
  };

  const getRecommendations = () => {
    if (!selectedField) return [];
    
    const body = endorsingBodies[selectedField as keyof typeof endorsingBodies];
    if (!body) return [];
    
    return [
      'Review your qualifications against the criteria',
      'Gather supporting evidence and documentation',
      'Consider your route: Exceptional Talent vs Promise',
      'Prepare a strong application narrative'
    ];
  };

  if (!authState.isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-semibold">Access Denied</h2>
          <p className="text-muted-foreground">Please sign in to access the Endorsement Checker.</p>
          <Button onClick={() => navigate('/')}>Go to Home</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mobile-page-container bg-background">
      <div className="mobile-page-content">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate('/dashboard')}
                  className="mobile-back-button"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
                <div>
                  <h1 className="text-2xl font-bold flex items-center space-x-2">
                    <Building2 className="w-6 h-6 text-primary" />
                    <span>Endorsement Checker</span>
                  </h1>
                  <p className="text-muted-foreground">
                    Check your compatibility with endorsing bodies
                  </p>
                </div>
              </div>
              <Badge variant="secondary" className="hidden sm:flex">
                Global Talent
              </Badge>
            </div>

            {/* Field Selection */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Select Your Field</CardTitle>
                <CardDescription>
                  Choose the field that best matches your expertise
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Select value={selectedField} onValueChange={setSelectedField}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select your field of expertise" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="science">Science & Research</SelectItem>
                    <SelectItem value="engineering">Engineering & Technology</SelectItem>
                    <SelectItem value="arts">Arts & Culture</SelectItem>
                    <SelectItem value="humanities">Humanities & Social Sciences</SelectItem>
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>

            {/* Results */}
            {selectedField && (
              <div className="space-y-6">
                {/* Endorsing Body Info */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Building2 className="w-5 h-5 text-primary" />
                      <span>{endorsingBodies[selectedField as keyof typeof endorsingBodies].name}</span>
                    </CardTitle>
                    <CardDescription>
                      {endorsingBodies[selectedField as keyof typeof endorsingBodies].description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-semibold mb-2">Relevant Fields</h4>
                        <ul className="text-sm space-y-1">
                          {endorsingBodies[selectedField as keyof typeof endorsingBodies].fields.map((field, index) => (
                            <li key={index} className="flex items-center space-x-2">
                              <CheckCircle className="w-3 h-3 text-green-500" />
                              <span>{field}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold mb-2">Key Requirements</h4>
                        <ul className="text-sm space-y-1">
                          {endorsingBodies[selectedField as keyof typeof endorsingBodies].requirements.map((req, index) => (
                            <li key={index} className="flex items-center space-x-2">
                              <div className="w-2 h-2 bg-primary rounded-full"></div>
                              <span>{req}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Criteria Breakdown */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span>Exceptional Talent</span>
                      </CardTitle>
                      <CardDescription>
                        Already established as a leader
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {endorsingBodies[selectedField as keyof typeof endorsingBodies].criteria['Exceptional Talent'].map((criterion, index) => (
                          <li key={index} className="flex items-start space-x-2 text-sm">
                            <div className="w-2 h-2 bg-green-500 rounded-full mt-1.5"></div>
                            <span>{criterion}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <AlertCircle className="w-5 h-5 text-blue-500" />
                        <span>Exceptional Promise</span>
                      </CardTitle>
                      <CardDescription>
                        Emerging talent with potential
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {endorsingBodies[selectedField as keyof typeof endorsingBodies].criteria['Exceptional Promise'].map((criterion, index) => (
                          <li key={index} className="flex items-start space-x-2 text-sm">
                            <div className="w-2 h-2 bg-blue-500 rounded-full mt-1.5"></div>
                            <span>{criterion}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>

                {/* Compatibility Score */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Info className="w-5 h-5 text-primary" />
                      <span>Compatibility Analysis</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Field Match</span>
                        <Badge variant="default">
                          {getCompatibilityScore()}% Compatible
                        </Badge>
                      </div>
                      
                      <div className="bg-muted/50 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Recommendations</h4>
                        <ul className="text-sm space-y-1">
                          {getRecommendations().map((rec, index) => (
                            <li key={index} className="flex items-start space-x-2">
                              <CheckCircle className="w-3 h-3 text-green-500 mt-0.5" />
                              <span>{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Next Steps */}
                <Card>
                  <CardHeader>
                    <CardTitle>Next Steps</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Button 
                        onClick={() => navigate('/global-talent-guide')}
                        className="h-auto p-4 mobile-button"
                      >
                        <div className="text-center">
                          <Building2 className="w-6 h-6 mx-auto mb-2" />
                          <div className="font-semibold">Full Guide</div>
                          <div className="text-xs opacity-80">Complete requirements</div>
                        </div>
                      </Button>
                      
                      <Button 
                        variant="outline"
                        onClick={() => navigate('/assessment')}
                        className="h-auto p-4 mobile-button"
                      >
                        <div className="text-center">
                          <CheckCircle className="w-6 h-6 mx-auto mb-2" />
                          <div className="font-semibold">Assessment</div>
                          <div className="text-xs opacity-80">Check eligibility</div>
                        </div>
                      </Button>
                      
                      <Button 
                        variant="outline"
                        onClick={() => navigate('/ai-assistant')}
                        className="h-auto p-4 mobile-button"
                      >
                        <div className="text-center">
                          <Info className="w-6 h-6 mx-auto mb-2" />
                          <div className="font-semibold">AI Assistant</div>
                          <div className="text-xs opacity-80">Get advice</div>
                        </div>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}