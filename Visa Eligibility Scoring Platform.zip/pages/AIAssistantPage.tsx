import { useState, useEffect, useRef } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Badge } from '../components/ui/badge';
import { Separator } from '../components/ui/separator';
import { Header } from '../components/Header';
import { 
  MessageSquare, 
  Send, 
  Bot, 
  User, 
  Loader2, 
  Sparkles,
  MessageCircle,
  Target,
  FileText,
  AlertTriangle
} from 'lucide-react';
import { createClient } from '../utils/supabase/client';
import { projectId } from '../utils/supabase/info';
import { toast } from 'sonner@2.0.3';

interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

interface UserProfile {
  name: string;
  email: string;
  completed_onboarding: boolean;
  [key: string]: any;
}

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  recommendations?: VisaRecommendation[];
}

interface VisaRecommendation {
  visaRoute: string;
  matchScore: number;
  reasoning: string;
  nextSteps: string[];
}

interface AIAssistantPageProps {
  authState: AuthState;
  userProfile: UserProfile | null;
  navigate: (path: string) => void;
  onSignIn?: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  onSignUp?: (email: string, password: string, name: string) => Promise<{ success: boolean; error?: string }>;
  onSignOut?: () => void;
}

export function AIAssistantPage({ authState, userProfile, navigate, onSignIn, onSignUp, onSignOut }: AIAssistantPageProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [chatHistory, setChatHistory] = useState<any[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const supabase = createClient();

  useEffect(() => {
    if (authState.isAuthenticated) {
      loadChatHistory();
    }
    
    // Add welcome message
    const welcomeMessage: Message = {
      id: 'welcome',
      content: `Hello${userProfile?.name ? ` ${userProfile.name}` : ''}! 👋 

I'm your AI Visa Assistant, here to help you navigate UK visa requirements and find the best route for your situation.

I can help you with:
• **Visa route recommendations** based on your profile
• **Detailed requirement explanations** for any UK visa
• **Application guidance** and document preparation
• **Eligibility assessments** and improvement suggestions

What would you like to know about UK visas today?`,
      sender: 'ai',
      timestamp: new Date()
    };
    
    setMessages([welcomeMessage]);
  }, [authState.isAuthenticated, userProfile]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadChatHistory = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ca272e8b/chat-history`,
        {
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        setChatHistory(data.history || []);
      }
    } catch (error) {
      console.error('Error loading chat history:', error);
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    if (!authState.isAuthenticated) {
      toast.error('Please sign in to use the AI assistant');
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage.trim(),
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No active session');
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ca272e8b/chat`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            message: inputMessage.trim(),
            context: {
              userProfile,
              previousMessages: messages.slice(-5) // Include last 5 messages for context
            }
          })
        }
      );

      if (!response.ok) {
        throw new Error('Failed to get AI response');
      }

      const data = await response.json();

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: data.response,
        sender: 'ai',
        timestamp: new Date(),
        recommendations: data.recommendations
      };

      setMessages(prev => [...prev, aiMessage]);
      
      // Reload chat history to include the new messages
      await loadChatHistory();

    } catch (error) {
      console.error('AI chat error:', error);
      toast.error('Failed to get AI response. Please try again.');
      
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: 'I apologize, but I encountered an error. Please try asking your question again.',
        sender: 'ai',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleRecommendationClick = (recommendation: VisaRecommendation) => {
    // Navigate to visa routes page and highlight the recommended route
    navigate('/visa-routes');
    toast.success(`Navigating to ${recommendation.visaRoute} information`);
  };

  const handleSignOut = () => {
    console.log('Sign out requested from AI assistant');
    if (onSignOut) {
      onSignOut();
    }
  };

  if (!authState.isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Header
          authState={authState}
          userProfile={userProfile}
          onSignIn={onSignIn}
          onSignUp={onSignUp}
          onSignOut={handleSignOut}
          currentPath="/ai-assistant"
          navigate={navigate}
        />
        
        <div className="pt-16 flex items-center justify-center min-h-[80vh]">
          <Card className="max-w-md w-full mx-4">
            <CardHeader className="text-center">
              <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Bot className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>AI Visa Assistant</CardTitle>
              <CardDescription>
                Sign in to get personalized visa guidance and recommendations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="text-sm text-muted-foreground">
                  <p className="mb-2">Get help with:</p>
                  <ul className="space-y-1">
                    <li>• Visa route recommendations</li>
                    <li>• Requirement explanations</li>
                    <li>• Application guidance</li>
                    <li>• Document preparation</li>
                  </ul>
                </div>
                <Button 
                  onClick={() => navigate('/')} 
                  className="w-full"
                >
                  Sign In to Continue
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background mobile-constrain">
      <Header
        authState={authState}
        userProfile={userProfile}
        onSignIn={onSignIn}
        onSignUp={onSignUp}
        onSignOut={handleSignOut}
        currentPath="/ai-assistant"
        navigate={navigate}
      />
      
      <div className="pt-16 mobile-chat-container">
        <div className="mobile-chat-messages">
          <div className="max-w-4xl mx-auto space-y-4">
            {/* Header */}
            <div className="text-center py-6 border-b border-border">
              <div className="flex items-center justify-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                  <Bot className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold">AI Visa Assistant</h1>
                  <p className="text-muted-foreground">Your personal UK visa expert</p>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="space-y-6 py-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex items-start space-x-3 ${
                    message.sender === 'user' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  {message.sender === 'ai' && (
                    <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <Bot className="w-4 h-4 text-primary" />
                    </div>
                  )}
                  
                  <div className={`max-w-[85%] mobile-text-wrap ${
                    message.sender === 'user' 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-card border'
                  } rounded-lg p-4`}>
                    <div className="whitespace-pre-wrap mobile-long-text">{message.content}</div>
                    
                    {message.recommendations && message.recommendations.length > 0 && (
                      <div className="mt-4 space-y-3">
                        <Separator />
                        <div>
                          <h4 className="font-medium mb-3 flex items-center space-x-2">
                            <Target className="w-4 h-4" />
                            <span>Recommended Visa Routes</span>
                          </h4>
                          <div className="space-y-2">
                            {message.recommendations.map((rec, index) => (
                              <Card key={index} className="mobile-card cursor-pointer hover:bg-accent/50 transition-colors" onClick={() => handleRecommendationClick(rec)}>
                                <CardContent className="p-3">
                                  <div className="flex items-center justify-between mb-2">
                                    <h5 className="font-medium">{rec.visaRoute}</h5>
                                    <Badge variant="secondary">{rec.matchScore}% match</Badge>
                                  </div>
                                  <p className="text-sm text-muted-foreground mb-2">{rec.reasoning}</p>
                                  {rec.nextSteps.length > 0 && (
                                    <div className="text-xs text-muted-foreground">
                                      Next: {rec.nextSteps[0]}
                                    </div>
                                  )}
                                </CardContent>
                              </Card>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <div className="text-xs text-muted-foreground mt-2">
                      {message.timestamp.toLocaleTimeString()}
                    </div>
                  </div>
                  
                  {message.sender === 'user' && (
                    <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center flex-shrink-0">
                      <User className="w-4 h-4" />
                    </div>
                  )}
                </div>
              ))}
              
              {isLoading && (
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                    <Bot className="w-4 h-4 text-primary" />
                  </div>
                  <div className="bg-card border rounded-lg p-4">
                    <div className="flex items-center space-x-2">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span className="text-sm text-muted-foreground">AI is thinking...</span>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
          </div>
        </div>

        {/* Input Area */}
        <div className="mobile-chat-input">
          <div className="max-w-4xl mx-auto">
            <div className="flex space-x-2">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask me anything about UK visas..."
                disabled={isLoading}
                className="flex-1 mobile-form"
              />
              <Button 
                onClick={handleSendMessage}
                disabled={isLoading || !inputMessage.trim()}
                size="sm"
                className="mobile-button touch-target"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            
            <div className="mt-2 text-xs text-muted-foreground text-center">
              AI responses are for guidance only. Always verify with official UKVI sources.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}