import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Alert, AlertDescription } from '../components/ui/alert';
import { CheckCircle, Clock, TrendingUp, AlertTriangle, LogIn, Shield } from 'lucide-react';
import { visaRoutes, VisaRoute } from '../data/visaRoutes';
import { EligibilityQuestionnaire } from '../components/EligibilityQuestionnaire';
import { AuthModal } from '../components/AuthModal';

interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

interface UserProfile {
  name: string;
  email: string;
  completed_onboarding: boolean;
  [key: string]: any;
}

interface EligibilityAssessmentPageProps {
  authState: AuthState;
  userProfile: UserProfile | null;
  navigate: (path: string) => void;
  onSignIn?: (email: string, password: string) => Promise<any>;
  onSignUp?: (email: string, password: string, name: string) => Promise<any>;
}

export function EligibilityAssessmentPage({ 
  authState, 
  userProfile, 
  navigate, 
  onSignIn, 
  onSignUp 
}: EligibilityAssessmentPageProps) {
  const [selectedRoute, setSelectedRoute] = useState<VisaRoute | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Check if user session is valid
  useEffect(() => {
    if (authState.user && !authState.session?.access_token) {
      console.warn('User exists but no valid session token found');
      setAuthError('Session expired. Please sign in again.');
    }
  }, [authState.user, authState.session]);

  // Show loading state
  if (authState.isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground">Loading authentication status...</p>
        </div>
      </div>
    );
  }

  // Show authentication required screen
  if (!authState.user || !authState.session?.access_token) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="container mx-auto px-4">
          <div className="max-w-md mx-auto text-center space-y-6">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
              <Shield className="w-8 h-8 text-primary" />
            </div>
            
            <div className="space-y-2">
              <h2 className="text-2xl font-bold">Authentication Required</h2>
              <p className="text-muted-foreground">
                Please sign in to access the Visa Eligibility Checker. Your assessment results will be securely stored and personalized.
              </p>
            </div>

            {authError && (
              <Alert className="border-red-200 bg-red-50 dark:bg-red-950/20">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800 dark:text-red-200">
                  {authError}
                </AlertDescription>
              </Alert>
            )}

            <div className="space-y-3">
              <Button 
                onClick={() => setShowAuthModal(true)}
                className="w-full"
                size="lg"
              >
                <LogIn className="w-4 h-4 mr-2" />
                Sign In to Continue
              </Button>
              
              <p className="text-sm text-muted-foreground">
                New user? You can create an account during the sign-in process.
              </p>
            </div>

            <div className="border-t pt-6">
              <div className="text-left space-y-2 text-sm text-muted-foreground">
                <h4 className="font-medium text-foreground">Why sign in?</h4>
                <ul className="space-y-1">
                  <li>• Save your assessment results</li>
                  <li>• Get personalized recommendations</li>
                  <li>• Track your application progress</li>
                  <li>• Access AI-powered insights</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {showAuthModal && onSignIn && onSignUp && (
          <AuthModal
            isOpen={showAuthModal}
            onClose={() => setShowAuthModal(false)}
            onSignIn={onSignIn}
            onSignUp={onSignUp}
            title="Sign In to Continue"
            subtitle="Access your personalized visa eligibility assessment"
          />
        )}
      </div>
    );
  }

  // Validate session token before proceeding
  if (!authState.session?.access_token) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <AlertTriangle className="w-12 h-12 mx-auto text-yellow-500" />
          <h2 className="text-2xl font-semibold">Session Error</h2>
          <p className="text-muted-foreground">
            Authentication session is invalid. Please sign in again.
          </p>
          <Button onClick={() => setShowAuthModal(true)}>
            Sign In Again
          </Button>
        </div>
      </div>
    );
  }

  // Create user object in the format expected by EligibilityQuestionnaire
  const user = {
    id: authState.user.id,
    email: authState.user.email,
    name: userProfile?.name || authState.user.user_metadata?.name || 'User'
  };

  if (selectedRoute) {
    return (
      <EligibilityQuestionnaire 
        route={selectedRoute}
        onBack={() => setSelectedRoute(null)}
        onComplete={(answers, assessment) => {
          console.log('Assessment completed:', assessment);
          // Navigation is handled within the questionnaire component
        }}
        navigate={navigate}
        user={user} // Ensure user is passed
      />
    );
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'Medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400';
      case 'Hard': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Work': return <TrendingUp className="w-4 h-4" />;
      case 'Education': return <CheckCircle className="w-4 h-4" />;
      case 'Family': return <CheckCircle className="w-4 h-4" />;
      case 'Visit': return <Clock className="w-4 h-4" />;
      default: return <CheckCircle className="w-4 h-4" />;
    }
  };

  return (
    <div className="mobile-page-container bg-background">
      <div className="mobile-page-content">
        <div className="container mx-auto px-4 py-4 md:py-8">
          <div className="max-w-4xl mx-auto">
            {/* Header */}
            <div className="text-center mb-8">
              <div className="flex items-center justify-center space-x-2 mb-4">
                <CheckCircle className="w-8 h-8 text-primary" />
                <h1 className="text-3xl font-bold">Visa Eligibility Checker</h1>
              </div>
              <p className="text-muted-foreground">
                Select a visa route to check your eligibility with our AI-powered assessment
              </p>
            </div>

            {/* User Welcome */}
            <div className="mb-6">
              <Alert className="border-primary/20 bg-primary/5">
                <Shield className="h-4 w-4 text-primary" />
                <AlertDescription>
                  Welcome back, <strong>{user.name}</strong>! Your assessment results will be saved to your account.
                </AlertDescription>
              </Alert>
            </div>

            {/* Visa Routes Grid */}
            <div className="grid gap-4 md:gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
              {visaRoutes.map((route) => (
                <Card 
                  key={route.id} 
                  className="cursor-pointer transition-all duration-200 hover:shadow-lg hover:scale-[1.02] group"
                  onClick={() => setSelectedRoute(route)}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        {getCategoryIcon(route.category)}
                        <Badge variant="outline" className="text-xs">
                          {route.category}
                        </Badge>
                      </div>
                      <Badge className={`text-xs ${getDifficultyColor(route.difficulty)}`}>
                        {route.difficulty}
                      </Badge>
                    </div>
                    <CardTitle className="text-lg group-hover:text-primary transition-colors">
                      {route.name}
                    </CardTitle>
                    <CardDescription className="text-sm line-clamp-2">
                      {route.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Processing Time:</span>
                        <span className="font-medium">{route.processingTime}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Questions:</span>
                        <span className="font-medium">{route.questions.length}</span>
                      </div>
                      {route.minSalary && (
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Min. Salary:</span>
                          <span className="font-medium">£{route.minSalary.toLocaleString()}</span>
                        </div>
                      )}
                    </div>
                    <Button 
                      className="w-full mt-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                      variant="outline"
                    >
                      Start Assessment
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Info Section */}
            <div className="mt-8 p-6 bg-primary/5 rounded-lg border border-primary/20">
              <h3 className="text-lg font-semibold mb-2">How it works</h3>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-primary font-bold text-sm">1</span>
                  </div>
                  <div>
                    <h4 className="font-medium">Choose Route</h4>
                    <p className="text-sm text-muted-foreground">Select the visa route that matches your situation</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-primary font-bold text-sm">2</span>
                  </div>
                  <div>
                    <h4 className="font-medium">Answer Questions</h4>
                    <p className="text-sm text-muted-foreground">Complete our detailed eligibility questionnaire</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-primary font-bold text-sm">3</span>
                  </div>
                  <div>
                    <h4 className="font-medium">Get Results</h4>
                    <p className="text-sm text-muted-foreground">Receive your personalized eligibility score and AI-powered recommendations</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}