import { HeroSection } from '../components/home/HeroSection';
import { ServicesSection } from '../components/home/ServicesSection';
import { WhyChooseSection } from '../components/home/WhyChooseSection';
import { SuccessStoriesSection } from '../components/home/SuccessStoriesSection';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';

interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

interface UserProfile {
  name: string;
  email: string;
  completed_onboarding: boolean;
  [key: string]: any;
}

interface HomePageProps {
  authState: AuthState;
  userProfile: UserProfile | null;
  onSignIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  onSignUp: (email: string, password: string, name: string) => Promise<{ success: boolean; error?: string }>;
  onSignOut: () => void;
  navigate: (path: string) => void;
}

export function HomePage({ 
  authState, 
  userProfile, 
  onSignIn, 
  onSignUp, 
  onSignOut, 
  navigate 
}: HomePageProps) {
  return (
    <div className="min-h-screen bg-background">
      <Header
        authState={authState}
        userProfile={userProfile}
        onSignIn={onSignIn}
        onSignUp={onSignUp}
        onSignOut={onSignOut}
        currentPath="/"
        navigate={navigate}
      />
      
      <div className="pt-16">
        <HeroSection
          authState={authState}
          userProfile={userProfile}
          onSignIn={onSignIn}
          onSignUp={onSignUp}
          navigate={navigate}
        />
        <ServicesSection 
          onServiceClick={(href) => navigate(href)}
        />
        <WhyChooseSection />
        <SuccessStoriesSection />
      </div>
      
      <Footer onAdminLogin={() => navigate('/admin/login')} />
    </div>
  );
}