import { SmartVisaRecommendations } from '../components/SmartVisaRecommendations';

interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

interface UserProfile {
  name: string;
  email: string;
  completed_onboarding: boolean;
  has_used_trial?: boolean;
  [key: string]: any;
}

interface SmartRecommendationsPageProps {
  authState: AuthState;
  userProfile: UserProfile | null;
  navigate: (path: string) => void;
}

export function SmartRecommendationsPage({ authState, userProfile, navigate }: SmartRecommendationsPageProps) {
  if (!authState.isAuthenticated || !authState.user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-semibold">Access Denied</h2>
          <p className="text-muted-foreground">Please sign in to view smart recommendations.</p>
          <button 
            onClick={() => navigate('home')}
            className="bg-primary text-primary-foreground px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors"
          >
            Go Home
          </button>
        </div>
      </div>
    );
  }

  // Create user object in expected format
  const user = {
    id: authState.user.id,
    email: authState.user.email,
    name: userProfile?.name || authState.user.user_metadata?.name
  };

  return (
    <div className="min-h-screen bg-background">
      <SmartVisaRecommendations user={user} navigate={navigate} />
    </div>
  );
}