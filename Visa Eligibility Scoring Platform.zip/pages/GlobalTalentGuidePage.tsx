import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { ArrowLeft, Star, Award, Users, FileText, CheckCircle, AlertCircle, Clock } from 'lucide-react';

interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

interface UserProfile {
  name: string;
  email: string;
  completed_onboarding: boolean;
  [key: string]: any;
}

interface GlobalTalentGuidePageProps {
  authState: AuthState;
  userProfile: UserProfile | null;
  navigate: (path: string) => void;
}

export function GlobalTalentGuidePage({ authState, userProfile, navigate }: GlobalTalentGuidePageProps) {
  const [activeTab, setActiveTab] = useState('overview');

  const endorsingBodies = [
    {
      name: 'Royal Academy of Engineering',
      field: 'Engineering',
      description: 'For leaders in engineering innovation and research',
      requirements: ['PhD in Engineering', 'Published research', 'Industry recognition']
    },
    {
      name: 'Arts Council England',
      field: 'Arts & Culture',
      description: 'For exceptional artists and cultural leaders',
      requirements: ['Portfolio of work', 'Awards/recognition', 'Media coverage']
    },
    {
      name: 'British Academy',
      field: 'Humanities & Social Sciences',
      description: 'For academics and researchers in humanities',
      requirements: ['PhD qualification', 'Published work', 'Academic recognition']
    },
    {
      name: 'Royal Society',
      field: 'Science & Research',
      description: 'For leading scientists and researchers',
      requirements: ['Scientific publications', 'Research grants', 'Peer recognition']
    }
  ];

  const requirements = [
    {
      category: 'Exceptional Talent',
      description: 'Already established as a leader in your field',
      criteria: [
        'International recognition',
        'Awards and honors',
        'Published work or patents',
        'Leadership roles'
      ]
    },
    {
      category: 'Exceptional Promise',
      description: 'Emerging talent with potential to become a leader',
      criteria: [
        'Recent significant achievements',
        'Potential for leadership',
        'Innovation in your field',
        'Future impact potential'
      ]
    }
  ];

  const applicationProcess = [
    {
      step: 1,
      title: 'Endorsement Application',
      description: 'Apply to the relevant endorsing body',
      timeframe: '8-12 weeks',
      status: 'critical'
    },
    {
      step: 2,
      title: 'Endorsement Review',
      description: 'Endorsing body reviews your application',
      timeframe: '6-8 weeks',
      status: 'warning'
    },
    {
      step: 3,
      title: 'Visa Application',
      description: 'Submit visa application with endorsement',
      timeframe: '3-4 weeks',
      status: 'success'
    }
  ];

  if (!authState.isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-semibold">Access Denied</h2>
          <p className="text-muted-foreground">Please sign in to access the Global Talent Guide.</p>
          <Button onClick={() => navigate('/')}>Go to Home</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mobile-page-container bg-background">
      <div className="mobile-page-content">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate('/dashboard')}
                  className="mobile-back-button"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
                <div>
                  <h1 className="text-2xl font-bold flex items-center space-x-2">
                    <Star className="w-6 h-6 text-primary" />
                    <span>Global Talent Visa Guide</span>
                  </h1>
                  <p className="text-muted-foreground">
                    Complete guide for exceptional talent and promise visas
                  </p>
                </div>
              </div>
              <Badge variant="secondary" className="hidden sm:flex">
                Premium Guide
              </Badge>
            </div>

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="requirements">Requirements</TabsTrigger>
                <TabsTrigger value="endorsing">Endorsing Bodies</TabsTrigger>
                <TabsTrigger value="process">Process</TabsTrigger>
              </TabsList>

              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Award className="w-5 h-5" />
                      <span>What is the Global Talent Visa?</span>
                    </CardTitle>
                    <CardDescription>
                      A visa route for exceptional talent and promise in specific fields
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">
                      The Global Talent visa is designed for leaders or potential leaders in academia, 
                      research, arts, culture, and digital technology. It offers a fast-track route to 
                      settlement for those who can demonstrate exceptional talent or promise.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-muted/50 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Key Benefits</h4>
                        <ul className="text-sm space-y-1">
                          <li>• No job offer required</li>
                          <li>• Fast track to settlement (3 years)</li>
                          <li>• No salary requirements</li>
                          <li>• Bring dependents</li>
                          <li>• Work flexibility</li>
                        </ul>
                      </div>
                      
                      <div className="bg-muted/50 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Eligible Fields</h4>
                        <ul className="text-sm space-y-1">
                          <li>• Science & Research</li>
                          <li>• Engineering</li>
                          <li>• Arts & Culture</li>
                          <li>• Digital Technology</li>
                          <li>• Humanities</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Requirements Tab */}
              <TabsContent value="requirements" className="space-y-6">
                <div className="grid gap-6">
                  {requirements.map((req, index) => (
                    <Card key={index}>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <CheckCircle className="w-5 h-5 text-green-500" />
                          <span>{req.category}</span>
                        </CardTitle>
                        <CardDescription>{req.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {req.criteria.map((criterion, idx) => (
                            <li key={idx} className="flex items-center space-x-2 text-sm">
                              <div className="w-2 h-2 bg-primary rounded-full"></div>
                              <span>{criterion}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* Endorsing Bodies Tab */}
              <TabsContent value="endorsing" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Endorsing Bodies</CardTitle>
                    <CardDescription>
                      You must get endorsement from one of these approved bodies
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4">
                      {endorsingBodies.map((body, index) => (
                        <div key={index} className="border rounded-lg p-4">
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-semibold">{body.name}</h4>
                            <Badge variant="outline">{body.field}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-3">
                            {body.description}
                          </p>
                          <div>
                            <h5 className="font-medium text-sm mb-1">Key Requirements:</h5>
                            <ul className="text-sm space-y-1">
                              {body.requirements.map((req, idx) => (
                                <li key={idx} className="flex items-center space-x-2">
                                  <div className="w-1.5 h-1.5 bg-primary rounded-full"></div>
                                  <span>{req}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Process Tab */}
              <TabsContent value="process" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Application Process</CardTitle>
                    <CardDescription>
                      Step-by-step guide to applying for the Global Talent visa
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {applicationProcess.map((step, index) => (
                        <div key={index} className="flex items-start space-x-4">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold text-white ${
                            step.status === 'critical' ? 'bg-red-500' :
                            step.status === 'warning' ? 'bg-yellow-500' :
                            'bg-green-500'
                          }`}>
                            {step.step}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold">{step.title}</h4>
                            <p className="text-sm text-muted-foreground mb-2">
                              {step.description}
                            </p>
                            <div className="flex items-center space-x-2">
                              <Clock className="w-4 h-4 text-muted-foreground" />
                              <span className="text-sm text-muted-foreground">
                                {step.timeframe}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Next Steps</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Button 
                        onClick={() => navigate('/assessment')}
                        className="h-auto p-4 mobile-button"
                      >
                        <div className="text-center">
                          <FileText className="w-6 h-6 mx-auto mb-2" />
                          <div className="font-semibold">Start Assessment</div>
                          <div className="text-xs opacity-80">Check your eligibility</div>
                        </div>
                      </Button>
                      
                      <Button 
                        variant="outline"
                        onClick={() => navigate('/ai-assistant')}
                        className="h-auto p-4 mobile-button"
                      >
                        <div className="text-center">
                          <Users className="w-6 h-6 mx-auto mb-2" />
                          <div className="font-semibold">AI Assistant</div>
                          <div className="text-xs opacity-80">Get personalized advice</div>
                        </div>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}