import { EligibilityResults } from '../components/EligibilityResults';

interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

interface EligibilityResultsPageProps {
  authState: AuthState;
  navigate: (path: string) => void;
}

export function EligibilityResultsPage({ authState, navigate }: EligibilityResultsPageProps) {
  if (!authState.isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-semibold">Access Denied</h2>
          <p className="text-muted-foreground">Please sign in to view your results.</p>
          <button
            onClick={() => navigate('home')}
            className="bg-primary text-primary-foreground px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors"
          >
            Go Home
          </button>
        </div>
      </div>
    );
  }

  // Get assessment data from localStorage
  const assessmentData = localStorage.getItem('lastAssessment');
  
  if (!assessmentData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-semibold">No Assessment Data</h2>
          <p className="text-muted-foreground">Please complete an eligibility assessment first to view your results.</p>
          <button
            onClick={() => navigate('eligibility-assessment')}
            className="bg-primary text-primary-foreground px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors mr-4"
          >
            Take Assessment
          </button>
          <button
            onClick={() => navigate('dashboard')}
            className="bg-secondary text-secondary-foreground px-6 py-2 rounded-lg hover:bg-secondary/90 transition-colors"
          >
            Dashboard
          </button>
        </div>
      </div>
    );
  }

  let parsedData;
  try {
    parsedData = JSON.parse(assessmentData);
  } catch (error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-semibold">Invalid Assessment Data</h2>
          <p className="text-muted-foreground">Please take a new assessment.</p>
          <button
            onClick={() => navigate('eligibility-assessment')}
            className="bg-primary text-primary-foreground px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors"
          >
            Take Assessment
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <EligibilityResults 
        route={parsedData.route}
        answers={parsedData.answers}
        score={parsedData.assessment?.overallScore || parsedData.score || 0}
        assessment={parsedData.assessment}
        actionPlan={parsedData.actionPlan}
        ukviApplicationUrl={parsedData.ukviApplicationUrl}
        onBack={() => navigate('visa-routes')}
        onRetakeQuiz={() => navigate('visa-routes')}
        onCheckAnotherRoute={() => navigate('visa-routes')}
        onStartActionPlan={() => {
          // Data is already stored in localStorage, navigate to action plan
          navigate('action-plan');
        }}
      />
    </div>
  );
}