import { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Label } from '../components/ui/label';
import { 
  CheckCircle, 
  AlertCircle, 
  Loader2, 
  Mail, 
  Lock,
  Eye,
  EyeOff
} from 'lucide-react';
import { createClient } from '../utils/supabase/client';
import { toast } from 'sonner@2.0.3';

interface EmailConfirmationPageProps {
  navigate: (path: string) => void;
}

export function EmailConfirmationPage({ navigate }: EmailConfirmationPageProps) {
  const [isConfirming, setIsConfirming] = useState(true);
  const [confirmationStatus, setConfirmationStatus] = useState<'confirming' | 'success' | 'error' | 'expired'>('confirming');
  const [errorMessage, setErrorMessage] = useState('');
  const [showSignIn, setShowSignIn] = useState(false);
  
  // Sign in form state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSigningIn, setIsSigningIn] = useState(false);

  const supabase = createClient();

  useEffect(() => {
    handleEmailConfirmation();
  }, []);

  const handleEmailConfirmation = async () => {
    try {
      // Get the hash from the URL (contains the confirmation token)
      const hashParams = new URLSearchParams(window.location.hash.substring(1));
      const accessToken = hashParams.get('access_token');
      const refreshToken = hashParams.get('refresh_token');
      const type = hashParams.get('type');

      if (!accessToken || !refreshToken || type !== 'signup') {
        setConfirmationStatus('error');
        setErrorMessage('Invalid or missing confirmation link. Please check your email and try again.');
        return;
      }

      // Set the session with the tokens from the URL
      const { data, error } = await supabase.auth.setSession({
        access_token: accessToken,
        refresh_token: refreshToken
      });

      if (error) {
        console.error('Email confirmation error:', error);
        
        if (error.message.includes('expired')) {
          setConfirmationStatus('expired');
          setErrorMessage('This confirmation link has expired. Please request a new verification email.');
        } else {
          setConfirmationStatus('error');
          setErrorMessage(error.message || 'Failed to confirm your email. Please try again.');
        }
      } else if (data.user) {
        setConfirmationStatus('success');
        // Pre-fill the email for sign in
        setEmail(data.user.email || '');
        
        // Show success message
        toast.success('Email confirmed successfully! Please sign in to continue.');
        
        // Show sign in form after a brief delay
        setTimeout(() => {
          setShowSignIn(true);
        }, 2000);
      } else {
        setConfirmationStatus('error');
        setErrorMessage('Unexpected error during confirmation. Please try again.');
      }
    } catch (error) {
      console.error('Email confirmation error:', error);
      setConfirmationStatus('error');
      setErrorMessage('An unexpected error occurred. Please try again.');
    } finally {
      setIsConfirming(false);
    }
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email.trim() || !password.trim()) {
      toast.error('Please fill in all fields');
      return;
    }

    setIsSigningIn(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password: password.trim()
      });

      if (error) {
        console.error('Sign in error:', error);
        toast.error(error.message || 'Failed to sign in. Please check your credentials.');
      } else if (data.user) {
        toast.success('Signed in successfully! Redirecting...');
        
        // Clear the hash from URL to clean up
        window.history.replaceState(null, '', window.location.pathname);
        
        // Navigate to dashboard or home
        setTimeout(() => {
          navigate('dashboard');
        }, 1500);
      }
    } catch (error) {
      console.error('Sign in error:', error);
      toast.error('An unexpected error occurred. Please try again.');
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleResendVerification = async () => {
    if (!email.trim()) {
      toast.error('Please enter your email address');
      return;
    }

    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: email.trim()
      });

      if (error) {
        toast.error(error.message || 'Failed to resend verification email');
      } else {
        toast.success('Verification email sent! Please check your inbox.');
      }
    } catch (error) {
      console.error('Resend verification error:', error);
      toast.error('Failed to resend verification email');
    }
  };

  const renderConfirmationStatus = () => {
    switch (confirmationStatus) {
      case 'confirming':
        return (
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
              <CardTitle>Confirming Your Email</CardTitle>
              <CardDescription>
                Please wait while we verify your email address...
              </CardDescription>
            </CardHeader>
          </Card>
        );

      case 'success':
        return (
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/20">
                <CheckCircle className="h-8 w-8 text-green-600 dark:text-green-400" />
              </div>
              <CardTitle className="text-green-800 dark:text-green-200">Email Confirmed!</CardTitle>
              <CardDescription>
                Your email has been successfully verified. You can now sign in to your account.
              </CardDescription>
            </CardHeader>
            {!showSignIn && (
              <CardContent className="text-center">
                <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Preparing sign in form...</span>
                </div>
              </CardContent>
            )}
          </Card>
        );

      case 'expired':
        return (
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-yellow-100 dark:bg-yellow-900/20">
                <AlertCircle className="h-8 w-8 text-yellow-600 dark:text-yellow-400" />
              </div>
              <CardTitle className="text-yellow-800 dark:text-yellow-200">Link Expired</CardTitle>
              <CardDescription>
                This confirmation link has expired. Please request a new verification email.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address"
                  className="mobile-form"
                />
              </div>
              <Button 
                onClick={handleResendVerification}
                className="w-full"
              >
                <Mail className="mr-2 h-4 w-4" />
                Resend Verification Email
              </Button>
              <Button 
                variant="outline"
                onClick={() => navigate('home')}
                className="w-full"
              >
                Go to Home
              </Button>
            </CardContent>
          </Card>
        );

      case 'error':
        return (
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/20">
                <AlertCircle className="h-8 w-8 text-red-600 dark:text-red-400" />
              </div>
              <CardTitle className="text-red-800 dark:text-red-200">Confirmation Failed</CardTitle>
              <CardDescription>
                We couldn't confirm your email address.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  {errorMessage}
                </AlertDescription>
              </Alert>
              
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address"
                  className="mobile-form"
                />
              </div>
              
              <div className="grid gap-2">
                <Button 
                  onClick={handleResendVerification}
                  className="w-full"
                >
                  <Mail className="mr-2 h-4 w-4" />
                  Resend Verification Email
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => navigate('home')}
                  className="w-full"
                >
                  Go to Home
                </Button>
              </div>
            </CardContent>
          </Card>
        );

      default:
        return null;
    }
  };

  const renderSignInForm = () => {
    if (!showSignIn || confirmationStatus !== 'success') return null;

    return (
      <Card className="w-full max-w-md mt-6">
        <CardHeader className="text-center">
          <CardTitle>Sign In to Continue</CardTitle>
          <CardDescription>
            Use your email and password to access your account
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSignIn} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="signin-email">Email Address</Label>
              <Input
                id="signin-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                required
                className="mobile-form"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="signin-password">Password</Label>
              <div className="relative">
                <Input
                  id="signin-password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  required
                  className="mobile-form pr-12"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <Eye className="h-4 w-4 text-muted-foreground" />
                  )}
                </Button>
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full mobile-button"
              disabled={isSigningIn}
            >
              {isSigningIn ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Signing In...
                </>
              ) : (
                <>
                  <Lock className="mr-2 h-4 w-4" />
                  Sign In
                </>
              )}
            </Button>

            <div className="text-center">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => navigate('home')}
                className="text-sm text-muted-foreground hover:text-foreground"
              >
                Back to Home
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-2xl font-bold">Email Verification</h1>
          <p className="text-muted-foreground text-sm">
            Complete your account setup
          </p>
        </div>

        {/* Main Content */}
        <div className="space-y-6">
          {renderConfirmationStatus()}
          {renderSignInForm()}
        </div>

        {/* Footer */}
        <div className="text-center text-xs text-muted-foreground">
          <p>
            Need help? Contact our support team for assistance.
          </p>
        </div>
      </div>
    </div>
  );
}