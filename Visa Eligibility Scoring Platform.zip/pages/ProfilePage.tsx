import { useEffect, useState } from 'react';
import { UserProfile } from '../components/UserProfile';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Badge } from '../components/ui/badge';
import { 
  Trophy, 
  TrendingUp, 
  Star, 
  Award,
  AlertCircle,
  Sparkles,
  Target,
  ArrowLeft,
  Home,
  LayoutDashboard
} from 'lucide-react';

interface ProfilePageProps {
  navigate: (page: string, params?: any) => void;
  authState: any;
  userProfile: any;
  onboardingResult?: any;
  updateUserProfile?: (data: any) => Promise<any>;
  updateSettings?: (data: any) => Promise<any>;
}

export function ProfilePage({ 
  navigate, 
  authState, 
  userProfile, 
  onboardingResult,
  updateUserProfile,
  updateSettings
}: ProfilePageProps) {
  const [showWelcome, setShowWelcome] = useState(false);

  useEffect(() => {
    // Show welcome message if user just completed onboarding
    if (onboardingResult && onboardingResult.scores) {
      setShowWelcome(true);
      // Auto-hide after 5 seconds
      setTimeout(() => setShowWelcome(false), 5000);
    }
  }, [onboardingResult]);

  if (!authState.isAuthenticated) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-semibold mb-4">Authentication Required</h2>
        <p className="text-muted-foreground mb-6">
          Please sign in to view your profile.
        </p>
        <Button onClick={() => navigate('home')}>
          Go Home
        </Button>
      </div>
    );
  }

  const getTopRecommendation = () => {
    if (onboardingResult?.recommendations?.length > 0) {
      return onboardingResult.recommendations[0];
    }
    return null;
  };

  const topRecommendation = getTopRecommendation();

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation Header */}
      <div className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('home')}
                className="flex items-center space-x-2"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </Button>
              <div className="hidden sm:block w-px h-6 bg-border" />
              <h1 className="text-xl font-semibold">My Profile</h1>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate('home')}
                className="flex items-center space-x-2"
              >
                <Home className="w-4 h-4" />
                <span className="hidden sm:inline">Home</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate('dashboard')}
                className="flex items-center space-x-2"
              >
                <LayoutDashboard className="w-4 h-4" />
                <span className="hidden sm:inline">Dashboard</span>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Welcome Banner for New Users */}
      {showWelcome && onboardingResult && (
        <div className="bg-gradient-to-r from-primary/10 to-secondary/10 border-b">
          <div className="container mx-auto px-4 py-6">
            <Card className="border-primary/20 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                      <Sparkles className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold">🎉 Welcome to Visa Score!</h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowWelcome(false)}
                      >
                        ✕
                      </Button>
                    </div>
                    <p className="text-muted-foreground mb-4">
                      Your profile has been created and your visa scores have been calculated based on your background and goals.
                    </p>
                    
                    {topRecommendation && (
                      <div className="bg-primary/5 rounded-lg p-4 border border-primary/20">
                        <div className="flex items-center space-x-2 mb-2">
                          <Target className="w-5 h-5 text-primary" />
                          <span className="font-medium">Your Top Match:</span>
                          <Badge variant="default">
                            {topRecommendation.visaType.replace(/([A-Z])/g, ' $1')} - {topRecommendation.score}%
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">
                          {topRecommendation.message}
                        </p>
                        <div className="flex space-x-2">
                          <Button size="sm" onClick={() => navigate('smart-recommendations')}>
                            View All Recommendations
                          </Button>
                          <Button variant="outline" size="sm" onClick={() => navigate('ai-assistant')}>
                            Get AI Guidance
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Quick Stats for New Users */}
      {onboardingResult?.scores && (
        <div className="container mx-auto px-4 py-6">
          <div className="grid gap-4 md:grid-cols-4 mb-6">
            <Card>
              <CardContent className="p-4 text-center">
                <Trophy className="w-8 h-8 mx-auto text-yellow-500 mb-2" />
                <div className="text-2xl font-bold">
                  {Math.max(...Object.values(onboardingResult.scores))}%
                </div>
                <p className="text-sm text-muted-foreground">Highest Score</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <TrendingUp className="w-8 h-8 mx-auto text-green-500 mb-2" />
                <div className="text-2xl font-bold">
                  {Object.values(onboardingResult.scores).filter((score: any) => score >= 60).length}
                </div>
                <p className="text-sm text-muted-foreground">Strong Matches</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <Star className="w-8 h-8 mx-auto text-blue-500 mb-2" />
                <div className="text-2xl font-bold">
                  {onboardingResult.recommendations?.length || 0}
                </div>
                <p className="text-sm text-muted-foreground">Recommendations</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <Award className="w-8 h-8 mx-auto text-purple-500 mb-2" />
                <div className="text-2xl font-bold">100%</div>
                <p className="text-sm text-muted-foreground">Profile Complete</p>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Main Profile Component */}
      <UserProfile
        userProfile={userProfile}
        authState={authState}
        updateUserProfile={updateUserProfile}
        updateSettings={updateSettings}
        navigate={navigate}
        onProfileUpdate={() => {
          // Trigger a profile reload if needed
          window.location.reload();
        }}
      />


    </div>
  );
}