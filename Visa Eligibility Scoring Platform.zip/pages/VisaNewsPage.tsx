import { useState } from 'react';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { LiveVisaNews } from '../components/LiveVisaNews';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Bell, Newspaper, Zap, TrendingUp, AlertTriangle } from 'lucide-react';
import { motion } from 'motion/react';

interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

interface UserProfile {
  name: string;
  email: string;
  completed_onboarding: boolean;
  [key: string]: any;
}

interface VisaNewsPageProps {
  authState: AuthState;
  userProfile: UserProfile | null;
  onSignIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  onSignUp: (email: string, password: string, name: string) => Promise<{ success: boolean; error?: string }>;
  onSignOut: () => void;
  navigate: (path: string) => void;
}

export function VisaNewsPage({
  authState,
  userProfile,
  onSignIn,
  onSignUp,
  onSignOut,
  navigate
}: VisaNewsPageProps) {
  const [selectedNewsId, setSelectedNewsId] = useState<string | null>(null);

  const handleNewsClick = (newsId: string) => {
    // Navigate to news detail page
    navigate(`/news/${newsId}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header
        authState={authState}
        userProfile={userProfile}
        onSignIn={onSignIn}
        onSignUp={onSignUp}
        onSignOut={onSignOut}
        currentPath="/news"
        navigate={navigate}
      />
      
      <div className="pt-16">
        {/* Hero Section */}
        <section className="relative overflow-hidden py-16 px-4">
          {/* Gaming Background */}
          <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-primary/10"></div>
          
          {/* Grid Pattern */}
          <div className="absolute inset-0 opacity-20">
            <div 
              className="absolute inset-0" 
              style={{
                backgroundImage: 'linear-gradient(to right, hsl(var(--primary)) 0.5px, transparent 0.5px), linear-gradient(to bottom, hsl(var(--primary)) 0.5px, transparent 0.5px)',
                backgroundSize: '40px 40px'
              }}
            ></div>
          </div>
          
          {/* Gaming Orbs */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-20 right-20 w-32 h-32 bg-primary/20 rounded-full blur-2xl animate-gaming-pulse"></div>
            <div className="absolute bottom-32 left-32 w-24 h-24 bg-secondary/20 rounded-full blur-xl animate-gaming-float"></div>
          </div>

          <div className="container mx-auto relative z-10">
            <div className="max-w-4xl mx-auto text-center space-y-8">
              
              {/* Header */}
              <div className="space-y-6">
                <div className="flex items-center justify-center space-x-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/70 rounded-2xl flex items-center justify-center">
                    <Newspaper className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex items-center space-x-2">
                    <h1 className="text-3xl md:text-4xl lg:text-5xl">
                      <span className="block bg-gradient-to-r from-primary via-primary to-secondary bg-clip-text text-transparent font-bold">
                        VISA NEWS UPDATES
                      </span>
                    </h1>
                    <div className="flex items-center space-x-1 ml-3">
                      <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                      <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                        LIVE
                      </Badge>
                    </div>
                  </div>
                </div>

                <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                  Stay ahead with real-time updates on UK visa policy changes, processing times, 
                  new requirements, and breaking announcements that could affect your application.
                </p>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-card/50 backdrop-blur-sm rounded-xl border border-white/20 p-4 text-center group hover:bg-card/70 transition-all duration-300">
                  <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform">
                    <Bell className="h-5 w-5 text-blue-400" />
                  </div>
                  <div className="text-lg font-bold text-foreground">24/7</div>
                  <div className="text-xs text-muted-foreground">Live Monitoring</div>
                </div>

                <div className="bg-card/50 backdrop-blur-sm rounded-xl border border-white/20 p-4 text-center group hover:bg-card/70 transition-all duration-300">
                  <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform">
                    <Zap className="h-5 w-5 text-green-400" />
                  </div>
                  <div className="text-lg font-bold text-foreground">Instant</div>
                  <div className="text-xs text-muted-foreground">Breaking News</div>
                </div>

                <div className="bg-card/50 backdrop-blur-sm rounded-xl border border-white/20 p-4 text-center group hover:bg-card/70 transition-all duration-300">
                  <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform">
                    <TrendingUp className="h-5 w-5 text-purple-400" />
                  </div>
                  <div className="text-lg font-bold text-foreground">Trending</div>
                  <div className="text-xs text-muted-foreground">Topics</div>
                </div>

                <div className="bg-card/50 backdrop-blur-sm rounded-xl border border-white/20 p-4 text-center group hover:bg-card/70 transition-all duration-300">
                  <div className="w-10 h-10 bg-red-500/20 rounded-lg flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform">
                    <AlertTriangle className="h-5 w-5 text-red-400" />
                  </div>
                  <div className="text-lg font-bold text-foreground">Critical</div>
                  <div className="text-xs text-muted-foreground">Alerts</div>
                </div>
              </div>

              {/* Call to Action */}
              {!authState.isAuthenticated && (
                <div className="bg-card/30 backdrop-blur-sm rounded-2xl border border-white/20 p-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-center space-x-2">
                      <Bell className="h-5 w-5 text-primary" />
                      <h3 className="text-lg font-semibold">Get Personalized Alerts</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Sign up to receive news updates relevant to your specific visa route and situation
                    </p>
                    <Button
                      onClick={() => navigate('/')}
                      className="bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70"
                    >
                      Create Free Account
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Live News Section */}
        <LiveVisaNews onNewsClick={handleNewsClick} />
      </div>
      
      <Footer onAdminLogin={() => navigate('/admin/login')} />
    </div>
  );
}