import { ActionPlan } from '../components/ActionPlan';

interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

interface ActionPlanPageProps {
  authState: AuthState;
  navigate: (path: string) => void;
}

export function ActionPlanPage({ authState, navigate }: ActionPlanPageProps) {
  if (!authState.isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-semibold">Access Denied</h2>
          <p className="text-muted-foreground">Please sign in to view your action plan.</p>
          <button
            onClick={() => navigate('home')}
            className="bg-primary text-primary-foreground px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors"
          >
            Go Home
          </button>
        </div>
      </div>
    );
  }

  // Check if we have assessment data in localStorage or session
  const assessmentData = localStorage.getItem('lastAssessment');
  
  if (!assessmentData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-semibold">No Assessment Data</h2>
          <p className="text-muted-foreground">Please complete an eligibility assessment first to view your action plan.</p>
          <button
            onClick={() => navigate('visa-routes')}
            className="bg-primary text-primary-foreground px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors mr-4"
          >
            Select Visa Route
          </button>
          <button
            onClick={() => navigate('dashboard')}
            className="bg-secondary text-secondary-foreground px-6 py-2 rounded-lg hover:bg-secondary/90 transition-colors"
          >
            Dashboard
          </button>
        </div>
      </div>
    );
  }

  let parsedData;
  try {
    parsedData = JSON.parse(assessmentData);
  } catch (error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-semibold">Invalid Assessment Data</h2>
          <p className="text-muted-foreground">Please take a new assessment.</p>
          <button
            onClick={() => navigate('visa-routes')}
            className="bg-primary text-primary-foreground px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors"
          >
            Select Visa Route
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <ActionPlan 
        route={parsedData.route}
        answers={parsedData.answers}
        initialScore={parsedData.score}
        onBack={() => navigate('eligibility-results')}
        onScoreUpdate={(newScore) => {
          // Update local storage with new score
          const updatedData = { ...parsedData, score: newScore };
          localStorage.setItem('lastAssessment', JSON.stringify(updatedData));
        }}
      />
    </div>
  );
}