import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '../components/ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { 
  Users, 
  TrendingUp, 
  DollarSign, 
  Calendar,
  UserCheck,
  UserX,
  RefreshCw,
  Trash2,
  Search,
  Filter,
  Eye,
  Edit,
  AlertTriangle,
  Download,
  BarChart3,
  PieChartIcon,
  Activity,
  Clock,
  CreditCard,
  Shield
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { adminAPI } from '../utils/api-client';

interface AdminDashboardPageProps {
  adminAuth: any;
  onSignOut: () => void;
}

interface User {
  id: string;
  email: string;
  created_at: string;
  last_sign_in_at?: string;
  email_confirmed_at?: string;
  profile?: any;
  subscription?: any;
  fullProfile?: any;
}

interface Analytics {
  overview: {
    totalUsers: number;
    activeUsers: number;
    trialUsers: number;
    monthlyUsers: number;
    totalRevenue: number;
    monthlyRevenue: number;
  };
  chartData: Array<{
    date: string;
    users: number;
    revenue: number;
  }>;
  recentActivity: Array<{
    id: string;
    email: string;
    created_at: string;
    last_sign_in_at?: string;
  }>;
}

export function AdminDashboardPage({ adminAuth, onSignOut }: AdminDashboardPageProps) {
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [revenueData, setRevenueData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  useEffect(() => {
    fetchAnalytics();
    fetchUsers();
    fetchRevenueData();
  }, []);

  const fetchAnalytics = async () => {
    try {
      const data = await adminAPI.getAnalytics(adminAuth.session.access_token);
      setAnalytics(data);
    } catch (error) {
      console.error('Analytics fetch error:', error);
      toast.error('Failed to load analytics');
    }
  };

  const fetchUsers = async () => {
    try {
      const data = await adminAPI.getUsers(adminAuth.session.access_token);
      setUsers(data.users);
    } catch (error) {
      console.error('Users fetch error:', error);
      toast.error('Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  const fetchRevenueData = async () => {
    try {
      const data = await adminAPI.getRevenue(adminAuth.session.access_token);
      setRevenueData(data.revenueData);
    } catch (error) {
      console.error('Revenue data fetch error:', error);
      toast.error('Failed to load revenue data');
    }
  };

  const handleDeleteUser = async (userId: string) => {
    try {
      await adminAPI.deleteUser(userId, adminAuth.session.access_token);
      toast.success('User deleted successfully');
      fetchUsers();
      fetchAnalytics();
    } catch (error) {
      console.error('User deletion error:', error);
      toast.error('Failed to delete user');
    }
  };

  const handleResetUser = async (userId: string) => {
    try {
      await adminAPI.resetUser(userId, adminAuth.session.access_token);
      toast.success('User data reset successfully');
      fetchUsers();
    } catch (error) {
      console.error('User reset error:', error);
      toast.error('Failed to reset user data');
    }
  };

  const handleUpdateSubscription = async (userId: string, status: string, plan: string, amount: number) => {
    try {
      await adminAPI.updateSubscription(userId, status, plan, amount, adminAuth.session.access_token);
      toast.success('Subscription updated successfully');
      fetchUsers();
      fetchAnalytics();
    } catch (error) {
      console.error('Subscription update error:', error);
      toast.error('Failed to update subscription');
    }
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || 
      (statusFilter === 'trial' && user.subscription?.status === 'trial') ||
      (statusFilter === 'active' && user.subscription?.status === 'active') ||
      (statusFilter === 'inactive' && !user.subscription);
    
    return matchesSearch && matchesStatus;
  });

  const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))'];

  const pieData = analytics ? [
    { name: 'Active Subscriptions', value: analytics.overview.monthlyUsers, color: COLORS[0] },
    { name: 'Trial Users', value: analytics.overview.trialUsers, color: COLORS[1] },
    { name: 'Inactive Users', value: analytics.overview.totalUsers - analytics.overview.monthlyUsers - analytics.overview.trialUsers, color: COLORS[2] }
  ] : [];

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Admin Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Shield className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-2xl font-bold">Admin Dashboard</h1>
              <p className="text-sm text-muted-foreground">Visa Score Platform Management</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant="secondary">
              Admin: {adminAuth.user.email}
            </Badge>
            <Button variant="outline" onClick={onSignOut}>
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">User Management</TabsTrigger>
            <TabsTrigger value="revenue">Revenue Analytics</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{analytics?.overview.totalUsers || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    {analytics?.overview.activeUsers || 0} active this month
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Trial Users</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{analytics?.overview.trialUsers || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    2-day free trial active
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Monthly Subscribers</CardTitle>
                  <CreditCard className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{analytics?.overview.monthlyUsers || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    £6.99/month each
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">£{analytics?.overview.totalRevenue || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    £{analytics?.overview.monthlyRevenue || 0} this month
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>User Growth</CardTitle>
                  <CardDescription>New users over the last 7 days</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={analytics?.chartData || []}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Area type="monotone" dataKey="users" stroke="hsl(var(--primary))" fill="hsl(var(--primary))" fillOpacity={0.3} />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>User Distribution</CardTitle>
                  <CardDescription>Breakdown by subscription status</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent User Activity</CardTitle>
                <CardDescription>Latest user registrations and sign-ins</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analytics?.recentActivity.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium">{user.email}</p>
                        <p className="text-sm text-muted-foreground">
                          Joined {new Date(user.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">
                          Last seen: {user.last_sign_in_at 
                            ? new Date(user.last_sign_in_at).toLocaleDateString()
                            : 'Never'
                          }
                        </p>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={async () => {
                            try {
                              const profileData = await adminAPI.getUserProfile(user.id, adminAuth.session.access_token);
                              setSelectedUser({ 
                                id: user.id,
                                email: user.email,
                                created_at: user.created_at,
                                last_sign_in_at: user.last_sign_in_at,
                                fullProfile: profileData 
                              });
                            } catch (error) {
                              console.error('Error fetching user profile:', error);
                              setSelectedUser({
                                id: user.id,
                                email: user.email,
                                created_at: user.created_at,
                                last_sign_in_at: user.last_sign_in_at
                              });
                            }
                          }}
                          className="text-xs"
                        >
                          <Eye className="h-3 w-3 mr-1" />
                          View
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Platform Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Activity className="h-5 w-5 mr-2" />
                    User Engagement
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Daily Active Users</span>
                      <span className="text-sm font-medium">{Math.round((analytics?.overview.activeUsers || 0) * 0.3)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Avg. Session Duration</span>
                      <span className="text-sm font-medium">12m 34s</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Bounce Rate</span>
                      <span className="text-sm font-medium">23%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2" />
                    Growth Metrics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">User Growth (7d)</span>
                      <span className="text-sm font-medium text-green-600">+12%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Revenue Growth (30d)</span>
                      <span className="text-sm font-medium text-green-600">+8.5%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Retention Rate</span>
                      <span className="text-sm font-medium">78%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="h-5 w-5 mr-2" />
                    Feature Usage
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">AI Assistant</span>
                      <span className="text-sm font-medium">89%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Eligibility Assessment</span>
                      <span className="text-sm font-medium">76%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Visa Routes</span>
                      <span className="text-sm font-medium">95%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* User Management Tab */}
          <TabsContent value="users" className="space-y-6">
            {/* User Filters */}
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
                <CardDescription>Manage user accounts and subscriptions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row gap-4 mb-6">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search users by email..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Users</SelectItem>
                      <SelectItem value="trial">Trial Users</SelectItem>
                      <SelectItem value="active">Active Subscribers</SelectItem>
                      <SelectItem value="inactive">Inactive Users</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Users Table */}
                <div className="space-y-4">
                  {filteredUsers.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center space-x-4">
                          <div>
                            <p className="font-medium">{user.email}</p>
                            <p className="text-sm text-muted-foreground">
                              ID: {user.id.slice(0, 8)}...
                            </p>
                          </div>
                          <div className="flex space-x-2">
                            {user.subscription?.status === 'trial' && (
                              <Badge variant="outline">Trial</Badge>
                            )}
                            {user.subscription?.status === 'active' && (
                              <Badge variant="default">Active</Badge>
                            )}
                            {!user.subscription && (
                              <Badge variant="secondary">Inactive</Badge>
                            )}
                            {user.email_confirmed_at && (
                              <Badge variant="outline">Verified</Badge>
                            )}
                          </div>
                        </div>
                        <div className="mt-2 text-sm text-muted-foreground">
                          <p>Joined: {new Date(user.created_at).toLocaleDateString()}</p>
                          <p>Last active: {user.last_sign_in_at 
                            ? new Date(user.last_sign_in_at).toLocaleDateString()
                            : 'Never'
                          }</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={async () => {
                            try {
                              const profileData = await adminAPI.getUserProfile(user.id, adminAuth.session.access_token);
                              setSelectedUser({ ...user, fullProfile: profileData });
                            } catch (error) {
                              console.error('Error fetching user profile:', error);
                              setSelectedUser(user);
                            }
                          }}
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              <RefreshCw className="h-4 w-4 mr-1" />
                              Reset
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Reset User Data</AlertDialogTitle>
                              <AlertDialogDescription>
                                This will reset all user data including profile, subscription, and chat history. This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleResetUser(user.id)}>
                                Reset Data
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="destructive" size="sm">
                              <Trash2 className="h-4 w-4 mr-1" />
                              Delete
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete User</AlertDialogTitle>
                              <AlertDialogDescription>
                                This will permanently delete the user account and all associated data. This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteUser(user.id)}>
                                Delete User
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Revenue Analytics Tab */}
          <TabsContent value="revenue" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Revenue Analytics</CardTitle>
                <CardDescription>Monthly revenue trends and financial insights</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={revenueData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`£${value}`, 'Revenue']} />
                    <Legend />
                    <Bar dataKey="revenue" fill="hsl(var(--primary))" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Monthly Recurring Revenue</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">£{analytics?.overview.monthlyRevenue || 0}</div>
                  <p className="text-sm text-muted-foreground">
                    From {analytics?.overview.monthlyUsers || 0} active subscriptions
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Average Revenue Per User</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    £{analytics ? (analytics.overview.totalRevenue / Math.max(analytics.overview.totalUsers, 1)).toFixed(2) : '0.00'}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Lifetime value
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Conversion Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {analytics ? ((analytics.overview.monthlyUsers / Math.max(analytics.overview.totalUsers, 1)) * 100).toFixed(1) : '0.0'}%
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Trial to paid conversion
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Admin Settings</CardTitle>
                <CardDescription>Configure platform settings and permissions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h3 className="font-medium">Platform Access</h3>
                      <p className="text-sm text-muted-foreground">Control overall platform access</p>
                    </div>
                    <Button variant="outline">
                      Configure
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h3 className="font-medium">Subscription Settings</h3>
                      <p className="text-sm text-muted-foreground">Manage subscription plans and pricing</p>
                    </div>
                    <Button variant="outline">
                      Manage
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h3 className="font-medium">Data Export</h3>
                      <p className="text-sm text-muted-foreground">Export user data and analytics</p>
                    </div>
                    <Button variant="outline">
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* User Detail Modal */}
      {selectedUser && (
        <AlertDialog open={!!selectedUser} onOpenChange={() => setSelectedUser(null)}>
          <AlertDialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <AlertDialogHeader>
              <AlertDialogTitle>User Details</AlertDialogTitle>
              <AlertDialogDescription>
                Detailed information for {selectedUser.email}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Email</label>
                  <p className="text-sm text-muted-foreground">{selectedUser.email}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">User ID</label>
                  <p className="text-sm text-muted-foreground font-mono text-xs">{selectedUser.id}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">Created</label>
                  <p className="text-sm text-muted-foreground">
                    {new Date(selectedUser.created_at).toLocaleString()}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium">Last Sign In</label>
                  <p className="text-sm text-muted-foreground">
                    {selectedUser.last_sign_in_at 
                      ? new Date(selectedUser.last_sign_in_at).toLocaleString()
                      : 'Never'
                    }
                  </p>
                </div>
              </div>

              {/* Enhanced Profile Information */}
              {selectedUser.fullProfile && (
                <>
                  <div className="border rounded-lg p-4">
                    <h3 className="font-medium mb-3">Profile Information</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Name</label>
                        <p className="text-sm text-muted-foreground">
                          {selectedUser.fullProfile.profile?.name || 'Not provided'}
                        </p>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Country</label>
                        <p className="text-sm text-muted-foreground">
                          {selectedUser.fullProfile.profile?.country || 'Not provided'}
                        </p>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Profession</label>
                        <p className="text-sm text-muted-foreground">
                          {selectedUser.fullProfile.profile?.profession || 'Not provided'}
                        </p>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Age Range</label>
                        <p className="text-sm text-muted-foreground">
                          {selectedUser.fullProfile.profile?.age || 'Not provided'}
                        </p>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Onboarding Complete</label>
                        <p className="text-sm text-muted-foreground">
                          {selectedUser.fullProfile.profile?.completed_onboarding ? 'Yes' : 'No'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Visa Scores */}
                  {selectedUser.fullProfile.visaScores && (
                    <div className="border rounded-lg p-4">
                      <h3 className="font-medium mb-3">Visa Scores</h3>
                      <div className="grid grid-cols-3 gap-4">
                        {Object.entries(selectedUser.fullProfile.visaScores).map(([visaType, score]) => (
                          <div key={visaType}>
                            <label className="text-sm font-medium capitalize">{visaType.replace(/([A-Z])/g, ' $1')}</label>
                            <p className="text-sm text-muted-foreground">{score}%</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Activity Summary */}
                  {selectedUser.fullProfile.activity && (
                    <div className="border rounded-lg p-4">
                      <h3 className="font-medium mb-3">Activity Summary</h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium">Chat Messages</label>
                          <p className="text-sm text-muted-foreground">
                            {selectedUser.fullProfile.activity.chat.totalMessages} messages
                          </p>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Assessments</label>
                          <p className="text-sm text-muted-foreground">
                            {selectedUser.fullProfile.activity.assessments.totalAssessments} completed
                          </p>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Last Chat Activity</label>
                          <p className="text-sm text-muted-foreground">
                            {selectedUser.fullProfile.activity.chat.lastActivity 
                              ? new Date(selectedUser.fullProfile.activity.chat.lastActivity).toLocaleDateString()
                              : 'No activity'
                            }
                          </p>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Last Assessment</label>
                          <p className="text-sm text-muted-foreground">
                            {selectedUser.fullProfile.activity.assessments.lastAssessment 
                              ? new Date(selectedUser.fullProfile.activity.assessments.lastAssessment).toLocaleDateString()
                              : 'No assessments'
                            }
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}
              
              {selectedUser.subscription && (
                <div className="border rounded-lg p-4">
                  <h3 className="font-medium mb-2">Subscription Details</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium">Status</label>
                      <p className="text-sm text-muted-foreground">{selectedUser.subscription.status}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Plan</label>
                      <p className="text-sm text-muted-foreground">{selectedUser.subscription.plan || 'N/A'}</p>
                    </div>
                  </div>
                  
                  <div className="mt-4 flex space-x-2">
                    <Button 
                      size="sm" 
                      onClick={() => handleUpdateSubscription(selectedUser.id, 'active', 'monthly', 6.99)}
                    >
                      Activate Subscription
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleUpdateSubscription(selectedUser.id, 'cancelled', 'none', 0)}
                    >
                      Cancel Subscription
                    </Button>
                  </div>
                </div>
              )}
            </div>
            <AlertDialogFooter>
              <AlertDialogCancel>Close</AlertDialogCancel>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
}