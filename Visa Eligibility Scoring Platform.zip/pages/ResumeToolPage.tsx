import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Badge } from '../components/ui/badge';
import { ArrowLeft, Upload, Search, Target, Sparkles } from 'lucide-react';
import { ResumeUpload } from '../components/ResumeUpload';
import { JobAnalysis } from '../components/JobAnalysis';
import { ResumeJobMatch } from '../components/ResumeJobMatch';
import { ResumeOptimization } from '../components/ResumeOptimization';

interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

interface ResumeToolPageProps {
  authState: AuthState;
  navigate: (path: string) => void;
}

export function ResumeToolPage({ authState, navigate }: ResumeToolPageProps) {
  const [activeTab, setActiveTab] = useState('upload');

  if (!authState.isAuthenticated || !authState.user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-semibold">Access Denied</h2>
          <p className="text-muted-foreground">Please sign in to use the Resume Tool.</p>
          <button
            onClick={() => navigate('home')}
            className="bg-primary text-primary-foreground px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors"
          >
            Go Home
          </button>
        </div>
      </div>
    );
  }

  // Create user object in expected format
  const user = {
    id: authState.user.id,
    email: authState.user.email,
    name: authState.user.user_metadata?.name
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Header */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur border-b border-border md:hidden">
        <div className="flex items-center justify-between p-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('dashboard')}
            className="mobile-back-button"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div className="flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-primary" />
            <span className="font-semibold">Resume Tool</span>
          </div>
          <div className="w-20"></div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-4 md:py-8">
        <div className="max-w-6xl mx-auto">
          {/* Desktop Header */}
          <div className="hidden md:flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">AI Resume Optimizer</h1>
              <p className="text-muted-foreground">
                Optimize your CV for UK job applications with AI-powered insights
              </p>
            </div>
            <Button
              variant="outline"
              onClick={() => navigate('dashboard')}
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Dashboard</span>
            </Button>
          </div>

          {/* Feature Overview */}
          <div className="grid md:grid-cols-4 gap-4 mb-8">
            <Card className="relative overflow-hidden">
              <CardContent className="p-4 text-center">
                <Upload className="w-8 h-8 mx-auto mb-2 text-primary" />
                <h3 className="font-semibold mb-1">Upload Resume</h3>
                <p className="text-xs text-muted-foreground">
                  Upload your CV for AI analysis
                </p>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden">
              <CardContent className="p-4 text-center">
                <Search className="w-8 h-8 mx-auto mb-2 text-primary" />
                <h3 className="font-semibold mb-1">Job Analysis</h3>
                <p className="text-xs text-muted-foreground">
                  Analyze job descriptions
                </p>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden">
              <CardContent className="p-4 text-center">
                <Target className="w-8 h-8 mx-auto mb-2 text-primary" />
                <h3 className="font-semibold mb-1">Match Score</h3>
                <p className="text-xs text-muted-foreground">
                  See how well you match
                </p>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden">
              <CardContent className="p-4 text-center">
                <Sparkles className="w-8 h-8 mx-auto mb-2 text-primary" />
                <h3 className="font-semibold mb-1">Optimization</h3>
                <p className="text-xs text-muted-foreground">
                  Get improvement suggestions
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <Card>
            <CardContent className="p-0">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <div className="border-b border-border">
                  <TabsList className="grid w-full grid-cols-4 h-auto bg-transparent">
                    <TabsTrigger 
                      value="upload" 
                      className="flex-col h-16 data-[state=active]:bg-primary/10"
                    >
                      <Upload className="w-4 h-4 mb-1" />
                      <span className="text-xs">Upload</span>
                    </TabsTrigger>
                    <TabsTrigger 
                      value="job-analysis" 
                      className="flex-col h-16 data-[state=active]:bg-primary/10"
                    >
                      <Search className="w-4 h-4 mb-1" />
                      <span className="text-xs">Job Analysis</span>
                    </TabsTrigger>
                    <TabsTrigger 
                      value="match" 
                      className="flex-col h-16 data-[state=active]:bg-primary/10"
                    >
                      <Target className="w-4 h-4 mb-1" />
                      <span className="text-xs">Match</span>
                    </TabsTrigger>
                    <TabsTrigger 
                      value="optimize" 
                      className="flex-col h-16 data-[state=active]:bg-primary/10"
                    >
                      <Sparkles className="w-4 h-4 mb-1" />
                      <span className="text-xs">Optimize</span>
                    </TabsTrigger>
                  </TabsList>
                </div>

                <div className="p-6">
                  <TabsContent value="upload" className="mt-0">
                    <ResumeUpload user={user} navigate={navigate} />
                  </TabsContent>

                  <TabsContent value="job-analysis" className="mt-0">
                    <JobAnalysis user={user} navigate={navigate} />
                  </TabsContent>

                  <TabsContent value="match" className="mt-0">
                    <ResumeJobMatch user={user} navigate={navigate} />
                  </TabsContent>

                  <TabsContent value="optimize" className="mt-0">
                    <ResumeOptimization user={user} navigate={navigate} />
                  </TabsContent>
                </div>
              </Tabs>
            </CardContent>
          </Card>

          {/* Tips */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-lg">💡 Pro Tips for UK Job Applications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div className="space-y-2">
                  <div className="flex items-start space-x-2">
                    <Badge variant="outline" className="mt-0.5">1</Badge>
                    <span>Use UK spelling (organisation, colour, etc.)</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Badge variant="outline" className="mt-0.5">2</Badge>
                    <span>Include relevant UK qualifications or equivalents</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Badge variant="outline" className="mt-0.5">3</Badge>
                    <span>Highlight visa status or right to work clearly</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-start space-x-2">
                    <Badge variant="outline" className="mt-0.5">4</Badge>
                    <span>Tailor CV to specific job requirements</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Badge variant="outline" className="mt-0.5">5</Badge>
                    <span>Use action verbs and quantify achievements</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Badge variant="outline" className="mt-0.5">6</Badge>
                    <span>Keep formatting clean and professional</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}