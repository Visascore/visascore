import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Home, ArrowLeft, Search } from 'lucide-react';

interface NotFoundPageProps {
  navigate: (path: string) => void;
}

export function NotFoundPage({ navigate }: NotFoundPageProps) {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="container mx-auto px-4">
        <div className="max-w-md mx-auto text-center">
          <Card>
            <CardHeader>
              <div className="text-6xl mb-4">🤔</div>
              <CardTitle className="text-2xl">Page Not Found</CardTitle>
              <CardDescription>
                The page you're looking for doesn't exist or has been moved.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Button 
                  onClick={() => navigate('/dashboard')}
                  className="w-full"
                >
                  <Home className="w-4 h-4 mr-2" />
                  Go to Dashboard
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => window.history.back()}
                  className="w-full"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Go Back
                </Button>
              </div>
              
              <div className="text-sm text-muted-foreground">
                <p className="mb-2">Popular pages:</p>
                <div className="space-y-1">
                  <Button 
                    variant="link" 
                    size="sm"
                    onClick={() => navigate('/ai-assistant')}
                    className="h-auto p-0 text-sm"
                  >
                    AI Assistant
                  </Button>
                  <br />
                  <Button 
                    variant="link" 
                    size="sm"
                    onClick={() => navigate('/assessment')}
                    className="h-auto p-0 text-sm"
                  >
                    Visa Assessment
                  </Button>
                  <br />
                  <Button 
                    variant="link" 
                    size="sm"
                    onClick={() => navigate('/resume-tool')}
                    className="h-auto p-0 text-sm"
                  >
                    Resume Tool
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}