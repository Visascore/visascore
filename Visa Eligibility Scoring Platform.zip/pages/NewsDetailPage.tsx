import { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { ArrowLeft, Calendar, User, Share2, Bookmark } from 'lucide-react';

interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

interface UserProfile {
  name: string;
  email: string;
  completed_onboarding: boolean;
  [key: string]: any;
}

interface NewsDetailPageProps {
  newsId: string;
  authState: AuthState;
  userProfile: UserProfile | null;
  navigate: (path: string) => void;
}

export function NewsDetailPage({ newsId, authState, userProfile, navigate }: NewsDetailPageProps) {
  const [newsArticle, setNewsArticle] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Mock news data - in a real app, this would come from an API
  const mockNews = {
    '1': {
      id: '1',
      title: 'Skilled Worker Visa Salary Threshold Increases to £38,700',
      excerpt: 'Major changes to Skilled Worker visa requirements as salary threshold rises significantly from April 2025.',
      content: `The UK government has announced a significant increase to the Skilled Worker visa salary threshold, rising from £26,200 to £38,700 from April 2025.

## Key Changes

The new salary requirements include:

- **General threshold**: Minimum salary increases from £26,200 to £38,700 per year
- **Going rate requirement**: Must meet the higher of the new threshold or going rate for the occupation
- **New entrant rate**: Reduced threshold of £30,960 for those under 26 or in their first UK skilled job
- **Shortage occupation discount**: 80% of the going rate (minimum £30,960) for shortage occupations

## Who Is Affected

This change impacts:
- New Skilled Worker visa applicants from April 2025
- Current visa holders applying for extensions
- Employers sponsoring international workers
- Workers in roles previously meeting the old threshold

## Implementation Timeline

The changes will be implemented as follows:
- **April 4, 2025**: New thresholds take effect for new applications
- **Existing visa holders**: Current visas remain valid until expiry
- **Extensions**: New rates apply to all extension applications from April 2025

## Exceptions and Protections

Some protections are in place:
- **Shortage occupations**: Maintain 80% discount on going rates
- **New entrants**: Lower threshold for young workers and first-time UK employees
- **Health and care workers**: Separate, more favorable requirements
- **PhD qualifications**: Additional discounts may apply for relevant qualifications

## Impact on Employers

Employers will need to:
- Review current sponsorship commitments
- Adjust salary packages to meet new thresholds
- Update job advertisements and recruitment strategies
- Consider reclassifying roles or increasing compensation

## What This Means for Applicants

Current and prospective applicants should:
- Check if their role meets the new salary requirements
- Consider timing of applications before April deadline
- Explore alternative visa routes if salary requirements cannot be met
- Seek professional advice on their specific circumstances

The Home Office states these changes are designed to ensure skilled migration benefits the UK economy while reducing overall migration numbers.`,
      author: 'UK Visa Policy Team',
      publishedAt: '2025-02-01T09:00:00Z',
      category: 'Policy Changes',
      tags: ['Skilled Worker', 'Salary Threshold', 'Immigration Rules'],
      readTime: '6 min read'
    },
    '2': {
      id: '2',
      title: 'Graduate Visa Under Review - Potential Changes Announced',
      excerpt: 'Home Office announces comprehensive review of Graduate visa route amid concerns about potential abuse.',
      content: `The Home Office has announced a comprehensive review of the Graduate visa route, with potential significant changes on the horizon for international students.

## Background to the Review

The Graduate visa has been under scrutiny due to:
- **Concerns about abuse**: Reports of students enrolling in low-quality courses solely for visa purposes
- **Migration statistics**: Graduate visa grants have increased substantially since introduction
- **Quality concerns**: Questions raised about some educational institutions and course standards
- **Economic impact**: Debate over the route's contribution to UK economy vs. migration targets

## Potential Changes Under Consideration

The review may result in:
- **Enhanced English language requirements**: Higher IELTS/equivalent scores may be required
- **Sponsorship requirements**: Possible introduction of employer sponsorship for Graduate visa holders
- **Qualification restrictions**: Limiting eligibility to specific degree levels or subjects
- **Institution requirements**: Restricting to higher-ranked universities only
- **Duration changes**: Potential reduction from current 2-3 year validity periods

## Current Graduate Visa Rules

For reference, current rules allow:
- **2 years** for bachelor's and master's degree graduates
- **3 years** for PhD graduates
- **No sponsorship required**: Freedom to work for any employer
- **Flexible employment**: Includes self-employment and multiple jobs
- **Study permission**: Can undertake further studies while on Graduate visa

## Timeline for Changes

Expected timeline:
- **Consultation period**: Spring 2025 public consultation
- **Parliamentary process**: Summer 2025 for any legislative changes
- **Implementation**: Potential changes from January 2026
- **Transition arrangements**: Current visa holders likely protected

## Impact on Current Students

Current international students should consider:
- **Timing of graduation**: Earlier graduation may benefit from current rules
- **Alternative routes**: Exploring Skilled Worker visa options
- **Documentation**: Ensuring all academic credentials are properly verified
- **Career planning**: Preparing for potential sponsorship requirements

## Impact on Universities

UK universities face:
- **Recruitment challenges**: Potential reduction in international student applications
- **Revenue implications**: Graduate visa is key factor in international student decisions
- **Quality focus**: Pressure to demonstrate genuine educational value
- **Compliance requirements**: Enhanced monitoring and reporting obligations

## What Students Should Do Now

Current and prospective students should:
- Stay informed about review developments
- Consider accelerated study options if available
- Research Skilled Worker visa requirements for their career field
- Maintain detailed academic and employment records
- Seek immigration advice for their specific circumstances

The review is expected to conclude by summer 2025, with any changes likely to affect new applicants rather than existing Graduate visa holders.`,
      author: 'Education Immigration Team',
      publishedAt: '2025-01-30T14:30:00Z',
      category: 'Education Policy',
      tags: ['Graduate Visa', 'Student Immigration', 'Policy Review'],
      readTime: '7 min read'
    },
    '3': {
      id: '3',
      title: 'Family Visa Income Threshold Increases to £29,000',
      excerpt: 'Significant increase in minimum income requirement for family visas as part of government\'s migration reduction strategy.',
      content: `The minimum income requirement for UK family visas has increased substantially from £18,600 to £29,000, with further increases planned.

## New Income Requirements

From January 2025:
- **Minimum income**: £29,000 per year (previously £18,600)
- **Further increases planned**: Rising to £34,500 by early 2025, then £38,700
- **Savings alternative**: £88,500 in savings (previously £62,500) if relying on savings alone
- **Combined approach**: Combination of income and savings using established formula

## Who Is Affected

These changes impact:
- **Spouse/partner visa applications**: New applications and extensions
- **Parent visa applications**: For those applying to join children in UK
- **Adult dependent relative visas**: Extended family members
- **Settlement applications**: Those applying for indefinite leave to remain

## Implementation Schedule

The increases will be phased:
- **January 2025**: £29,000 threshold takes effect
- **Spring 2025**: Increase to £34,500
- **Summer 2025**: Final increase to £38,700 (aligning with Skilled Worker threshold)

## Savings Requirements

Updated savings thresholds:
- **Minimum savings**: £88,500 (if no employment income)
- **Combined income/savings**: £2,500 in savings for every £1,000 below income threshold
- **Held period**: Savings must be held for 6 months before application
- **Source documentation**: Enhanced evidence requirements for savings origin

## Exemptions and Protections

Some exemptions apply:
- **Refugee/humanitarian protection**: Sponsors with protected status may be exempt
- **Disability benefits**: Certain disability benefits count toward income requirement
- **Exceptional circumstances**: Limited discretion for exceptional cases
- **Armed forces**: Special provisions for military families

## Impact on Families

The changes will affect:
- **Separated families**: More families unable to meet requirements
- **Regional variations**: Greater impact in lower-income areas
- **Career planning**: Sponsors may need to increase earnings before applying
- **Legal costs**: More complex cases requiring professional assistance

## Alternative Options

Families unable to meet requirements might consider:
- **Article 8 claims**: Human rights-based applications (limited success rates)
- **EU Settlement Scheme**: If applicable based on pre-Brexit residence
- **Other immigration routes**: If sponsor qualifies for different visa categories
- **Appeals process**: Challenging decisions on human rights grounds

## Preparation Strategies

Families should:
- **Financial planning**: Start building savings or increasing income early
- **Documentation**: Maintain detailed financial records
- **Professional advice**: Seek specialist immigration guidance
- **Timing considerations**: Consider application timing relative to income increases
- **Alternative evidence**: Explore all possible sources of qualifying income

## Government Justification

The government states these changes:
- **Reduce migration numbers**: Align with overall reduction targets
- **Economic contribution**: Ensure families can support themselves
- **Public services**: Reduce pressure on public services and benefits
- **Wage growth**: Encourage higher wages in UK job market

The increases represent the most significant change to family immigration rules in over a decade, with substantial implications for mixed-nationality families.`,
      author: 'Family Immigration Team',
      publishedAt: '2025-01-28T11:00:00Z',
      category: 'Family Immigration',
      tags: ['Family Visa', 'Income Requirement', 'Immigration Changes'],
      readTime: '8 min read'
    }
  };

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      const article = mockNews[newsId as keyof typeof mockNews];
      setNewsArticle(article);
      setLoading(false);
    }, 1000);
  }, [newsId]);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
          <p className="text-muted-foreground">Loading article...</p>
        </div>
      </div>
    );
  }

  if (!newsArticle) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-semibold">Article Not Found</h2>
          <p className="text-muted-foreground">The requested article could not be found.</p>
          <Button onClick={() => navigate('/news')}>Back to News</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mobile-page-container bg-background">
      <div className="mobile-page-content">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate('/news')}
                className="mobile-back-button"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to News
              </Button>
              
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </Button>
                <Button variant="outline" size="sm">
                  <Bookmark className="w-4 h-4 mr-2" />
                  Save
                </Button>
              </div>
            </div>

            {/* Article */}
            <Card>
              <CardHeader>
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Badge variant="default">{newsArticle.category}</Badge>
                    <span className="text-sm text-muted-foreground">
                      {newsArticle.readTime}
                    </span>
                  </div>
                  
                  <CardTitle className="text-2xl md:text-3xl">
                    {newsArticle.title}
                  </CardTitle>
                  
                  <p className="text-lg text-muted-foreground">
                    {newsArticle.excerpt}
                  </p>
                  
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      <User className="w-4 h-4" />
                      <span>{newsArticle.author}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-4 h-4" />
                      <span>{formatDate(newsArticle.publishedAt)}</span>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {newsArticle.tags.map((tag: string, index: number) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="prose prose-sm max-w-none">
                  {newsArticle.content.split('\n').map((paragraph: string, index: number) => {
                    if (paragraph.startsWith('## ')) {
                      return (
                        <h2 key={index} className="text-xl font-semibold mt-8 mb-4">
                          {paragraph.replace('## ', '')}
                        </h2>
                      );
                    } else if (paragraph.startsWith('- ')) {
                      return (
                        <li key={index} className="ml-4 mb-2">
                          {paragraph.replace('- ', '')}
                        </li>
                      );
                    } else if (paragraph.trim() === '') {
                      return null;
                    } else {
                      return (
                        <p key={index} className="mb-4 text-sm leading-relaxed">
                          {paragraph}
                        </p>
                      );
                    }
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Related Actions */}
            <Card className="mt-8">
              <CardHeader>
                <CardTitle>Related Tools</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button 
                    onClick={() => navigate('/ai-assistant')}
                    className="h-auto p-4 mobile-button"
                  >
                    <div className="text-center">
                      <User className="w-6 h-6 mx-auto mb-2" />
                      <div className="font-semibold">AI Assistant</div>
                      <div className="text-xs opacity-80">Get personalized advice</div>
                    </div>
                  </Button>
                  
                  <Button 
                    variant="outline"
                    onClick={() => navigate('/eligibility-assessment')}
                    className="h-auto p-4 mobile-button"
                  >
                    <div className="text-center">
                      <Calendar className="w-6 h-6 mx-auto mb-2" />
                      <div className="font-semibold">Assessment</div>
                      <div className="text-xs opacity-80">Check eligibility</div>
                    </div>
                  </Button>
                  
                  <Button 
                    variant="outline"
                    onClick={() => navigate('/visa-routes')}
                    className="h-auto p-4 mobile-button"
                  >
                    <div className="text-center">
                      <Share2 className="w-6 h-6 mx-auto mb-2" />
                      <div className="font-semibold">Visa Routes</div>
                      <div className="text-xs opacity-80">Explore options</div>
                    </div>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}