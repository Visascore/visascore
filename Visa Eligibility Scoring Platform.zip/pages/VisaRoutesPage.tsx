import { useState, useEffect } from 'react';
import { VisaRoutes } from '../components/VisaRoutes';
import { Header } from '../components/Header';
import { VisaRoute } from '../data/visaRoutes';

interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

interface UserProfile {
  name: string;
  email: string;
  completed_onboarding: boolean;
  [key: string]: any;
}

interface VisaRoutesPageProps {
  authState: AuthState;
  userProfile: UserProfile | null;
  navigate: (path: string) => void;
  onSignIn?: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  onSignUp?: (email: string, password: string, name: string) => Promise<{ success: boolean; error?: string }>;
  onSignOut?: () => void;
}

export function VisaRoutesPage({ 
  authState, 
  userProfile, 
  navigate,
  onSignIn,
  onSignUp,
  onSignOut
}: VisaRoutesPageProps) {
  const [showWelcomeMessage, setShowWelcomeMessage] = useState(false);

  console.log('VisaRoutesPage rendering with navigate:', typeof navigate);

  useEffect(() => {
    // Check if user just completed onboarding by looking for a timestamp or flag
    const onboardingCompleted = localStorage.getItem('onboardingJustCompleted');
    if (onboardingCompleted) {
      setShowWelcomeMessage(true);
      // Clear the flag after showing the message
      localStorage.removeItem('onboardingJustCompleted');
      
      // Auto-hide the welcome message after 10 seconds
      setTimeout(() => {
        setShowWelcomeMessage(false);
      }, 10000);
    }
  }, []);
  
  const handleSelectRoute = (route: VisaRoute) => {
    console.log('=== HANDLESELCTROUTE CALLED ===');
    console.log('VisaRoutesPage: Navigating to visa route detail:', route.id);
    console.log('Navigate function type:', typeof navigate);
    console.log('Navigate function definition:', navigate);
    console.log('Route object:', route);
    
    if (typeof navigate !== 'function') {
      console.error('Navigate is not a function!', navigate);
      return;
    }
    
    try {
      const targetPath = `/visa-routes/${route.id}`;
      console.log('Navigating to path:', targetPath);
      navigate(targetPath);
      console.log('Navigation call completed');
    } catch (error) {
      console.error('Navigation error:', error);
      console.error('Error stack:', error.stack);
    }
  };

  const handleStartEligibilityCheck = (route: VisaRoute) => {
    console.log('=== HANDLESTARTELIGIBILITYCHECK CALLED ===');
    console.log('VisaRoutesPage: Starting eligibility check for route:', route.id);
    console.log('Navigate function type:', typeof navigate);
    console.log('Navigate function definition:', navigate);
    console.log('Route object:', route);
    
    if (typeof navigate !== 'function') {
      console.error('Navigate is not a function!', navigate);
      return;
    }
    
    try {
      const targetPath = `/visa-routes/${route.id}`;
      console.log('Navigating to path for eligibility check:', targetPath);
      // Navigate to the specific visa route detail page which contains the eligibility checker
      navigate(targetPath);
      console.log('Navigation call completed for eligibility check');
    } catch (error) {
      console.error('Navigation error:', error);
      console.error('Error stack:', error.stack);
    }
  };

  const handleSignOut = () => {
    console.log('Sign out requested from visa routes page');
    if (onSignOut) {
      onSignOut();
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header
        authState={authState}
        userProfile={userProfile}
        onSignIn={onSignIn}
        onSignUp={onSignUp}
        onSignOut={handleSignOut}
        currentPath="/visa-routes"
        navigate={navigate}
      />
      
      <div className="pt-16">
        <VisaRoutes 
          authState={authState}
          onSelectRoute={handleSelectRoute}
          onViewDetails={handleSelectRoute}
          navigate={navigate}
        />
      </div>
    </div>
  );
}