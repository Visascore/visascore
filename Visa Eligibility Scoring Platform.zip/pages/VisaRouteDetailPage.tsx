import { useState } from 'react';
import { VisaRouteDetail } from '../components/VisaRouteDetail';
import { EligibilityQuestionnaire } from '../components/EligibilityQuestionnaire';
import { Header } from '../components/Header';
import { visaRoutes } from '../data/visaRoutes';

interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

interface UserProfile {
  name: string;
  email: string;
  completed_onboarding: boolean;
  [key: string]: any;
}

interface VisaRouteDetailPageProps {
  routeId: string;
  authState: AuthState;
  userProfile: UserProfile | null;
  navigate: (path: string, data?: any) => void;
  onSignIn?: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  onSignUp?: (email: string, password: string, name: string) => Promise<{ success: boolean; error?: string }>;
  onSignOut?: () => void;
}

export function VisaRouteDetailPage({ 
  routeId, 
  authState, 
  userProfile, 
  navigate,
  onSignIn,
  onSignUp,
  onSignOut
}: VisaRouteDetailPageProps) {
  const [showEligibilityCheck, setShowEligibilityCheck] = useState(false);
  
  const route = visaRoutes.find(r => r.id === routeId);

  const handleSignOut = () => {
    console.log('Sign out requested from visa route detail');
    if (onSignOut) {
      onSignOut();
    }
  };

  if (!route) {
    return (
      <div className="min-h-screen bg-background">
        <Header
          authState={authState}
          userProfile={userProfile}
          onSignIn={onSignIn}
          onSignUp={onSignUp}
          onSignOut={handleSignOut}
          currentPath={`/visa-routes/${routeId}`}
          navigate={navigate}
        />
        
        <div className="pt-16 flex items-center justify-center min-h-screen">
          <div className="text-center space-y-4">
            <h2 className="text-2xl font-semibold">Visa Route Not Found</h2>
            <p className="text-muted-foreground">The requested visa route could not be found.</p>
            <button
              onClick={() => navigate('/visa-routes')}
              className="bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors"
            >
              View All Routes
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (showEligibilityCheck) {
    // Create user object for the questionnaire
    const user = authState.user ? {
      id: authState.user.id,
      email: authState.user.email,
      name: userProfile?.name || authState.user.user_metadata?.name
    } : undefined;

    return (
      <div className="min-h-screen bg-background">
        <Header
          authState={authState}
          userProfile={userProfile}
          onSignIn={onSignIn}
          onSignUp={onSignUp}
          onSignOut={handleSignOut}
          currentPath={`/visa-routes/${routeId}`}
          navigate={navigate}
        />
        
        <div className="pt-16">
          <EligibilityQuestionnaire 
            route={route}
            onBack={() => setShowEligibilityCheck(false)}
            onComplete={(answers, assessment) => {
              // This will be handled by the navigate prop in the questionnaire
            }}
            navigate={navigate}
            user={user}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header
        authState={authState}
        userProfile={userProfile}
        onSignIn={onSignIn}
        onSignUp={onSignUp}
        onSignOut={handleSignOut}
        currentPath={`/visa-routes/${routeId}`}
        navigate={navigate}
      />
      
      <div className="pt-16">
        <VisaRouteDetail 
          route={route}
          onBack={() => navigate('/visa-routes')}
          onStartEligibilityCheck={() => setShowEligibilityCheck(true)}
          onShowDetailedGuide={() => {
            // Navigate to specific guide pages based on route
            if (route.id === 'global-talent') {
              navigate('/global-talent-guide');
            } else if (route.id === 'ancestry-visa') {
              navigate('/ancestry-visa-guide');
            }
          }}
        />
      </div>
    </div>
  );
}