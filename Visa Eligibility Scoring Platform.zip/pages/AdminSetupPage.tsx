import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Label } from '../components/ui/label';
import { Shield, CheckCircle, AlertTriangle } from 'lucide-react';
import { projectId } from '../utils/supabase/info';

export function AdminSetupPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isComplete, setIsComplete] = useState(false);

  const handleCreateAdmin = async () => {
    setIsLoading(true);
    setMessage(null);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ca272e8b/admin/setup`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            email: 'admin@visascore.co.uk',
            password: '@Admin123',
            confirmKey: 'ADMIN_SETUP_VISA_SCORE_2025'
          })
        }
      );

      const data = await response.json();

      if (response.ok) {
        setMessage({ type: 'success', text: data.message });
        setIsComplete(true);
      } else {
        setMessage({ type: 'error', text: data.error || 'Failed to create admin account' });
      }
    } catch (error) {
      console.error('Admin setup error:', error);
      setMessage({ type: 'error', text: 'Network error - failed to create admin account' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
            <Shield className="w-6 h-6 text-primary" />
          </div>
          <CardTitle>Admin Account Setup</CardTitle>
          <CardDescription>
            Initialize the Visa Score admin account
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {!isComplete ? (
            <>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Admin Email</Label>
                  <Input 
                    value="admin@visascore.co.uk" 
                    disabled 
                    className="bg-muted"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Admin Password</Label>
                  <Input 
                    value="@Admin123" 
                    type="password"
                    disabled 
                    className="bg-muted"
                  />
                </div>
              </div>

              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  This will create the system administrator account with the credentials shown above.
                  This action can only be performed once.
                </AlertDescription>
              </Alert>

              <Button 
                onClick={handleCreateAdmin}
                disabled={isLoading}
                className="w-full"
              >
                {isLoading ? 'Creating Admin Account...' : 'Create Admin Account'}
              </Button>
            </>
          ) : (
            <div className="text-center space-y-4">
              <div className="mx-auto w-12 h-12 bg-green-500/10 rounded-full flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-green-500" />
              </div>
              <div>
                <h3 className="font-semibold text-green-500">Setup Complete</h3>
                <p className="text-sm text-muted-foreground mt-2">
                  Admin account has been created successfully. You can now access the admin panel.
                </p>
              </div>
              <Button 
                onClick={() => window.location.href = '/admin/login'}
                className="w-full"
              >
                Go to Admin Login
              </Button>
            </div>
          )}

          {message && (
            <Alert className={message.type === 'error' ? 'border-destructive' : 'border-green-500'}>
              {message.type === 'error' ? (
                <AlertTriangle className="h-4 w-4" />
              ) : (
                <CheckCircle className="h-4 w-4" />
              )}
              <AlertDescription className={message.type === 'error' ? 'text-destructive' : 'text-green-500'}>
                {message.text}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>
    </div>
  );
}