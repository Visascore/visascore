export interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  session: any;
}

export interface UserProfile {
  name: string;
  email: string;
  completed_onboarding: boolean;
  has_used_trial?: boolean;
  [key: string]: any;
}

export interface Subscription {
  id: string;
  status: 'trial' | 'active' | 'canceled' | 'expired';
  plan: string;
  amount: number;
  currency: string;
  trial_start?: string;
  trial_end?: string;
  current_period_start?: string;
  current_period_end?: string;
  cancel_at_period_end?: boolean;
  is_expired?: boolean;
  days_remaining?: number;
  card_last_four?: string;
  card_brand?: string;
}